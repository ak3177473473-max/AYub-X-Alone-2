(function() {
    const t = document.createElement("link").relList;
    if (t && t.supports && t.supports("modulepreload"))
        return;
    for (const l of document.querySelectorAll('link[rel="modulepreload"]'))
        r(l);
    new MutationObserver(l => {
        for (const o of l)
            if (o.type === "childList")
                for (const i of o.addedNodes)
                    i.tagName === "LINK" && i.rel === "modulepreload" && r(i)
    }
    ).observe(document, {
        childList: !0,
        subtree: !0
    });
    function n(l) {
        const o = {};
        return l.integrity && (o.integrity = l.integrity),
        l.referrerPolicy && (o.referrerPolicy = l.referrerPolicy),
        l.crossOrigin === "use-credentials" ? o.credentials = "include" : l.crossOrigin === "anonymous" ? o.credentials = "omit" : o.credentials = "same-origin",
        o
    }
    function r(l) {
        if (l.ep)
            return;
        l.ep = !0;
        const o = n(l);
        fetch(l.href, o)
    }
}
)();
function oc(e) {
    return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
}
var Yu = {
    exports: {}
}
  , il = {}
  , Xu = {
    exports: {}
}
  , M = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var er = Symbol.for("react.element")
  , ic = Symbol.for("react.portal")
  , uc = Symbol.for("react.fragment")
  , sc = Symbol.for("react.strict_mode")
  , ac = Symbol.for("react.profiler")
  , cc = Symbol.for("react.provider")
  , fc = Symbol.for("react.context")
  , dc = Symbol.for("react.forward_ref")
  , pc = Symbol.for("react.suspense")
  , mc = Symbol.for("react.memo")
  , hc = Symbol.for("react.lazy")
  , Ii = Symbol.iterator;
function vc(e) {
    return e === null || typeof e != "object" ? null : (e = Ii && e[Ii] || e["@@iterator"],
    typeof e == "function" ? e : null)
}
var Gu = {
    isMounted: function() {
        return !1
    },
    enqueueForceUpdate: function() {},
    enqueueReplaceState: function() {},
    enqueueSetState: function() {}
}
  , Zu = Object.assign
  , Ju = {};
function pn(e, t, n) {
    this.props = e,
    this.context = t,
    this.refs = Ju,
    this.updater = n || Gu
}
pn.prototype.isReactComponent = {};
pn.prototype.setState = function(e, t) {
    if (typeof e != "object" && typeof e != "function" && e != null)
        throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
    this.updater.enqueueSetState(this, e, t, "setState")
}
;
pn.prototype.forceUpdate = function(e) {
    this.updater.enqueueForceUpdate(this, e, "forceUpdate")
}
;
function qu() {}
qu.prototype = pn.prototype;
function Ho(e, t, n) {
    this.props = e,
    this.context = t,
    this.refs = Ju,
    this.updater = n || Gu
}
var Wo = Ho.prototype = new qu;
Wo.constructor = Ho;
Zu(Wo, pn.prototype);
Wo.isPureReactComponent = !0;
var Ui = Array.isArray
  , bu = Object.prototype.hasOwnProperty
  , Qo = {
    current: null
}
  , es = {
    key: !0,
    ref: !0,
    __self: !0,
    __source: !0
};
function ts(e, t, n) {
    var r, l = {}, o = null, i = null;
    if (t != null)
        for (r in t.ref !== void 0 && (i = t.ref),
        t.key !== void 0 && (o = "" + t.key),
        t)
            bu.call(t, r) && !es.hasOwnProperty(r) && (l[r] = t[r]);
    var u = arguments.length - 2;
    if (u === 1)
        l.children = n;
    else if (1 < u) {
        for (var s = Array(u), c = 0; c < u; c++)
            s[c] = arguments[c + 2];
        l.children = s
    }
    if (e && e.defaultProps)
        for (r in u = e.defaultProps,
        u)
            l[r] === void 0 && (l[r] = u[r]);
    return {
        $$typeof: er,
        type: e,
        key: o,
        ref: i,
        props: l,
        _owner: Qo.current
    }
}
function yc(e, t) {
    return {
        $$typeof: er,
        type: e.type,
        key: t,
        ref: e.ref,
        props: e.props,
        _owner: e._owner
    }
}
function Ko(e) {
    return typeof e == "object" && e !== null && e.$$typeof === er
}
function gc(e) {
    var t = {
        "=": "=0",
        ":": "=2"
    };
    return "$" + e.replace(/[=:]/g, function(n) {
        return t[n]
    })
}
var Ai = /\/+/g;
function El(e, t) {
    return typeof e == "object" && e !== null && e.key != null ? gc("" + e.key) : t.toString(36)
}
function Cr(e, t, n, r, l) {
    var o = typeof e;
    (o === "undefined" || o === "boolean") && (e = null);
    var i = !1;
    if (e === null)
        i = !0;
    else
        switch (o) {
        case "string":
        case "number":
            i = !0;
            break;
        case "object":
            switch (e.$$typeof) {
            case er:
            case ic:
                i = !0
            }
        }
    if (i)
        return i = e,
        l = l(i),
        e = r === "" ? "." + El(i, 0) : r,
        Ui(l) ? (n = "",
        e != null && (n = e.replace(Ai, "$&/") + "/"),
        Cr(l, t, n, "", function(c) {
            return c
        })) : l != null && (Ko(l) && (l = yc(l, n + (!l.key || i && i.key === l.key ? "" : ("" + l.key).replace(Ai, "$&/") + "/") + e)),
        t.push(l)),
        1;
    if (i = 0,
    r = r === "" ? "." : r + ":",
    Ui(e))
        for (var u = 0; u < e.length; u++) {
            o = e[u];
            var s = r + El(o, u);
            i += Cr(o, t, n, s, l)
        }
    else if (s = vc(e),
    typeof s == "function")
        for (e = s.call(e),
        u = 0; !(o = e.next()).done; )
            o = o.value,
            s = r + El(o, u++),
            i += Cr(o, t, n, s, l);
    else if (o === "object")
        throw t = String(e),
        Error("Objects are not valid as a React child (found: " + (t === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : t) + "). If you meant to render a collection of children, use an array instead.");
    return i
}
function ir(e, t, n) {
    if (e == null)
        return e;
    var r = []
      , l = 0;
    return Cr(e, r, "", "", function(o) {
        return t.call(n, o, l++)
    }),
    r
}
function wc(e) {
    if (e._status === -1) {
        var t = e._result;
        t = t(),
        t.then(function(n) {
            (e._status === 0 || e._status === -1) && (e._status = 1,
            e._result = n)
        }, function(n) {
            (e._status === 0 || e._status === -1) && (e._status = 2,
            e._result = n)
        }),
        e._status === -1 && (e._status = 0,
        e._result = t)
    }
    if (e._status === 1)
        return e._result.default;
    throw e._result
}
var pe = {
    current: null
}
  , Nr = {
    transition: null
}
  , xc = {
    ReactCurrentDispatcher: pe,
    ReactCurrentBatchConfig: Nr,
    ReactCurrentOwner: Qo
};
function ns() {
    throw Error("act(...) is not supported in production builds of React.")
}
M.Children = {
    map: ir,
    forEach: function(e, t, n) {
        ir(e, function() {
            t.apply(this, arguments)
        }, n)
    },
    count: function(e) {
        var t = 0;
        return ir(e, function() {
            t++
        }),
        t
    },
    toArray: function(e) {
        return ir(e, function(t) {
            return t
        }) || []
    },
    only: function(e) {
        if (!Ko(e))
            throw Error("React.Children.only expected to receive a single React element child.");
        return e
    }
};
M.Component = pn;
M.Fragment = uc;
M.Profiler = ac;
M.PureComponent = Ho;
M.StrictMode = sc;
M.Suspense = pc;
M.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = xc;
M.act = ns;
M.cloneElement = function(e, t, n) {
    if (e == null)
        throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + e + ".");
    var r = Zu({}, e.props)
      , l = e.key
      , o = e.ref
      , i = e._owner;
    if (t != null) {
        if (t.ref !== void 0 && (o = t.ref,
        i = Qo.current),
        t.key !== void 0 && (l = "" + t.key),
        e.type && e.type.defaultProps)
            var u = e.type.defaultProps;
        for (s in t)
            bu.call(t, s) && !es.hasOwnProperty(s) && (r[s] = t[s] === void 0 && u !== void 0 ? u[s] : t[s])
    }
    var s = arguments.length - 2;
    if (s === 1)
        r.children = n;
    else if (1 < s) {
        u = Array(s);
        for (var c = 0; c < s; c++)
            u[c] = arguments[c + 2];
        r.children = u
    }
    return {
        $$typeof: er,
        type: e.type,
        key: l,
        ref: o,
        props: r,
        _owner: i
    }
}
;
M.createContext = function(e) {
    return e = {
        $$typeof: fc,
        _currentValue: e,
        _currentValue2: e,
        _threadCount: 0,
        Provider: null,
        Consumer: null,
        _defaultValue: null,
        _globalName: null
    },
    e.Provider = {
        $$typeof: cc,
        _context: e
    },
    e.Consumer = e
}
;
M.createElement = ts;
M.createFactory = function(e) {
    var t = ts.bind(null, e);
    return t.type = e,
    t
}
;
M.createRef = function() {
    return {
        current: null
    }
}
;
M.forwardRef = function(e) {
    return {
        $$typeof: dc,
        render: e
    }
}
;
M.isValidElement = Ko;
M.lazy = function(e) {
    return {
        $$typeof: hc,
        _payload: {
            _status: -1,
            _result: e
        },
        _init: wc
    }
}
;
M.memo = function(e, t) {
    return {
        $$typeof: mc,
        type: e,
        compare: t === void 0 ? null : t
    }
}
;
M.startTransition = function(e) {
    var t = Nr.transition;
    Nr.transition = {};
    try {
        e()
    } finally {
        Nr.transition = t
    }
}
;
M.unstable_act = ns;
M.useCallback = function(e, t) {
    return pe.current.useCallback(e, t)
}
;
M.useContext = function(e) {
    return pe.current.useContext(e)
}
;
M.useDebugValue = function() {}
;
M.useDeferredValue = function(e) {
    return pe.current.useDeferredValue(e)
}
;
M.useEffect = function(e, t) {
    return pe.current.useEffect(e, t)
}
;
M.useId = function() {
    return pe.current.useId()
}
;
M.useImperativeHandle = function(e, t, n) {
    return pe.current.useImperativeHandle(e, t, n)
}
;
M.useInsertionEffect = function(e, t) {
    return pe.current.useInsertionEffect(e, t)
}
;
M.useLayoutEffect = function(e, t) {
    return pe.current.useLayoutEffect(e, t)
}
;
M.useMemo = function(e, t) {
    return pe.current.useMemo(e, t)
}
;
M.useReducer = function(e, t, n) {
    return pe.current.useReducer(e, t, n)
}
;
M.useRef = function(e) {
    return pe.current.useRef(e)
}
;
M.useState = function(e) {
    return pe.current.useState(e)
}
;
M.useSyncExternalStore = function(e, t, n) {
    return pe.current.useSyncExternalStore(e, t, n)
}
;
M.useTransition = function() {
    return pe.current.useTransition()
}
;
M.version = "18.3.1";
Xu.exports = M;
var se = Xu.exports;
const kc = oc(se);
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Sc = se
  , Ec = Symbol.for("react.element")
  , Cc = Symbol.for("react.fragment")
  , Nc = Object.prototype.hasOwnProperty
  , _c = Sc.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner
  , Pc = {
    key: !0,
    ref: !0,
    __self: !0,
    __source: !0
};
function rs(e, t, n) {
    var r, l = {}, o = null, i = null;
    n !== void 0 && (o = "" + n),
    t.key !== void 0 && (o = "" + t.key),
    t.ref !== void 0 && (i = t.ref);
    for (r in t)
        Nc.call(t, r) && !Pc.hasOwnProperty(r) && (l[r] = t[r]);
    if (e && e.defaultProps)
        for (r in t = e.defaultProps,
        t)
            l[r] === void 0 && (l[r] = t[r]);
    return {
        $$typeof: Ec,
        type: e,
        key: o,
        ref: i,
        props: l,
        _owner: _c.current
    }
}
il.Fragment = Cc;
il.jsx = rs;
il.jsxs = rs;
Yu.exports = il;
var v = Yu.exports
  , Gl = {}
  , ls = {
    exports: {}
}
  , _e = {}
  , os = {
    exports: {}
}
  , is = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
(function(e) {
    function t(x, z) {
        var L = x.length;
        x.push(z);
        e: for (; 0 < L; ) {
            var W = L - 1 >>> 1
              , K = x[W];
            if (0 < l(K, z))
                x[W] = z,
                x[L] = K,
                L = W;
            else
                break e
        }
    }
    function n(x) {
        return x.length === 0 ? null : x[0]
    }
    function r(x) {
        if (x.length === 0)
            return null;
        var z = x[0]
          , L = x.pop();
        if (L !== z) {
            x[0] = L;
            e: for (var W = 0, K = x.length, Et = K >>> 1; W < Et; ) {
                var Ct = 2 * (W + 1) - 1
                  , Sl = x[Ct]
                  , Nt = Ct + 1
                  , or = x[Nt];
                if (0 > l(Sl, L))
                    Nt < K && 0 > l(or, Sl) ? (x[W] = or,
                    x[Nt] = L,
                    W = Nt) : (x[W] = Sl,
                    x[Ct] = L,
                    W = Ct);
                else if (Nt < K && 0 > l(or, L))
                    x[W] = or,
                    x[Nt] = L,
                    W = Nt;
                else
                    break e
            }
        }
        return z
    }
    function l(x, z) {
        var L = x.sortIndex - z.sortIndex;
        return L !== 0 ? L : x.id - z.id
    }
    if (typeof performance == "object" && typeof performance.now == "function") {
        var o = performance;
        e.unstable_now = function() {
            return o.now()
        }
    } else {
        var i = Date
          , u = i.now();
        e.unstable_now = function() {
            return i.now() - u
        }
    }
    var s = []
      , c = []
      , h = 1
      , m = null
      , p = 3
      , w = !1
      , k = !1
      , S = !1
      , D = typeof setTimeout == "function" ? setTimeout : null
      , f = typeof clearTimeout == "function" ? clearTimeout : null
      , a = typeof setImmediate < "u" ? setImmediate : null;
    typeof navigator < "u" && navigator.scheduling !== void 0 && navigator.scheduling.isInputPending !== void 0 && navigator.scheduling.isInputPending.bind(navigator.scheduling);
    function d(x) {
        for (var z = n(c); z !== null; ) {
            if (z.callback === null)
                r(c);
            else if (z.startTime <= x)
                r(c),
                z.sortIndex = z.expirationTime,
                t(s, z);
            else
                break;
            z = n(c)
        }
    }
    function y(x) {
        if (S = !1,
        d(x),
        !k)
            if (n(s) !== null)
                k = !0,
                $(E);
            else {
                var z = n(c);
                z !== null && ke(y, z.startTime - x)
            }
    }
    function E(x, z) {
        k = !1,
        S && (S = !1,
        f(j),
        j = -1),
        w = !0;
        var L = p;
        try {
            for (d(z),
            m = n(s); m !== null && (!(m.expirationTime > z) || x && !xe()); ) {
                var W = m.callback;
                if (typeof W == "function") {
                    m.callback = null,
                    p = m.priorityLevel;
                    var K = W(m.expirationTime <= z);
                    z = e.unstable_now(),
                    typeof K == "function" ? m.callback = K : m === n(s) && r(s),
                    d(z)
                } else
                    r(s);
                m = n(s)
            }
            if (m !== null)
                var Et = !0;
            else {
                var Ct = n(c);
                Ct !== null && ke(y, Ct.startTime - z),
                Et = !1
            }
            return Et
        } finally {
            m = null,
            p = L,
            w = !1
        }
    }
    var _ = !1
      , N = null
      , j = -1
      , H = 5
      , R = -1;
    function xe() {
        return !(e.unstable_now() - R < H)
    }
    function P() {
        if (N !== null) {
            var x = e.unstable_now();
            R = x;
            var z = !0;
            try {
                z = N(!0, x)
            } finally {
                z ? T() : (_ = !1,
                N = null)
            }
        } else
            _ = !1
    }
    var T;
    if (typeof a == "function")
        T = function() {
            a(P)
        }
        ;
    else if (typeof MessageChannel < "u") {
        var I = new MessageChannel
          , U = I.port2;
        I.port1.onmessage = P,
        T = function() {
            U.postMessage(null)
        }
    } else
        T = function() {
            D(P, 0)
        }
        ;
    function $(x) {
        N = x,
        _ || (_ = !0,
        T())
    }
    function ke(x, z) {
        j = D(function() {
            x(e.unstable_now())
        }, z)
    }
    e.unstable_IdlePriority = 5,
    e.unstable_ImmediatePriority = 1,
    e.unstable_LowPriority = 4,
    e.unstable_NormalPriority = 3,
    e.unstable_Profiling = null,
    e.unstable_UserBlockingPriority = 2,
    e.unstable_cancelCallback = function(x) {
        x.callback = null
    }
    ,
    e.unstable_continueExecution = function() {
        k || w || (k = !0,
        $(E))
    }
    ,
    e.unstable_forceFrameRate = function(x) {
        0 > x || 125 < x ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : H = 0 < x ? Math.floor(1e3 / x) : 5
    }
    ,
    e.unstable_getCurrentPriorityLevel = function() {
        return p
    }
    ,
    e.unstable_getFirstCallbackNode = function() {
        return n(s)
    }
    ,
    e.unstable_next = function(x) {
        switch (p) {
        case 1:
        case 2:
        case 3:
            var z = 3;
            break;
        default:
            z = p
        }
        var L = p;
        p = z;
        try {
            return x()
        } finally {
            p = L
        }
    }
    ,
    e.unstable_pauseExecution = function() {}
    ,
    e.unstable_requestPaint = function() {}
    ,
    e.unstable_runWithPriority = function(x, z) {
        switch (x) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
            break;
        default:
            x = 3
        }
        var L = p;
        p = x;
        try {
            return z()
        } finally {
            p = L
        }
    }
    ,
    e.unstable_scheduleCallback = function(x, z, L) {
        var W = e.unstable_now();
        switch (typeof L == "object" && L !== null ? (L = L.delay,
        L = typeof L == "number" && 0 < L ? W + L : W) : L = W,
        x) {
        case 1:
            var K = -1;
            break;
        case 2:
            K = 250;
            break;
        case 5:
            K = 1073741823;
            break;
        case 4:
            K = 1e4;
            break;
        default:
            K = 5e3
        }
        return K = L + K,
        x = {
            id: h++,
            callback: z,
            priorityLevel: x,
            startTime: L,
            expirationTime: K,
            sortIndex: -1
        },
        L > W ? (x.sortIndex = L,
        t(c, x),
        n(s) === null && x === n(c) && (S ? (f(j),
        j = -1) : S = !0,
        ke(y, L - W))) : (x.sortIndex = K,
        t(s, x),
        k || w || (k = !0,
        $(E))),
        x
    }
    ,
    e.unstable_shouldYield = xe,
    e.unstable_wrapCallback = function(x) {
        var z = p;
        return function() {
            var L = p;
            p = z;
            try {
                return x.apply(this, arguments)
            } finally {
                p = L
            }
        }
    }
}
)(is);
os.exports = is;
var jc = os.exports;
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var zc = se
  , Ne = jc;
function g(e) {
    for (var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, n = 1; n < arguments.length; n++)
        t += "&args[]=" + encodeURIComponent(arguments[n]);
    return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
}
var us = new Set
  , In = {};
function Ut(e, t) {
    on(e, t),
    on(e + "Capture", t)
}
function on(e, t) {
    for (In[e] = t,
    e = 0; e < t.length; e++)
        us.add(t[e])
}
var qe = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u")
  , Zl = Object.prototype.hasOwnProperty
  , Lc = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/
  , $i = {}
  , Vi = {};
function Tc(e) {
    return Zl.call(Vi, e) ? !0 : Zl.call($i, e) ? !1 : Lc.test(e) ? Vi[e] = !0 : ($i[e] = !0,
    !1)
}
function Rc(e, t, n, r) {
    if (n !== null && n.type === 0)
        return !1;
    switch (typeof t) {
    case "function":
    case "symbol":
        return !0;
    case "boolean":
        return r ? !1 : n !== null ? !n.acceptsBooleans : (e = e.toLowerCase().slice(0, 5),
        e !== "data-" && e !== "aria-");
    default:
        return !1
    }
}
function Mc(e, t, n, r) {
    if (t === null || typeof t > "u" || Rc(e, t, n, r))
        return !0;
    if (r)
        return !1;
    if (n !== null)
        switch (n.type) {
        case 3:
            return !t;
        case 4:
            return t === !1;
        case 5:
            return isNaN(t);
        case 6:
            return isNaN(t) || 1 > t
        }
    return !1
}
function me(e, t, n, r, l, o, i) {
    this.acceptsBooleans = t === 2 || t === 3 || t === 4,
    this.attributeName = r,
    this.attributeNamespace = l,
    this.mustUseProperty = n,
    this.propertyName = e,
    this.type = t,
    this.sanitizeURL = o,
    this.removeEmptyString = i
}
var oe = {};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e) {
    oe[e] = new me(e,0,!1,e,null,!1,!1)
});
[["acceptCharset", "accept-charset"], ["className", "class"], ["htmlFor", "for"], ["httpEquiv", "http-equiv"]].forEach(function(e) {
    var t = e[0];
    oe[t] = new me(t,1,!1,e[1],null,!1,!1)
});
["contentEditable", "draggable", "spellCheck", "value"].forEach(function(e) {
    oe[e] = new me(e,2,!1,e.toLowerCase(),null,!1,!1)
});
["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(e) {
    oe[e] = new me(e,2,!1,e,null,!1,!1)
});
"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e) {
    oe[e] = new me(e,3,!1,e.toLowerCase(),null,!1,!1)
});
["checked", "multiple", "muted", "selected"].forEach(function(e) {
    oe[e] = new me(e,3,!0,e,null,!1,!1)
});
["capture", "download"].forEach(function(e) {
    oe[e] = new me(e,4,!1,e,null,!1,!1)
});
["cols", "rows", "size", "span"].forEach(function(e) {
    oe[e] = new me(e,6,!1,e,null,!1,!1)
});
["rowSpan", "start"].forEach(function(e) {
    oe[e] = new me(e,5,!1,e.toLowerCase(),null,!1,!1)
});
var Yo = /[\-:]([a-z])/g;
function Xo(e) {
    return e[1].toUpperCase()
}
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e) {
    var t = e.replace(Yo, Xo);
    oe[t] = new me(t,1,!1,e,null,!1,!1)
});
"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e) {
    var t = e.replace(Yo, Xo);
    oe[t] = new me(t,1,!1,e,"http://www.w3.org/1999/xlink",!1,!1)
});
["xml:base", "xml:lang", "xml:space"].forEach(function(e) {
    var t = e.replace(Yo, Xo);
    oe[t] = new me(t,1,!1,e,"http://www.w3.org/XML/1998/namespace",!1,!1)
});
["tabIndex", "crossOrigin"].forEach(function(e) {
    oe[e] = new me(e,1,!1,e.toLowerCase(),null,!1,!1)
});
oe.xlinkHref = new me("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1);
["src", "href", "action", "formAction"].forEach(function(e) {
    oe[e] = new me(e,1,!1,e.toLowerCase(),null,!0,!0)
});
function Go(e, t, n, r) {
    var l = oe.hasOwnProperty(t) ? oe[t] : null;
    (l !== null ? l.type !== 0 : r || !(2 < t.length) || t[0] !== "o" && t[0] !== "O" || t[1] !== "n" && t[1] !== "N") && (Mc(t, n, l, r) && (n = null),
    r || l === null ? Tc(t) && (n === null ? e.removeAttribute(t) : e.setAttribute(t, "" + n)) : l.mustUseProperty ? e[l.propertyName] = n === null ? l.type === 3 ? !1 : "" : n : (t = l.attributeName,
    r = l.attributeNamespace,
    n === null ? e.removeAttribute(t) : (l = l.type,
    n = l === 3 || l === 4 && n === !0 ? "" : "" + n,
    r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))))
}
var nt = zc.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED
  , ur = Symbol.for("react.element")
  , Vt = Symbol.for("react.portal")
  , Bt = Symbol.for("react.fragment")
  , Zo = Symbol.for("react.strict_mode")
  , Jl = Symbol.for("react.profiler")
  , ss = Symbol.for("react.provider")
  , as = Symbol.for("react.context")
  , Jo = Symbol.for("react.forward_ref")
  , ql = Symbol.for("react.suspense")
  , bl = Symbol.for("react.suspense_list")
  , qo = Symbol.for("react.memo")
  , lt = Symbol.for("react.lazy")
  , cs = Symbol.for("react.offscreen")
  , Bi = Symbol.iterator;
function vn(e) {
    return e === null || typeof e != "object" ? null : (e = Bi && e[Bi] || e["@@iterator"],
    typeof e == "function" ? e : null)
}
var G = Object.assign, Cl;
function Cn(e) {
    if (Cl === void 0)
        try {
            throw Error()
        } catch (n) {
            var t = n.stack.trim().match(/\n( *(at )?)/);
            Cl = t && t[1] || ""
        }
    return `
` + Cl + e
}
var Nl = !1;
function _l(e, t) {
    if (!e || Nl)
        return "";
    Nl = !0;
    var n = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
        if (t)
            if (t = function() {
                throw Error()
            }
            ,
            Object.defineProperty(t.prototype, "props", {
                set: function() {
                    throw Error()
                }
            }),
            typeof Reflect == "object" && Reflect.construct) {
                try {
                    Reflect.construct(t, [])
                } catch (c) {
                    var r = c
                }
                Reflect.construct(e, [], t)
            } else {
                try {
                    t.call()
                } catch (c) {
                    r = c
                }
                e.call(t.prototype)
            }
        else {
            try {
                throw Error()
            } catch (c) {
                r = c
            }
            e()
        }
    } catch (c) {
        if (c && r && typeof c.stack == "string") {
            for (var l = c.stack.split(`
`), o = r.stack.split(`
`), i = l.length - 1, u = o.length - 1; 1 <= i && 0 <= u && l[i] !== o[u]; )
                u--;
            for (; 1 <= i && 0 <= u; i--,
            u--)
                if (l[i] !== o[u]) {
                    if (i !== 1 || u !== 1)
                        do
                            if (i--,
                            u--,
                            0 > u || l[i] !== o[u]) {
                                var s = `
` + l[i].replace(" at new ", " at ");
                                return e.displayName && s.includes("<anonymous>") && (s = s.replace("<anonymous>", e.displayName)),
                                s
                            }
                        while (1 <= i && 0 <= u);
                    break
                }
        }
    } finally {
        Nl = !1,
        Error.prepareStackTrace = n
    }
    return (e = e ? e.displayName || e.name : "") ? Cn(e) : ""
}
function Fc(e) {
    switch (e.tag) {
    case 5:
        return Cn(e.type);
    case 16:
        return Cn("Lazy");
    case 13:
        return Cn("Suspense");
    case 19:
        return Cn("SuspenseList");
    case 0:
    case 2:
    case 15:
        return e = _l(e.type, !1),
        e;
    case 11:
        return e = _l(e.type.render, !1),
        e;
    case 1:
        return e = _l(e.type, !0),
        e;
    default:
        return ""
    }
}
function eo(e) {
    if (e == null)
        return null;
    if (typeof e == "function")
        return e.displayName || e.name || null;
    if (typeof e == "string")
        return e;
    switch (e) {
    case Bt:
        return "Fragment";
    case Vt:
        return "Portal";
    case Jl:
        return "Profiler";
    case Zo:
        return "StrictMode";
    case ql:
        return "Suspense";
    case bl:
        return "SuspenseList"
    }
    if (typeof e == "object")
        switch (e.$$typeof) {
        case as:
            return (e.displayName || "Context") + ".Consumer";
        case ss:
            return (e._context.displayName || "Context") + ".Provider";
        case Jo:
            var t = e.render;
            return e = e.displayName,
            e || (e = t.displayName || t.name || "",
            e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef"),
            e;
        case qo:
            return t = e.displayName || null,
            t !== null ? t : eo(e.type) || "Memo";
        case lt:
            t = e._payload,
            e = e._init;
            try {
                return eo(e(t))
            } catch {}
        }
    return null
}
function Oc(e) {
    var t = e.type;
    switch (e.tag) {
    case 24:
        return "Cache";
    case 9:
        return (t.displayName || "Context") + ".Consumer";
    case 10:
        return (t._context.displayName || "Context") + ".Provider";
    case 18:
        return "DehydratedFragment";
    case 11:
        return e = t.render,
        e = e.displayName || e.name || "",
        t.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef");
    case 7:
        return "Fragment";
    case 5:
        return t;
    case 4:
        return "Portal";
    case 3:
        return "Root";
    case 6:
        return "Text";
    case 16:
        return eo(t);
    case 8:
        return t === Zo ? "StrictMode" : "Mode";
    case 22:
        return "Offscreen";
    case 12:
        return "Profiler";
    case 21:
        return "Scope";
    case 13:
        return "Suspense";
    case 19:
        return "SuspenseList";
    case 25:
        return "TracingMarker";
    case 1:
    case 0:
    case 17:
    case 2:
    case 14:
    case 15:
        if (typeof t == "function")
            return t.displayName || t.name || null;
        if (typeof t == "string")
            return t
    }
    return null
}
function gt(e) {
    switch (typeof e) {
    case "boolean":
    case "number":
    case "string":
    case "undefined":
        return e;
    case "object":
        return e;
    default:
        return ""
    }
}
function fs(e) {
    var t = e.type;
    return (e = e.nodeName) && e.toLowerCase() === "input" && (t === "checkbox" || t === "radio")
}
function Dc(e) {
    var t = fs(e) ? "checked" : "value"
      , n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t)
      , r = "" + e[t];
    if (!e.hasOwnProperty(t) && typeof n < "u" && typeof n.get == "function" && typeof n.set == "function") {
        var l = n.get
          , o = n.set;
        return Object.defineProperty(e, t, {
            configurable: !0,
            get: function() {
                return l.call(this)
            },
            set: function(i) {
                r = "" + i,
                o.call(this, i)
            }
        }),
        Object.defineProperty(e, t, {
            enumerable: n.enumerable
        }),
        {
            getValue: function() {
                return r
            },
            setValue: function(i) {
                r = "" + i
            },
            stopTracking: function() {
                e._valueTracker = null,
                delete e[t]
            }
        }
    }
}
function sr(e) {
    e._valueTracker || (e._valueTracker = Dc(e))
}
function ds(e) {
    if (!e)
        return !1;
    var t = e._valueTracker;
    if (!t)
        return !0;
    var n = t.getValue()
      , r = "";
    return e && (r = fs(e) ? e.checked ? "true" : "false" : e.value),
    e = r,
    e !== n ? (t.setValue(e),
    !0) : !1
}
function Dr(e) {
    if (e = e || (typeof document < "u" ? document : void 0),
    typeof e > "u")
        return null;
    try {
        return e.activeElement || e.body
    } catch {
        return e.body
    }
}
function to(e, t) {
    var n = t.checked;
    return G({}, t, {
        defaultChecked: void 0,
        defaultValue: void 0,
        value: void 0,
        checked: n ?? e._wrapperState.initialChecked
    })
}
function Hi(e, t) {
    var n = t.defaultValue == null ? "" : t.defaultValue
      , r = t.checked != null ? t.checked : t.defaultChecked;
    n = gt(t.value != null ? t.value : n),
    e._wrapperState = {
        initialChecked: r,
        initialValue: n,
        controlled: t.type === "checkbox" || t.type === "radio" ? t.checked != null : t.value != null
    }
}
function ps(e, t) {
    t = t.checked,
    t != null && Go(e, "checked", t, !1)
}
function no(e, t) {
    ps(e, t);
    var n = gt(t.value)
      , r = t.type;
    if (n != null)
        r === "number" ? (n === 0 && e.value === "" || e.value != n) && (e.value = "" + n) : e.value !== "" + n && (e.value = "" + n);
    else if (r === "submit" || r === "reset") {
        e.removeAttribute("value");
        return
    }
    t.hasOwnProperty("value") ? ro(e, t.type, n) : t.hasOwnProperty("defaultValue") && ro(e, t.type, gt(t.defaultValue)),
    t.checked == null && t.defaultChecked != null && (e.defaultChecked = !!t.defaultChecked)
}
function Wi(e, t, n) {
    if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
        var r = t.type;
        if (!(r !== "submit" && r !== "reset" || t.value !== void 0 && t.value !== null))
            return;
        t = "" + e._wrapperState.initialValue,
        n || t === e.value || (e.value = t),
        e.defaultValue = t
    }
    n = e.name,
    n !== "" && (e.name = ""),
    e.defaultChecked = !!e._wrapperState.initialChecked,
    n !== "" && (e.name = n)
}
function ro(e, t, n) {
    (t !== "number" || Dr(e.ownerDocument) !== e) && (n == null ? e.defaultValue = "" + e._wrapperState.initialValue : e.defaultValue !== "" + n && (e.defaultValue = "" + n))
}
var Nn = Array.isArray;
function bt(e, t, n, r) {
    if (e = e.options,
    t) {
        t = {};
        for (var l = 0; l < n.length; l++)
            t["$" + n[l]] = !0;
        for (n = 0; n < e.length; n++)
            l = t.hasOwnProperty("$" + e[n].value),
            e[n].selected !== l && (e[n].selected = l),
            l && r && (e[n].defaultSelected = !0)
    } else {
        for (n = "" + gt(n),
        t = null,
        l = 0; l < e.length; l++) {
            if (e[l].value === n) {
                e[l].selected = !0,
                r && (e[l].defaultSelected = !0);
                return
            }
            t !== null || e[l].disabled || (t = e[l])
        }
        t !== null && (t.selected = !0)
    }
}
function lo(e, t) {
    if (t.dangerouslySetInnerHTML != null)
        throw Error(g(91));
    return G({}, t, {
        value: void 0,
        defaultValue: void 0,
        children: "" + e._wrapperState.initialValue
    })
}
function Qi(e, t) {
    var n = t.value;
    if (n == null) {
        if (n = t.children,
        t = t.defaultValue,
        n != null) {
            if (t != null)
                throw Error(g(92));
            if (Nn(n)) {
                if (1 < n.length)
                    throw Error(g(93));
                n = n[0]
            }
            t = n
        }
        t == null && (t = ""),
        n = t
    }
    e._wrapperState = {
        initialValue: gt(n)
    }
}
function ms(e, t) {
    var n = gt(t.value)
      , r = gt(t.defaultValue);
    n != null && (n = "" + n,
    n !== e.value && (e.value = n),
    t.defaultValue == null && e.defaultValue !== n && (e.defaultValue = n)),
    r != null && (e.defaultValue = "" + r)
}
function Ki(e) {
    var t = e.textContent;
    t === e._wrapperState.initialValue && t !== "" && t !== null && (e.value = t)
}
function hs(e) {
    switch (e) {
    case "svg":
        return "http://www.w3.org/2000/svg";
    case "math":
        return "http://www.w3.org/1998/Math/MathML";
    default:
        return "http://www.w3.org/1999/xhtml"
    }
}
function oo(e, t) {
    return e == null || e === "http://www.w3.org/1999/xhtml" ? hs(t) : e === "http://www.w3.org/2000/svg" && t === "foreignObject" ? "http://www.w3.org/1999/xhtml" : e
}
var ar, vs = function(e) {
    return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction ? function(t, n, r, l) {
        MSApp.execUnsafeLocalFunction(function() {
            return e(t, n, r, l)
        })
    }
    : e
}(function(e, t) {
    if (e.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML"in e)
        e.innerHTML = t;
    else {
        for (ar = ar || document.createElement("div"),
        ar.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>",
        t = ar.firstChild; e.firstChild; )
            e.removeChild(e.firstChild);
        for (; t.firstChild; )
            e.appendChild(t.firstChild)
    }
});
function Un(e, t) {
    if (t) {
        var n = e.firstChild;
        if (n && n === e.lastChild && n.nodeType === 3) {
            n.nodeValue = t;
            return
        }
    }
    e.textContent = t
}
var jn = {
    animationIterationCount: !0,
    aspectRatio: !0,
    borderImageOutset: !0,
    borderImageSlice: !0,
    borderImageWidth: !0,
    boxFlex: !0,
    boxFlexGroup: !0,
    boxOrdinalGroup: !0,
    columnCount: !0,
    columns: !0,
    flex: !0,
    flexGrow: !0,
    flexPositive: !0,
    flexShrink: !0,
    flexNegative: !0,
    flexOrder: !0,
    gridArea: !0,
    gridRow: !0,
    gridRowEnd: !0,
    gridRowSpan: !0,
    gridRowStart: !0,
    gridColumn: !0,
    gridColumnEnd: !0,
    gridColumnSpan: !0,
    gridColumnStart: !0,
    fontWeight: !0,
    lineClamp: !0,
    lineHeight: !0,
    opacity: !0,
    order: !0,
    orphans: !0,
    tabSize: !0,
    widows: !0,
    zIndex: !0,
    zoom: !0,
    fillOpacity: !0,
    floodOpacity: !0,
    stopOpacity: !0,
    strokeDasharray: !0,
    strokeDashoffset: !0,
    strokeMiterlimit: !0,
    strokeOpacity: !0,
    strokeWidth: !0
}
  , Ic = ["Webkit", "ms", "Moz", "O"];
Object.keys(jn).forEach(function(e) {
    Ic.forEach(function(t) {
        t = t + e.charAt(0).toUpperCase() + e.substring(1),
        jn[t] = jn[e]
    })
});
function ys(e, t, n) {
    return t == null || typeof t == "boolean" || t === "" ? "" : n || typeof t != "number" || t === 0 || jn.hasOwnProperty(e) && jn[e] ? ("" + t).trim() : t + "px"
}
function gs(e, t) {
    e = e.style;
    for (var n in t)
        if (t.hasOwnProperty(n)) {
            var r = n.indexOf("--") === 0
              , l = ys(n, t[n], r);
            n === "float" && (n = "cssFloat"),
            r ? e.setProperty(n, l) : e[n] = l
        }
}
var Uc = G({
    menuitem: !0
}, {
    area: !0,
    base: !0,
    br: !0,
    col: !0,
    embed: !0,
    hr: !0,
    img: !0,
    input: !0,
    keygen: !0,
    link: !0,
    meta: !0,
    param: !0,
    source: !0,
    track: !0,
    wbr: !0
});
function io(e, t) {
    if (t) {
        if (Uc[e] && (t.children != null || t.dangerouslySetInnerHTML != null))
            throw Error(g(137, e));
        if (t.dangerouslySetInnerHTML != null) {
            if (t.children != null)
                throw Error(g(60));
            if (typeof t.dangerouslySetInnerHTML != "object" || !("__html"in t.dangerouslySetInnerHTML))
                throw Error(g(61))
        }
        if (t.style != null && typeof t.style != "object")
            throw Error(g(62))
    }
}
function uo(e, t) {
    if (e.indexOf("-") === -1)
        return typeof t.is == "string";
    switch (e) {
    case "annotation-xml":
    case "color-profile":
    case "font-face":
    case "font-face-src":
    case "font-face-uri":
    case "font-face-format":
    case "font-face-name":
    case "missing-glyph":
        return !1;
    default:
        return !0
    }
}
var so = null;
function bo(e) {
    return e = e.target || e.srcElement || window,
    e.correspondingUseElement && (e = e.correspondingUseElement),
    e.nodeType === 3 ? e.parentNode : e
}
var ao = null
  , en = null
  , tn = null;
function Yi(e) {
    if (e = rr(e)) {
        if (typeof ao != "function")
            throw Error(g(280));
        var t = e.stateNode;
        t && (t = fl(t),
        ao(e.stateNode, e.type, t))
    }
}
function ws(e) {
    en ? tn ? tn.push(e) : tn = [e] : en = e
}
function xs() {
    if (en) {
        var e = en
          , t = tn;
        if (tn = en = null,
        Yi(e),
        t)
            for (e = 0; e < t.length; e++)
                Yi(t[e])
    }
}
function ks(e, t) {
    return e(t)
}
function Ss() {}
var Pl = !1;
function Es(e, t, n) {
    if (Pl)
        return e(t, n);
    Pl = !0;
    try {
        return ks(e, t, n)
    } finally {
        Pl = !1,
        (en !== null || tn !== null) && (Ss(),
        xs())
    }
}
function An(e, t) {
    var n = e.stateNode;
    if (n === null)
        return null;
    var r = fl(n);
    if (r === null)
        return null;
    n = r[t];
    e: switch (t) {
    case "onClick":
    case "onClickCapture":
    case "onDoubleClick":
    case "onDoubleClickCapture":
    case "onMouseDown":
    case "onMouseDownCapture":
    case "onMouseMove":
    case "onMouseMoveCapture":
    case "onMouseUp":
    case "onMouseUpCapture":
    case "onMouseEnter":
        (r = !r.disabled) || (e = e.type,
        r = !(e === "button" || e === "input" || e === "select" || e === "textarea")),
        e = !r;
        break e;
    default:
        e = !1
    }
    if (e)
        return null;
    if (n && typeof n != "function")
        throw Error(g(231, t, typeof n));
    return n
}
var co = !1;
if (qe)
    try {
        var yn = {};
        Object.defineProperty(yn, "passive", {
            get: function() {
                co = !0
            }
        }),
        window.addEventListener("test", yn, yn),
        window.removeEventListener("test", yn, yn)
    } catch {
        co = !1
    }
function Ac(e, t, n, r, l, o, i, u, s) {
    var c = Array.prototype.slice.call(arguments, 3);
    try {
        t.apply(n, c)
    } catch (h) {
        this.onError(h)
    }
}
var zn = !1
  , Ir = null
  , Ur = !1
  , fo = null
  , $c = {
    onError: function(e) {
        zn = !0,
        Ir = e
    }
};
function Vc(e, t, n, r, l, o, i, u, s) {
    zn = !1,
    Ir = null,
    Ac.apply($c, arguments)
}
function Bc(e, t, n, r, l, o, i, u, s) {
    if (Vc.apply(this, arguments),
    zn) {
        if (zn) {
            var c = Ir;
            zn = !1,
            Ir = null
        } else
            throw Error(g(198));
        Ur || (Ur = !0,
        fo = c)
    }
}
function At(e) {
    var t = e
      , n = e;
    if (e.alternate)
        for (; t.return; )
            t = t.return;
    else {
        e = t;
        do
            t = e,
            t.flags & 4098 && (n = t.return),
            e = t.return;
        while (e)
    }
    return t.tag === 3 ? n : null
}
function Cs(e) {
    if (e.tag === 13) {
        var t = e.memoizedState;
        if (t === null && (e = e.alternate,
        e !== null && (t = e.memoizedState)),
        t !== null)
            return t.dehydrated
    }
    return null
}
function Xi(e) {
    if (At(e) !== e)
        throw Error(g(188))
}
function Hc(e) {
    var t = e.alternate;
    if (!t) {
        if (t = At(e),
        t === null)
            throw Error(g(188));
        return t !== e ? null : e
    }
    for (var n = e, r = t; ; ) {
        var l = n.return;
        if (l === null)
            break;
        var o = l.alternate;
        if (o === null) {
            if (r = l.return,
            r !== null) {
                n = r;
                continue
            }
            break
        }
        if (l.child === o.child) {
            for (o = l.child; o; ) {
                if (o === n)
                    return Xi(l),
                    e;
                if (o === r)
                    return Xi(l),
                    t;
                o = o.sibling
            }
            throw Error(g(188))
        }
        if (n.return !== r.return)
            n = l,
            r = o;
        else {
            for (var i = !1, u = l.child; u; ) {
                if (u === n) {
                    i = !0,
                    n = l,
                    r = o;
                    break
                }
                if (u === r) {
                    i = !0,
                    r = l,
                    n = o;
                    break
                }
                u = u.sibling
            }
            if (!i) {
                for (u = o.child; u; ) {
                    if (u === n) {
                        i = !0,
                        n = o,
                        r = l;
                        break
                    }
                    if (u === r) {
                        i = !0,
                        r = o,
                        n = l;
                        break
                    }
                    u = u.sibling
                }
                if (!i)
                    throw Error(g(189))
            }
        }
        if (n.alternate !== r)
            throw Error(g(190))
    }
    if (n.tag !== 3)
        throw Error(g(188));
    return n.stateNode.current === n ? e : t
}
function Ns(e) {
    return e = Hc(e),
    e !== null ? _s(e) : null
}
function _s(e) {
    if (e.tag === 5 || e.tag === 6)
        return e;
    for (e = e.child; e !== null; ) {
        var t = _s(e);
        if (t !== null)
            return t;
        e = e.sibling
    }
    return null
}
var Ps = Ne.unstable_scheduleCallback
  , Gi = Ne.unstable_cancelCallback
  , Wc = Ne.unstable_shouldYield
  , Qc = Ne.unstable_requestPaint
  , J = Ne.unstable_now
  , Kc = Ne.unstable_getCurrentPriorityLevel
  , ei = Ne.unstable_ImmediatePriority
  , js = Ne.unstable_UserBlockingPriority
  , Ar = Ne.unstable_NormalPriority
  , Yc = Ne.unstable_LowPriority
  , zs = Ne.unstable_IdlePriority
  , ul = null
  , Qe = null;
function Xc(e) {
    if (Qe && typeof Qe.onCommitFiberRoot == "function")
        try {
            Qe.onCommitFiberRoot(ul, e, void 0, (e.current.flags & 128) === 128)
        } catch {}
}
var Ae = Math.clz32 ? Math.clz32 : Jc
  , Gc = Math.log
  , Zc = Math.LN2;
function Jc(e) {
    return e >>>= 0,
    e === 0 ? 32 : 31 - (Gc(e) / Zc | 0) | 0
}
var cr = 64
  , fr = 4194304;
function _n(e) {
    switch (e & -e) {
    case 1:
        return 1;
    case 2:
        return 2;
    case 4:
        return 4;
    case 8:
        return 8;
    case 16:
        return 16;
    case 32:
        return 32;
    case 64:
    case 128:
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
    case 8192:
    case 16384:
    case 32768:
    case 65536:
    case 131072:
    case 262144:
    case 524288:
    case 1048576:
    case 2097152:
        return e & 4194240;
    case 4194304:
    case 8388608:
    case 16777216:
    case 33554432:
    case 67108864:
        return e & 130023424;
    case 134217728:
        return 134217728;
    case 268435456:
        return 268435456;
    case 536870912:
        return 536870912;
    case 1073741824:
        return 1073741824;
    default:
        return e
    }
}
function $r(e, t) {
    var n = e.pendingLanes;
    if (n === 0)
        return 0;
    var r = 0
      , l = e.suspendedLanes
      , o = e.pingedLanes
      , i = n & 268435455;
    if (i !== 0) {
        var u = i & ~l;
        u !== 0 ? r = _n(u) : (o &= i,
        o !== 0 && (r = _n(o)))
    } else
        i = n & ~l,
        i !== 0 ? r = _n(i) : o !== 0 && (r = _n(o));
    if (r === 0)
        return 0;
    if (t !== 0 && t !== r && !(t & l) && (l = r & -r,
    o = t & -t,
    l >= o || l === 16 && (o & 4194240) !== 0))
        return t;
    if (r & 4 && (r |= n & 16),
    t = e.entangledLanes,
    t !== 0)
        for (e = e.entanglements,
        t &= r; 0 < t; )
            n = 31 - Ae(t),
            l = 1 << n,
            r |= e[n],
            t &= ~l;
    return r
}
function qc(e, t) {
    switch (e) {
    case 1:
    case 2:
    case 4:
        return t + 250;
    case 8:
    case 16:
    case 32:
    case 64:
    case 128:
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
    case 8192:
    case 16384:
    case 32768:
    case 65536:
    case 131072:
    case 262144:
    case 524288:
    case 1048576:
    case 2097152:
        return t + 5e3;
    case 4194304:
    case 8388608:
    case 16777216:
    case 33554432:
    case 67108864:
        return -1;
    case 134217728:
    case 268435456:
    case 536870912:
    case 1073741824:
        return -1;
    default:
        return -1
    }
}
function bc(e, t) {
    for (var n = e.suspendedLanes, r = e.pingedLanes, l = e.expirationTimes, o = e.pendingLanes; 0 < o; ) {
        var i = 31 - Ae(o)
          , u = 1 << i
          , s = l[i];
        s === -1 ? (!(u & n) || u & r) && (l[i] = qc(u, t)) : s <= t && (e.expiredLanes |= u),
        o &= ~u
    }
}
function po(e) {
    return e = e.pendingLanes & -1073741825,
    e !== 0 ? e : e & 1073741824 ? 1073741824 : 0
}
function Ls() {
    var e = cr;
    return cr <<= 1,
    !(cr & 4194240) && (cr = 64),
    e
}
function jl(e) {
    for (var t = [], n = 0; 31 > n; n++)
        t.push(e);
    return t
}
function tr(e, t, n) {
    e.pendingLanes |= t,
    t !== 536870912 && (e.suspendedLanes = 0,
    e.pingedLanes = 0),
    e = e.eventTimes,
    t = 31 - Ae(t),
    e[t] = n
}
function ef(e, t) {
    var n = e.pendingLanes & ~t;
    e.pendingLanes = t,
    e.suspendedLanes = 0,
    e.pingedLanes = 0,
    e.expiredLanes &= t,
    e.mutableReadLanes &= t,
    e.entangledLanes &= t,
    t = e.entanglements;
    var r = e.eventTimes;
    for (e = e.expirationTimes; 0 < n; ) {
        var l = 31 - Ae(n)
          , o = 1 << l;
        t[l] = 0,
        r[l] = -1,
        e[l] = -1,
        n &= ~o
    }
}
function ti(e, t) {
    var n = e.entangledLanes |= t;
    for (e = e.entanglements; n; ) {
        var r = 31 - Ae(n)
          , l = 1 << r;
        l & t | e[r] & t && (e[r] |= t),
        n &= ~l
    }
}
var O = 0;
function Ts(e) {
    return e &= -e,
    1 < e ? 4 < e ? e & 268435455 ? 16 : 536870912 : 4 : 1
}
var Rs, ni, Ms, Fs, Os, mo = !1, dr = [], ct = null, ft = null, dt = null, $n = new Map, Vn = new Map, it = [], tf = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
function Zi(e, t) {
    switch (e) {
    case "focusin":
    case "focusout":
        ct = null;
        break;
    case "dragenter":
    case "dragleave":
        ft = null;
        break;
    case "mouseover":
    case "mouseout":
        dt = null;
        break;
    case "pointerover":
    case "pointerout":
        $n.delete(t.pointerId);
        break;
    case "gotpointercapture":
    case "lostpointercapture":
        Vn.delete(t.pointerId)
    }
}
function gn(e, t, n, r, l, o) {
    return e === null || e.nativeEvent !== o ? (e = {
        blockedOn: t,
        domEventName: n,
        eventSystemFlags: r,
        nativeEvent: o,
        targetContainers: [l]
    },
    t !== null && (t = rr(t),
    t !== null && ni(t)),
    e) : (e.eventSystemFlags |= r,
    t = e.targetContainers,
    l !== null && t.indexOf(l) === -1 && t.push(l),
    e)
}
function nf(e, t, n, r, l) {
    switch (t) {
    case "focusin":
        return ct = gn(ct, e, t, n, r, l),
        !0;
    case "dragenter":
        return ft = gn(ft, e, t, n, r, l),
        !0;
    case "mouseover":
        return dt = gn(dt, e, t, n, r, l),
        !0;
    case "pointerover":
        var o = l.pointerId;
        return $n.set(o, gn($n.get(o) || null, e, t, n, r, l)),
        !0;
    case "gotpointercapture":
        return o = l.pointerId,
        Vn.set(o, gn(Vn.get(o) || null, e, t, n, r, l)),
        !0
    }
    return !1
}
function Ds(e) {
    var t = jt(e.target);
    if (t !== null) {
        var n = At(t);
        if (n !== null) {
            if (t = n.tag,
            t === 13) {
                if (t = Cs(n),
                t !== null) {
                    e.blockedOn = t,
                    Os(e.priority, function() {
                        Ms(n)
                    });
                    return
                }
            } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
                e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
                return
            }
        }
    }
    e.blockedOn = null
}
function _r(e) {
    if (e.blockedOn !== null)
        return !1;
    for (var t = e.targetContainers; 0 < t.length; ) {
        var n = ho(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
        if (n === null) {
            n = e.nativeEvent;
            var r = new n.constructor(n.type,n);
            so = r,
            n.target.dispatchEvent(r),
            so = null
        } else
            return t = rr(n),
            t !== null && ni(t),
            e.blockedOn = n,
            !1;
        t.shift()
    }
    return !0
}
function Ji(e, t, n) {
    _r(e) && n.delete(t)
}
function rf() {
    mo = !1,
    ct !== null && _r(ct) && (ct = null),
    ft !== null && _r(ft) && (ft = null),
    dt !== null && _r(dt) && (dt = null),
    $n.forEach(Ji),
    Vn.forEach(Ji)
}
function wn(e, t) {
    e.blockedOn === t && (e.blockedOn = null,
    mo || (mo = !0,
    Ne.unstable_scheduleCallback(Ne.unstable_NormalPriority, rf)))
}
function Bn(e) {
    function t(l) {
        return wn(l, e)
    }
    if (0 < dr.length) {
        wn(dr[0], e);
        for (var n = 1; n < dr.length; n++) {
            var r = dr[n];
            r.blockedOn === e && (r.blockedOn = null)
        }
    }
    for (ct !== null && wn(ct, e),
    ft !== null && wn(ft, e),
    dt !== null && wn(dt, e),
    $n.forEach(t),
    Vn.forEach(t),
    n = 0; n < it.length; n++)
        r = it[n],
        r.blockedOn === e && (r.blockedOn = null);
    for (; 0 < it.length && (n = it[0],
    n.blockedOn === null); )
        Ds(n),
        n.blockedOn === null && it.shift()
}
var nn = nt.ReactCurrentBatchConfig
  , Vr = !0;
function lf(e, t, n, r) {
    var l = O
      , o = nn.transition;
    nn.transition = null;
    try {
        O = 1,
        ri(e, t, n, r)
    } finally {
        O = l,
        nn.transition = o
    }
}
function of(e, t, n, r) {
    var l = O
      , o = nn.transition;
    nn.transition = null;
    try {
        O = 4,
        ri(e, t, n, r)
    } finally {
        O = l,
        nn.transition = o
    }
}
function ri(e, t, n, r) {
    if (Vr) {
        var l = ho(e, t, n, r);
        if (l === null)
            Ul(e, t, r, Br, n),
            Zi(e, r);
        else if (nf(l, e, t, n, r))
            r.stopPropagation();
        else if (Zi(e, r),
        t & 4 && -1 < tf.indexOf(e)) {
            for (; l !== null; ) {
                var o = rr(l);
                if (o !== null && Rs(o),
                o = ho(e, t, n, r),
                o === null && Ul(e, t, r, Br, n),
                o === l)
                    break;
                l = o
            }
            l !== null && r.stopPropagation()
        } else
            Ul(e, t, r, null, n)
    }
}
var Br = null;
function ho(e, t, n, r) {
    if (Br = null,
    e = bo(r),
    e = jt(e),
    e !== null)
        if (t = At(e),
        t === null)
            e = null;
        else if (n = t.tag,
        n === 13) {
            if (e = Cs(t),
            e !== null)
                return e;
            e = null
        } else if (n === 3) {
            if (t.stateNode.current.memoizedState.isDehydrated)
                return t.tag === 3 ? t.stateNode.containerInfo : null;
            e = null
        } else
            t !== e && (e = null);
    return Br = e,
    null
}
function Is(e) {
    switch (e) {
    case "cancel":
    case "click":
    case "close":
    case "contextmenu":
    case "copy":
    case "cut":
    case "auxclick":
    case "dblclick":
    case "dragend":
    case "dragstart":
    case "drop":
    case "focusin":
    case "focusout":
    case "input":
    case "invalid":
    case "keydown":
    case "keypress":
    case "keyup":
    case "mousedown":
    case "mouseup":
    case "paste":
    case "pause":
    case "play":
    case "pointercancel":
    case "pointerdown":
    case "pointerup":
    case "ratechange":
    case "reset":
    case "resize":
    case "seeked":
    case "submit":
    case "touchcancel":
    case "touchend":
    case "touchstart":
    case "volumechange":
    case "change":
    case "selectionchange":
    case "textInput":
    case "compositionstart":
    case "compositionend":
    case "compositionupdate":
    case "beforeblur":
    case "afterblur":
    case "beforeinput":
    case "blur":
    case "fullscreenchange":
    case "focus":
    case "hashchange":
    case "popstate":
    case "select":
    case "selectstart":
        return 1;
    case "drag":
    case "dragenter":
    case "dragexit":
    case "dragleave":
    case "dragover":
    case "mousemove":
    case "mouseout":
    case "mouseover":
    case "pointermove":
    case "pointerout":
    case "pointerover":
    case "scroll":
    case "toggle":
    case "touchmove":
    case "wheel":
    case "mouseenter":
    case "mouseleave":
    case "pointerenter":
    case "pointerleave":
        return 4;
    case "message":
        switch (Kc()) {
        case ei:
            return 1;
        case js:
            return 4;
        case Ar:
        case Yc:
            return 16;
        case zs:
            return 536870912;
        default:
            return 16
        }
    default:
        return 16
    }
}
var st = null
  , li = null
  , Pr = null;
function Us() {
    if (Pr)
        return Pr;
    var e, t = li, n = t.length, r, l = "value"in st ? st.value : st.textContent, o = l.length;
    for (e = 0; e < n && t[e] === l[e]; e++)
        ;
    var i = n - e;
    for (r = 1; r <= i && t[n - r] === l[o - r]; r++)
        ;
    return Pr = l.slice(e, 1 < r ? 1 - r : void 0)
}
function jr(e) {
    var t = e.keyCode;
    return "charCode"in e ? (e = e.charCode,
    e === 0 && t === 13 && (e = 13)) : e = t,
    e === 10 && (e = 13),
    32 <= e || e === 13 ? e : 0
}
function pr() {
    return !0
}
function qi() {
    return !1
}
function Pe(e) {
    function t(n, r, l, o, i) {
        this._reactName = n,
        this._targetInst = l,
        this.type = r,
        this.nativeEvent = o,
        this.target = i,
        this.currentTarget = null;
        for (var u in e)
            e.hasOwnProperty(u) && (n = e[u],
            this[u] = n ? n(o) : o[u]);
        return this.isDefaultPrevented = (o.defaultPrevented != null ? o.defaultPrevented : o.returnValue === !1) ? pr : qi,
        this.isPropagationStopped = qi,
        this
    }
    return G(t.prototype, {
        preventDefault: function() {
            this.defaultPrevented = !0;
            var n = this.nativeEvent;
            n && (n.preventDefault ? n.preventDefault() : typeof n.returnValue != "unknown" && (n.returnValue = !1),
            this.isDefaultPrevented = pr)
        },
        stopPropagation: function() {
            var n = this.nativeEvent;
            n && (n.stopPropagation ? n.stopPropagation() : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0),
            this.isPropagationStopped = pr)
        },
        persist: function() {},
        isPersistent: pr
    }),
    t
}
var mn = {
    eventPhase: 0,
    bubbles: 0,
    cancelable: 0,
    timeStamp: function(e) {
        return e.timeStamp || Date.now()
    },
    defaultPrevented: 0,
    isTrusted: 0
}, oi = Pe(mn), nr = G({}, mn, {
    view: 0,
    detail: 0
}), uf = Pe(nr), zl, Ll, xn, sl = G({}, nr, {
    screenX: 0,
    screenY: 0,
    clientX: 0,
    clientY: 0,
    pageX: 0,
    pageY: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    getModifierState: ii,
    button: 0,
    buttons: 0,
    relatedTarget: function(e) {
        return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget
    },
    movementX: function(e) {
        return "movementX"in e ? e.movementX : (e !== xn && (xn && e.type === "mousemove" ? (zl = e.screenX - xn.screenX,
        Ll = e.screenY - xn.screenY) : Ll = zl = 0,
        xn = e),
        zl)
    },
    movementY: function(e) {
        return "movementY"in e ? e.movementY : Ll
    }
}), bi = Pe(sl), sf = G({}, sl, {
    dataTransfer: 0
}), af = Pe(sf), cf = G({}, nr, {
    relatedTarget: 0
}), Tl = Pe(cf), ff = G({}, mn, {
    animationName: 0,
    elapsedTime: 0,
    pseudoElement: 0
}), df = Pe(ff), pf = G({}, mn, {
    clipboardData: function(e) {
        return "clipboardData"in e ? e.clipboardData : window.clipboardData
    }
}), mf = Pe(pf), hf = G({}, mn, {
    data: 0
}), eu = Pe(hf), vf = {
    Esc: "Escape",
    Spacebar: " ",
    Left: "ArrowLeft",
    Up: "ArrowUp",
    Right: "ArrowRight",
    Down: "ArrowDown",
    Del: "Delete",
    Win: "OS",
    Menu: "ContextMenu",
    Apps: "ContextMenu",
    Scroll: "ScrollLock",
    MozPrintableKey: "Unidentified"
}, yf = {
    8: "Backspace",
    9: "Tab",
    12: "Clear",
    13: "Enter",
    16: "Shift",
    17: "Control",
    18: "Alt",
    19: "Pause",
    20: "CapsLock",
    27: "Escape",
    32: " ",
    33: "PageUp",
    34: "PageDown",
    35: "End",
    36: "Home",
    37: "ArrowLeft",
    38: "ArrowUp",
    39: "ArrowRight",
    40: "ArrowDown",
    45: "Insert",
    46: "Delete",
    112: "F1",
    113: "F2",
    114: "F3",
    115: "F4",
    116: "F5",
    117: "F6",
    118: "F7",
    119: "F8",
    120: "F9",
    121: "F10",
    122: "F11",
    123: "F12",
    144: "NumLock",
    145: "ScrollLock",
    224: "Meta"
}, gf = {
    Alt: "altKey",
    Control: "ctrlKey",
    Meta: "metaKey",
    Shift: "shiftKey"
};
function wf(e) {
    var t = this.nativeEvent;
    return t.getModifierState ? t.getModifierState(e) : (e = gf[e]) ? !!t[e] : !1
}
function ii() {
    return wf
}
var xf = G({}, nr, {
    key: function(e) {
        if (e.key) {
            var t = vf[e.key] || e.key;
            if (t !== "Unidentified")
                return t
        }
        return e.type === "keypress" ? (e = jr(e),
        e === 13 ? "Enter" : String.fromCharCode(e)) : e.type === "keydown" || e.type === "keyup" ? yf[e.keyCode] || "Unidentified" : ""
    },
    code: 0,
    location: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    repeat: 0,
    locale: 0,
    getModifierState: ii,
    charCode: function(e) {
        return e.type === "keypress" ? jr(e) : 0
    },
    keyCode: function(e) {
        return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0
    },
    which: function(e) {
        return e.type === "keypress" ? jr(e) : e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0
    }
})
  , kf = Pe(xf)
  , Sf = G({}, sl, {
    pointerId: 0,
    width: 0,
    height: 0,
    pressure: 0,
    tangentialPressure: 0,
    tiltX: 0,
    tiltY: 0,
    twist: 0,
    pointerType: 0,
    isPrimary: 0
})
  , tu = Pe(Sf)
  , Ef = G({}, nr, {
    touches: 0,
    targetTouches: 0,
    changedTouches: 0,
    altKey: 0,
    metaKey: 0,
    ctrlKey: 0,
    shiftKey: 0,
    getModifierState: ii
})
  , Cf = Pe(Ef)
  , Nf = G({}, mn, {
    propertyName: 0,
    elapsedTime: 0,
    pseudoElement: 0
})
  , _f = Pe(Nf)
  , Pf = G({}, sl, {
    deltaX: function(e) {
        return "deltaX"in e ? e.deltaX : "wheelDeltaX"in e ? -e.wheelDeltaX : 0
    },
    deltaY: function(e) {
        return "deltaY"in e ? e.deltaY : "wheelDeltaY"in e ? -e.wheelDeltaY : "wheelDelta"in e ? -e.wheelDelta : 0
    },
    deltaZ: 0,
    deltaMode: 0
})
  , jf = Pe(Pf)
  , zf = [9, 13, 27, 32]
  , ui = qe && "CompositionEvent"in window
  , Ln = null;
qe && "documentMode"in document && (Ln = document.documentMode);
var Lf = qe && "TextEvent"in window && !Ln
  , As = qe && (!ui || Ln && 8 < Ln && 11 >= Ln)
  , nu = " "
  , ru = !1;
function $s(e, t) {
    switch (e) {
    case "keyup":
        return zf.indexOf(t.keyCode) !== -1;
    case "keydown":
        return t.keyCode !== 229;
    case "keypress":
    case "mousedown":
    case "focusout":
        return !0;
    default:
        return !1
    }
}
function Vs(e) {
    return e = e.detail,
    typeof e == "object" && "data"in e ? e.data : null
}
var Ht = !1;
function Tf(e, t) {
    switch (e) {
    case "compositionend":
        return Vs(t);
    case "keypress":
        return t.which !== 32 ? null : (ru = !0,
        nu);
    case "textInput":
        return e = t.data,
        e === nu && ru ? null : e;
    default:
        return null
    }
}
function Rf(e, t) {
    if (Ht)
        return e === "compositionend" || !ui && $s(e, t) ? (e = Us(),
        Pr = li = st = null,
        Ht = !1,
        e) : null;
    switch (e) {
    case "paste":
        return null;
    case "keypress":
        if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
            if (t.char && 1 < t.char.length)
                return t.char;
            if (t.which)
                return String.fromCharCode(t.which)
        }
        return null;
    case "compositionend":
        return As && t.locale !== "ko" ? null : t.data;
    default:
        return null
    }
}
var Mf = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0
};
function lu(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t === "input" ? !!Mf[e.type] : t === "textarea"
}
function Bs(e, t, n, r) {
    ws(r),
    t = Hr(t, "onChange"),
    0 < t.length && (n = new oi("onChange","change",null,n,r),
    e.push({
        event: n,
        listeners: t
    }))
}
var Tn = null
  , Hn = null;
function Ff(e) {
    bs(e, 0)
}
function al(e) {
    var t = Kt(e);
    if (ds(t))
        return e
}
function Of(e, t) {
    if (e === "change")
        return t
}
var Hs = !1;
if (qe) {
    var Rl;
    if (qe) {
        var Ml = "oninput"in document;
        if (!Ml) {
            var ou = document.createElement("div");
            ou.setAttribute("oninput", "return;"),
            Ml = typeof ou.oninput == "function"
        }
        Rl = Ml
    } else
        Rl = !1;
    Hs = Rl && (!document.documentMode || 9 < document.documentMode)
}
function iu() {
    Tn && (Tn.detachEvent("onpropertychange", Ws),
    Hn = Tn = null)
}
function Ws(e) {
    if (e.propertyName === "value" && al(Hn)) {
        var t = [];
        Bs(t, Hn, e, bo(e)),
        Es(Ff, t)
    }
}
function Df(e, t, n) {
    e === "focusin" ? (iu(),
    Tn = t,
    Hn = n,
    Tn.attachEvent("onpropertychange", Ws)) : e === "focusout" && iu()
}
function If(e) {
    if (e === "selectionchange" || e === "keyup" || e === "keydown")
        return al(Hn)
}
function Uf(e, t) {
    if (e === "click")
        return al(t)
}
function Af(e, t) {
    if (e === "input" || e === "change")
        return al(t)
}
function $f(e, t) {
    return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t
}
var Ve = typeof Object.is == "function" ? Object.is : $f;
function Wn(e, t) {
    if (Ve(e, t))
        return !0;
    if (typeof e != "object" || e === null || typeof t != "object" || t === null)
        return !1;
    var n = Object.keys(e)
      , r = Object.keys(t);
    if (n.length !== r.length)
        return !1;
    for (r = 0; r < n.length; r++) {
        var l = n[r];
        if (!Zl.call(t, l) || !Ve(e[l], t[l]))
            return !1
    }
    return !0
}
function uu(e) {
    for (; e && e.firstChild; )
        e = e.firstChild;
    return e
}
function su(e, t) {
    var n = uu(e);
    e = 0;
    for (var r; n; ) {
        if (n.nodeType === 3) {
            if (r = e + n.textContent.length,
            e <= t && r >= t)
                return {
                    node: n,
                    offset: t - e
                };
            e = r
        }
        e: {
            for (; n; ) {
                if (n.nextSibling) {
                    n = n.nextSibling;
                    break e
                }
                n = n.parentNode
            }
            n = void 0
        }
        n = uu(n)
    }
}
function Qs(e, t) {
    return e && t ? e === t ? !0 : e && e.nodeType === 3 ? !1 : t && t.nodeType === 3 ? Qs(e, t.parentNode) : "contains"in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : !1 : !1
}
function Ks() {
    for (var e = window, t = Dr(); t instanceof e.HTMLIFrameElement; ) {
        try {
            var n = typeof t.contentWindow.location.href == "string"
        } catch {
            n = !1
        }
        if (n)
            e = t.contentWindow;
        else
            break;
        t = Dr(e.document)
    }
    return t
}
function si(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t && (t === "input" && (e.type === "text" || e.type === "search" || e.type === "tel" || e.type === "url" || e.type === "password") || t === "textarea" || e.contentEditable === "true")
}
function Vf(e) {
    var t = Ks()
      , n = e.focusedElem
      , r = e.selectionRange;
    if (t !== n && n && n.ownerDocument && Qs(n.ownerDocument.documentElement, n)) {
        if (r !== null && si(n)) {
            if (t = r.start,
            e = r.end,
            e === void 0 && (e = t),
            "selectionStart"in n)
                n.selectionStart = t,
                n.selectionEnd = Math.min(e, n.value.length);
            else if (e = (t = n.ownerDocument || document) && t.defaultView || window,
            e.getSelection) {
                e = e.getSelection();
                var l = n.textContent.length
                  , o = Math.min(r.start, l);
                r = r.end === void 0 ? o : Math.min(r.end, l),
                !e.extend && o > r && (l = r,
                r = o,
                o = l),
                l = su(n, o);
                var i = su(n, r);
                l && i && (e.rangeCount !== 1 || e.anchorNode !== l.node || e.anchorOffset !== l.offset || e.focusNode !== i.node || e.focusOffset !== i.offset) && (t = t.createRange(),
                t.setStart(l.node, l.offset),
                e.removeAllRanges(),
                o > r ? (e.addRange(t),
                e.extend(i.node, i.offset)) : (t.setEnd(i.node, i.offset),
                e.addRange(t)))
            }
        }
        for (t = [],
        e = n; e = e.parentNode; )
            e.nodeType === 1 && t.push({
                element: e,
                left: e.scrollLeft,
                top: e.scrollTop
            });
        for (typeof n.focus == "function" && n.focus(),
        n = 0; n < t.length; n++)
            e = t[n],
            e.element.scrollLeft = e.left,
            e.element.scrollTop = e.top
    }
}
var Bf = qe && "documentMode"in document && 11 >= document.documentMode
  , Wt = null
  , vo = null
  , Rn = null
  , yo = !1;
function au(e, t, n) {
    var r = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
    yo || Wt == null || Wt !== Dr(r) || (r = Wt,
    "selectionStart"in r && si(r) ? r = {
        start: r.selectionStart,
        end: r.selectionEnd
    } : (r = (r.ownerDocument && r.ownerDocument.defaultView || window).getSelection(),
    r = {
        anchorNode: r.anchorNode,
        anchorOffset: r.anchorOffset,
        focusNode: r.focusNode,
        focusOffset: r.focusOffset
    }),
    Rn && Wn(Rn, r) || (Rn = r,
    r = Hr(vo, "onSelect"),
    0 < r.length && (t = new oi("onSelect","select",null,t,n),
    e.push({
        event: t,
        listeners: r
    }),
    t.target = Wt)))
}
function mr(e, t) {
    var n = {};
    return n[e.toLowerCase()] = t.toLowerCase(),
    n["Webkit" + e] = "webkit" + t,
    n["Moz" + e] = "moz" + t,
    n
}
var Qt = {
    animationend: mr("Animation", "AnimationEnd"),
    animationiteration: mr("Animation", "AnimationIteration"),
    animationstart: mr("Animation", "AnimationStart"),
    transitionend: mr("Transition", "TransitionEnd")
}
  , Fl = {}
  , Ys = {};
qe && (Ys = document.createElement("div").style,
"AnimationEvent"in window || (delete Qt.animationend.animation,
delete Qt.animationiteration.animation,
delete Qt.animationstart.animation),
"TransitionEvent"in window || delete Qt.transitionend.transition);
function cl(e) {
    if (Fl[e])
        return Fl[e];
    if (!Qt[e])
        return e;
    var t = Qt[e], n;
    for (n in t)
        if (t.hasOwnProperty(n) && n in Ys)
            return Fl[e] = t[n];
    return e
}
var Xs = cl("animationend")
  , Gs = cl("animationiteration")
  , Zs = cl("animationstart")
  , Js = cl("transitionend")
  , qs = new Map
  , cu = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
function xt(e, t) {
    qs.set(e, t),
    Ut(t, [e])
}
for (var Ol = 0; Ol < cu.length; Ol++) {
    var Dl = cu[Ol]
      , Hf = Dl.toLowerCase()
      , Wf = Dl[0].toUpperCase() + Dl.slice(1);
    xt(Hf, "on" + Wf)
}
xt(Xs, "onAnimationEnd");
xt(Gs, "onAnimationIteration");
xt(Zs, "onAnimationStart");
xt("dblclick", "onDoubleClick");
xt("focusin", "onFocus");
xt("focusout", "onBlur");
xt(Js, "onTransitionEnd");
on("onMouseEnter", ["mouseout", "mouseover"]);
on("onMouseLeave", ["mouseout", "mouseover"]);
on("onPointerEnter", ["pointerout", "pointerover"]);
on("onPointerLeave", ["pointerout", "pointerover"]);
Ut("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
Ut("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
Ut("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
Ut("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
Ut("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
Ut("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
var Pn = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" ")
  , Qf = new Set("cancel close invalid load scroll toggle".split(" ").concat(Pn));
function fu(e, t, n) {
    var r = e.type || "unknown-event";
    e.currentTarget = n,
    Bc(r, t, void 0, e),
    e.currentTarget = null
}
function bs(e, t) {
    t = (t & 4) !== 0;
    for (var n = 0; n < e.length; n++) {
        var r = e[n]
          , l = r.event;
        r = r.listeners;
        e: {
            var o = void 0;
            if (t)
                for (var i = r.length - 1; 0 <= i; i--) {
                    var u = r[i]
                      , s = u.instance
                      , c = u.currentTarget;
                    if (u = u.listener,
                    s !== o && l.isPropagationStopped())
                        break e;
                    fu(l, u, c),
                    o = s
                }
            else
                for (i = 0; i < r.length; i++) {
                    if (u = r[i],
                    s = u.instance,
                    c = u.currentTarget,
                    u = u.listener,
                    s !== o && l.isPropagationStopped())
                        break e;
                    fu(l, u, c),
                    o = s
                }
        }
    }
    if (Ur)
        throw e = fo,
        Ur = !1,
        fo = null,
        e
}
function V(e, t) {
    var n = t[So];
    n === void 0 && (n = t[So] = new Set);
    var r = e + "__bubble";
    n.has(r) || (ea(t, e, 2, !1),
    n.add(r))
}
function Il(e, t, n) {
    var r = 0;
    t && (r |= 4),
    ea(n, e, r, t)
}
var hr = "_reactListening" + Math.random().toString(36).slice(2);
function Qn(e) {
    if (!e[hr]) {
        e[hr] = !0,
        us.forEach(function(n) {
            n !== "selectionchange" && (Qf.has(n) || Il(n, !1, e),
            Il(n, !0, e))
        });
        var t = e.nodeType === 9 ? e : e.ownerDocument;
        t === null || t[hr] || (t[hr] = !0,
        Il("selectionchange", !1, t))
    }
}
function ea(e, t, n, r) {
    switch (Is(t)) {
    case 1:
        var l = lf;
        break;
    case 4:
        l = of;
        break;
    default:
        l = ri
    }
    n = l.bind(null, t, n, e),
    l = void 0,
    !co || t !== "touchstart" && t !== "touchmove" && t !== "wheel" || (l = !0),
    r ? l !== void 0 ? e.addEventListener(t, n, {
        capture: !0,
        passive: l
    }) : e.addEventListener(t, n, !0) : l !== void 0 ? e.addEventListener(t, n, {
        passive: l
    }) : e.addEventListener(t, n, !1)
}
function Ul(e, t, n, r, l) {
    var o = r;
    if (!(t & 1) && !(t & 2) && r !== null)
        e: for (; ; ) {
            if (r === null)
                return;
            var i = r.tag;
            if (i === 3 || i === 4) {
                var u = r.stateNode.containerInfo;
                if (u === l || u.nodeType === 8 && u.parentNode === l)
                    break;
                if (i === 4)
                    for (i = r.return; i !== null; ) {
                        var s = i.tag;
                        if ((s === 3 || s === 4) && (s = i.stateNode.containerInfo,
                        s === l || s.nodeType === 8 && s.parentNode === l))
                            return;
                        i = i.return
                    }
                for (; u !== null; ) {
                    if (i = jt(u),
                    i === null)
                        return;
                    if (s = i.tag,
                    s === 5 || s === 6) {
                        r = o = i;
                        continue e
                    }
                    u = u.parentNode
                }
            }
            r = r.return
        }
    Es(function() {
        var c = o
          , h = bo(n)
          , m = [];
        e: {
            var p = qs.get(e);
            if (p !== void 0) {
                var w = oi
                  , k = e;
                switch (e) {
                case "keypress":
                    if (jr(n) === 0)
                        break e;
                case "keydown":
                case "keyup":
                    w = kf;
                    break;
                case "focusin":
                    k = "focus",
                    w = Tl;
                    break;
                case "focusout":
                    k = "blur",
                    w = Tl;
                    break;
                case "beforeblur":
                case "afterblur":
                    w = Tl;
                    break;
                case "click":
                    if (n.button === 2)
                        break e;
                case "auxclick":
                case "dblclick":
                case "mousedown":
                case "mousemove":
                case "mouseup":
                case "mouseout":
                case "mouseover":
                case "contextmenu":
                    w = bi;
                    break;
                case "drag":
                case "dragend":
                case "dragenter":
                case "dragexit":
                case "dragleave":
                case "dragover":
                case "dragstart":
                case "drop":
                    w = af;
                    break;
                case "touchcancel":
                case "touchend":
                case "touchmove":
                case "touchstart":
                    w = Cf;
                    break;
                case Xs:
                case Gs:
                case Zs:
                    w = df;
                    break;
                case Js:
                    w = _f;
                    break;
                case "scroll":
                    w = uf;
                    break;
                case "wheel":
                    w = jf;
                    break;
                case "copy":
                case "cut":
                case "paste":
                    w = mf;
                    break;
                case "gotpointercapture":
                case "lostpointercapture":
                case "pointercancel":
                case "pointerdown":
                case "pointermove":
                case "pointerout":
                case "pointerover":
                case "pointerup":
                    w = tu
                }
                var S = (t & 4) !== 0
                  , D = !S && e === "scroll"
                  , f = S ? p !== null ? p + "Capture" : null : p;
                S = [];
                for (var a = c, d; a !== null; ) {
                    d = a;
                    var y = d.stateNode;
                    if (d.tag === 5 && y !== null && (d = y,
                    f !== null && (y = An(a, f),
                    y != null && S.push(Kn(a, y, d)))),
                    D)
                        break;
                    a = a.return
                }
                0 < S.length && (p = new w(p,k,null,n,h),
                m.push({
                    event: p,
                    listeners: S
                }))
            }
        }
        if (!(t & 7)) {
            e: {
                if (p = e === "mouseover" || e === "pointerover",
                w = e === "mouseout" || e === "pointerout",
                p && n !== so && (k = n.relatedTarget || n.fromElement) && (jt(k) || k[be]))
                    break e;
                if ((w || p) && (p = h.window === h ? h : (p = h.ownerDocument) ? p.defaultView || p.parentWindow : window,
                w ? (k = n.relatedTarget || n.toElement,
                w = c,
                k = k ? jt(k) : null,
                k !== null && (D = At(k),
                k !== D || k.tag !== 5 && k.tag !== 6) && (k = null)) : (w = null,
                k = c),
                w !== k)) {
                    if (S = bi,
                    y = "onMouseLeave",
                    f = "onMouseEnter",
                    a = "mouse",
                    (e === "pointerout" || e === "pointerover") && (S = tu,
                    y = "onPointerLeave",
                    f = "onPointerEnter",
                    a = "pointer"),
                    D = w == null ? p : Kt(w),
                    d = k == null ? p : Kt(k),
                    p = new S(y,a + "leave",w,n,h),
                    p.target = D,
                    p.relatedTarget = d,
                    y = null,
                    jt(h) === c && (S = new S(f,a + "enter",k,n,h),
                    S.target = d,
                    S.relatedTarget = D,
                    y = S),
                    D = y,
                    w && k)
                        t: {
                            for (S = w,
                            f = k,
                            a = 0,
                            d = S; d; d = $t(d))
                                a++;
                            for (d = 0,
                            y = f; y; y = $t(y))
                                d++;
                            for (; 0 < a - d; )
                                S = $t(S),
                                a--;
                            for (; 0 < d - a; )
                                f = $t(f),
                                d--;
                            for (; a--; ) {
                                if (S === f || f !== null && S === f.alternate)
                                    break t;
                                S = $t(S),
                                f = $t(f)
                            }
                            S = null
                        }
                    else
                        S = null;
                    w !== null && du(m, p, w, S, !1),
                    k !== null && D !== null && du(m, D, k, S, !0)
                }
            }
            e: {
                if (p = c ? Kt(c) : window,
                w = p.nodeName && p.nodeName.toLowerCase(),
                w === "select" || w === "input" && p.type === "file")
                    var E = Of;
                else if (lu(p))
                    if (Hs)
                        E = Af;
                    else {
                        E = If;
                        var _ = Df
                    }
                else
                    (w = p.nodeName) && w.toLowerCase() === "input" && (p.type === "checkbox" || p.type === "radio") && (E = Uf);
                if (E && (E = E(e, c))) {
                    Bs(m, E, n, h);
                    break e
                }
                _ && _(e, p, c),
                e === "focusout" && (_ = p._wrapperState) && _.controlled && p.type === "number" && ro(p, "number", p.value)
            }
            switch (_ = c ? Kt(c) : window,
            e) {
            case "focusin":
                (lu(_) || _.contentEditable === "true") && (Wt = _,
                vo = c,
                Rn = null);
                break;
            case "focusout":
                Rn = vo = Wt = null;
                break;
            case "mousedown":
                yo = !0;
                break;
            case "contextmenu":
            case "mouseup":
            case "dragend":
                yo = !1,
                au(m, n, h);
                break;
            case "selectionchange":
                if (Bf)
                    break;
            case "keydown":
            case "keyup":
                au(m, n, h)
            }
            var N;
            if (ui)
                e: {
                    switch (e) {
                    case "compositionstart":
                        var j = "onCompositionStart";
                        break e;
                    case "compositionend":
                        j = "onCompositionEnd";
                        break e;
                    case "compositionupdate":
                        j = "onCompositionUpdate";
                        break e
                    }
                    j = void 0
                }
            else
                Ht ? $s(e, n) && (j = "onCompositionEnd") : e === "keydown" && n.keyCode === 229 && (j = "onCompositionStart");
            j && (As && n.locale !== "ko" && (Ht || j !== "onCompositionStart" ? j === "onCompositionEnd" && Ht && (N = Us()) : (st = h,
            li = "value"in st ? st.value : st.textContent,
            Ht = !0)),
            _ = Hr(c, j),
            0 < _.length && (j = new eu(j,e,null,n,h),
            m.push({
                event: j,
                listeners: _
            }),
            N ? j.data = N : (N = Vs(n),
            N !== null && (j.data = N)))),
            (N = Lf ? Tf(e, n) : Rf(e, n)) && (c = Hr(c, "onBeforeInput"),
            0 < c.length && (h = new eu("onBeforeInput","beforeinput",null,n,h),
            m.push({
                event: h,
                listeners: c
            }),
            h.data = N))
        }
        bs(m, t)
    })
}
function Kn(e, t, n) {
    return {
        instance: e,
        listener: t,
        currentTarget: n
    }
}
function Hr(e, t) {
    for (var n = t + "Capture", r = []; e !== null; ) {
        var l = e
          , o = l.stateNode;
        l.tag === 5 && o !== null && (l = o,
        o = An(e, n),
        o != null && r.unshift(Kn(e, o, l)),
        o = An(e, t),
        o != null && r.push(Kn(e, o, l))),
        e = e.return
    }
    return r
}
function $t(e) {
    if (e === null)
        return null;
    do
        e = e.return;
    while (e && e.tag !== 5);
    return e || null
}
function du(e, t, n, r, l) {
    for (var o = t._reactName, i = []; n !== null && n !== r; ) {
        var u = n
          , s = u.alternate
          , c = u.stateNode;
        if (s !== null && s === r)
            break;
        u.tag === 5 && c !== null && (u = c,
        l ? (s = An(n, o),
        s != null && i.unshift(Kn(n, s, u))) : l || (s = An(n, o),
        s != null && i.push(Kn(n, s, u)))),
        n = n.return
    }
    i.length !== 0 && e.push({
        event: t,
        listeners: i
    })
}
var Kf = /\r\n?/g
  , Yf = /\u0000|\uFFFD/g;
function pu(e) {
    return (typeof e == "string" ? e : "" + e).replace(Kf, `
`).replace(Yf, "")
}
function vr(e, t, n) {
    if (t = pu(t),
    pu(e) !== t && n)
        throw Error(g(425))
}
function Wr() {}
var go = null
  , wo = null;
function xo(e, t) {
    return e === "textarea" || e === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null
}
var ko = typeof setTimeout == "function" ? setTimeout : void 0
  , Xf = typeof clearTimeout == "function" ? clearTimeout : void 0
  , mu = typeof Promise == "function" ? Promise : void 0
  , Gf = typeof queueMicrotask == "function" ? queueMicrotask : typeof mu < "u" ? function(e) {
    return mu.resolve(null).then(e).catch(Zf)
}
: ko;
function Zf(e) {
    setTimeout(function() {
        throw e
    })
}
function Al(e, t) {
    var n = t
      , r = 0;
    do {
        var l = n.nextSibling;
        if (e.removeChild(n),
        l && l.nodeType === 8)
            if (n = l.data,
            n === "/$") {
                if (r === 0) {
                    e.removeChild(l),
                    Bn(t);
                    return
                }
                r--
            } else
                n !== "$" && n !== "$?" && n !== "$!" || r++;
        n = l
    } while (n);
    Bn(t)
}
function pt(e) {
    for (; e != null; e = e.nextSibling) {
        var t = e.nodeType;
        if (t === 1 || t === 3)
            break;
        if (t === 8) {
            if (t = e.data,
            t === "$" || t === "$!" || t === "$?")
                break;
            if (t === "/$")
                return null
        }
    }
    return e
}
function hu(e) {
    e = e.previousSibling;
    for (var t = 0; e; ) {
        if (e.nodeType === 8) {
            var n = e.data;
            if (n === "$" || n === "$!" || n === "$?") {
                if (t === 0)
                    return e;
                t--
            } else
                n === "/$" && t++
        }
        e = e.previousSibling
    }
    return null
}
var hn = Math.random().toString(36).slice(2)
  , We = "__reactFiber$" + hn
  , Yn = "__reactProps$" + hn
  , be = "__reactContainer$" + hn
  , So = "__reactEvents$" + hn
  , Jf = "__reactListeners$" + hn
  , qf = "__reactHandles$" + hn;
function jt(e) {
    var t = e[We];
    if (t)
        return t;
    for (var n = e.parentNode; n; ) {
        if (t = n[be] || n[We]) {
            if (n = t.alternate,
            t.child !== null || n !== null && n.child !== null)
                for (e = hu(e); e !== null; ) {
                    if (n = e[We])
                        return n;
                    e = hu(e)
                }
            return t
        }
        e = n,
        n = e.parentNode
    }
    return null
}
function rr(e) {
    return e = e[We] || e[be],
    !e || e.tag !== 5 && e.tag !== 6 && e.tag !== 13 && e.tag !== 3 ? null : e
}
function Kt(e) {
    if (e.tag === 5 || e.tag === 6)
        return e.stateNode;
    throw Error(g(33))
}
function fl(e) {
    return e[Yn] || null
}
var Eo = []
  , Yt = -1;
function kt(e) {
    return {
        current: e
    }
}
function B(e) {
    0 > Yt || (e.current = Eo[Yt],
    Eo[Yt] = null,
    Yt--)
}
function A(e, t) {
    Yt++,
    Eo[Yt] = e.current,
    e.current = t
}
var wt = {}
  , ce = kt(wt)
  , ye = kt(!1)
  , Mt = wt;
function un(e, t) {
    var n = e.type.contextTypes;
    if (!n)
        return wt;
    var r = e.stateNode;
    if (r && r.__reactInternalMemoizedUnmaskedChildContext === t)
        return r.__reactInternalMemoizedMaskedChildContext;
    var l = {}, o;
    for (o in n)
        l[o] = t[o];
    return r && (e = e.stateNode,
    e.__reactInternalMemoizedUnmaskedChildContext = t,
    e.__reactInternalMemoizedMaskedChildContext = l),
    l
}
function ge(e) {
    return e = e.childContextTypes,
    e != null
}
function Qr() {
    B(ye),
    B(ce)
}
function vu(e, t, n) {
    if (ce.current !== wt)
        throw Error(g(168));
    A(ce, t),
    A(ye, n)
}
function ta(e, t, n) {
    var r = e.stateNode;
    if (t = t.childContextTypes,
    typeof r.getChildContext != "function")
        return n;
    r = r.getChildContext();
    for (var l in r)
        if (!(l in t))
            throw Error(g(108, Oc(e) || "Unknown", l));
    return G({}, n, r)
}
function Kr(e) {
    return e = (e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext || wt,
    Mt = ce.current,
    A(ce, e),
    A(ye, ye.current),
    !0
}
function yu(e, t, n) {
    var r = e.stateNode;
    if (!r)
        throw Error(g(169));
    n ? (e = ta(e, t, Mt),
    r.__reactInternalMemoizedMergedChildContext = e,
    B(ye),
    B(ce),
    A(ce, e)) : B(ye),
    A(ye, n)
}
var Xe = null
  , dl = !1
  , $l = !1;
function na(e) {
    Xe === null ? Xe = [e] : Xe.push(e)
}
function bf(e) {
    dl = !0,
    na(e)
}
function St() {
    if (!$l && Xe !== null) {
        $l = !0;
        var e = 0
          , t = O;
        try {
            var n = Xe;
            for (O = 1; e < n.length; e++) {
                var r = n[e];
                do
                    r = r(!0);
                while (r !== null)
            }
            Xe = null,
            dl = !1
        } catch (l) {
            throw Xe !== null && (Xe = Xe.slice(e + 1)),
            Ps(ei, St),
            l
        } finally {
            O = t,
            $l = !1
        }
    }
    return null
}
var Xt = []
  , Gt = 0
  , Yr = null
  , Xr = 0
  , je = []
  , ze = 0
  , Ft = null
  , Ge = 1
  , Ze = "";
function _t(e, t) {
    Xt[Gt++] = Xr,
    Xt[Gt++] = Yr,
    Yr = e,
    Xr = t
}
function ra(e, t, n) {
    je[ze++] = Ge,
    je[ze++] = Ze,
    je[ze++] = Ft,
    Ft = e;
    var r = Ge;
    e = Ze;
    var l = 32 - Ae(r) - 1;
    r &= ~(1 << l),
    n += 1;
    var o = 32 - Ae(t) + l;
    if (30 < o) {
        var i = l - l % 5;
        o = (r & (1 << i) - 1).toString(32),
        r >>= i,
        l -= i,
        Ge = 1 << 32 - Ae(t) + l | n << l | r,
        Ze = o + e
    } else
        Ge = 1 << o | n << l | r,
        Ze = e
}
function ai(e) {
    e.return !== null && (_t(e, 1),
    ra(e, 1, 0))
}
function ci(e) {
    for (; e === Yr; )
        Yr = Xt[--Gt],
        Xt[Gt] = null,
        Xr = Xt[--Gt],
        Xt[Gt] = null;
    for (; e === Ft; )
        Ft = je[--ze],
        je[ze] = null,
        Ze = je[--ze],
        je[ze] = null,
        Ge = je[--ze],
        je[ze] = null
}
var Ce = null
  , Ee = null
  , Q = !1
  , Ue = null;
function la(e, t) {
    var n = Le(5, null, null, 0);
    n.elementType = "DELETED",
    n.stateNode = t,
    n.return = e,
    t = e.deletions,
    t === null ? (e.deletions = [n],
    e.flags |= 16) : t.push(n)
}
function gu(e, t) {
    switch (e.tag) {
    case 5:
        var n = e.type;
        return t = t.nodeType !== 1 || n.toLowerCase() !== t.nodeName.toLowerCase() ? null : t,
        t !== null ? (e.stateNode = t,
        Ce = e,
        Ee = pt(t.firstChild),
        !0) : !1;
    case 6:
        return t = e.pendingProps === "" || t.nodeType !== 3 ? null : t,
        t !== null ? (e.stateNode = t,
        Ce = e,
        Ee = null,
        !0) : !1;
    case 13:
        return t = t.nodeType !== 8 ? null : t,
        t !== null ? (n = Ft !== null ? {
            id: Ge,
            overflow: Ze
        } : null,
        e.memoizedState = {
            dehydrated: t,
            treeContext: n,
            retryLane: 1073741824
        },
        n = Le(18, null, null, 0),
        n.stateNode = t,
        n.return = e,
        e.child = n,
        Ce = e,
        Ee = null,
        !0) : !1;
    default:
        return !1
    }
}
function Co(e) {
    return (e.mode & 1) !== 0 && (e.flags & 128) === 0
}
function No(e) {
    if (Q) {
        var t = Ee;
        if (t) {
            var n = t;
            if (!gu(e, t)) {
                if (Co(e))
                    throw Error(g(418));
                t = pt(n.nextSibling);
                var r = Ce;
                t && gu(e, t) ? la(r, n) : (e.flags = e.flags & -4097 | 2,
                Q = !1,
                Ce = e)
            }
        } else {
            if (Co(e))
                throw Error(g(418));
            e.flags = e.flags & -4097 | 2,
            Q = !1,
            Ce = e
        }
    }
}
function wu(e) {
    for (e = e.return; e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13; )
        e = e.return;
    Ce = e
}
function yr(e) {
    if (e !== Ce)
        return !1;
    if (!Q)
        return wu(e),
        Q = !0,
        !1;
    var t;
    if ((t = e.tag !== 3) && !(t = e.tag !== 5) && (t = e.type,
    t = t !== "head" && t !== "body" && !xo(e.type, e.memoizedProps)),
    t && (t = Ee)) {
        if (Co(e))
            throw oa(),
            Error(g(418));
        for (; t; )
            la(e, t),
            t = pt(t.nextSibling)
    }
    if (wu(e),
    e.tag === 13) {
        if (e = e.memoizedState,
        e = e !== null ? e.dehydrated : null,
        !e)
            throw Error(g(317));
        e: {
            for (e = e.nextSibling,
            t = 0; e; ) {
                if (e.nodeType === 8) {
                    var n = e.data;
                    if (n === "/$") {
                        if (t === 0) {
                            Ee = pt(e.nextSibling);
                            break e
                        }
                        t--
                    } else
                        n !== "$" && n !== "$!" && n !== "$?" || t++
                }
                e = e.nextSibling
            }
            Ee = null
        }
    } else
        Ee = Ce ? pt(e.stateNode.nextSibling) : null;
    return !0
}
function oa() {
    for (var e = Ee; e; )
        e = pt(e.nextSibling)
}
function sn() {
    Ee = Ce = null,
    Q = !1
}
function fi(e) {
    Ue === null ? Ue = [e] : Ue.push(e)
}
var ed = nt.ReactCurrentBatchConfig;
function kn(e, t, n) {
    if (e = n.ref,
    e !== null && typeof e != "function" && typeof e != "object") {
        if (n._owner) {
            if (n = n._owner,
            n) {
                if (n.tag !== 1)
                    throw Error(g(309));
                var r = n.stateNode
            }
            if (!r)
                throw Error(g(147, e));
            var l = r
              , o = "" + e;
            return t !== null && t.ref !== null && typeof t.ref == "function" && t.ref._stringRef === o ? t.ref : (t = function(i) {
                var u = l.refs;
                i === null ? delete u[o] : u[o] = i
            }
            ,
            t._stringRef = o,
            t)
        }
        if (typeof e != "string")
            throw Error(g(284));
        if (!n._owner)
            throw Error(g(290, e))
    }
    return e
}
function gr(e, t) {
    throw e = Object.prototype.toString.call(t),
    Error(g(31, e === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : e))
}
function xu(e) {
    var t = e._init;
    return t(e._payload)
}
function ia(e) {
    function t(f, a) {
        if (e) {
            var d = f.deletions;
            d === null ? (f.deletions = [a],
            f.flags |= 16) : d.push(a)
        }
    }
    function n(f, a) {
        if (!e)
            return null;
        for (; a !== null; )
            t(f, a),
            a = a.sibling;
        return null
    }
    function r(f, a) {
        for (f = new Map; a !== null; )
            a.key !== null ? f.set(a.key, a) : f.set(a.index, a),
            a = a.sibling;
        return f
    }
    function l(f, a) {
        return f = yt(f, a),
        f.index = 0,
        f.sibling = null,
        f
    }
    function o(f, a, d) {
        return f.index = d,
        e ? (d = f.alternate,
        d !== null ? (d = d.index,
        d < a ? (f.flags |= 2,
        a) : d) : (f.flags |= 2,
        a)) : (f.flags |= 1048576,
        a)
    }
    function i(f) {
        return e && f.alternate === null && (f.flags |= 2),
        f
    }
    function u(f, a, d, y) {
        return a === null || a.tag !== 6 ? (a = Yl(d, f.mode, y),
        a.return = f,
        a) : (a = l(a, d),
        a.return = f,
        a)
    }
    function s(f, a, d, y) {
        var E = d.type;
        return E === Bt ? h(f, a, d.props.children, y, d.key) : a !== null && (a.elementType === E || typeof E == "object" && E !== null && E.$$typeof === lt && xu(E) === a.type) ? (y = l(a, d.props),
        y.ref = kn(f, a, d),
        y.return = f,
        y) : (y = Or(d.type, d.key, d.props, null, f.mode, y),
        y.ref = kn(f, a, d),
        y.return = f,
        y)
    }
    function c(f, a, d, y) {
        return a === null || a.tag !== 4 || a.stateNode.containerInfo !== d.containerInfo || a.stateNode.implementation !== d.implementation ? (a = Xl(d, f.mode, y),
        a.return = f,
        a) : (a = l(a, d.children || []),
        a.return = f,
        a)
    }
    function h(f, a, d, y, E) {
        return a === null || a.tag !== 7 ? (a = Rt(d, f.mode, y, E),
        a.return = f,
        a) : (a = l(a, d),
        a.return = f,
        a)
    }
    function m(f, a, d) {
        if (typeof a == "string" && a !== "" || typeof a == "number")
            return a = Yl("" + a, f.mode, d),
            a.return = f,
            a;
        if (typeof a == "object" && a !== null) {
            switch (a.$$typeof) {
            case ur:
                return d = Or(a.type, a.key, a.props, null, f.mode, d),
                d.ref = kn(f, null, a),
                d.return = f,
                d;
            case Vt:
                return a = Xl(a, f.mode, d),
                a.return = f,
                a;
            case lt:
                var y = a._init;
                return m(f, y(a._payload), d)
            }
            if (Nn(a) || vn(a))
                return a = Rt(a, f.mode, d, null),
                a.return = f,
                a;
            gr(f, a)
        }
        return null
    }
    function p(f, a, d, y) {
        var E = a !== null ? a.key : null;
        if (typeof d == "string" && d !== "" || typeof d == "number")
            return E !== null ? null : u(f, a, "" + d, y);
        if (typeof d == "object" && d !== null) {
            switch (d.$$typeof) {
            case ur:
                return d.key === E ? s(f, a, d, y) : null;
            case Vt:
                return d.key === E ? c(f, a, d, y) : null;
            case lt:
                return E = d._init,
                p(f, a, E(d._payload), y)
            }
            if (Nn(d) || vn(d))
                return E !== null ? null : h(f, a, d, y, null);
            gr(f, d)
        }
        return null
    }
    function w(f, a, d, y, E) {
        if (typeof y == "string" && y !== "" || typeof y == "number")
            return f = f.get(d) || null,
            u(a, f, "" + y, E);
        if (typeof y == "object" && y !== null) {
            switch (y.$$typeof) {
            case ur:
                return f = f.get(y.key === null ? d : y.key) || null,
                s(a, f, y, E);
            case Vt:
                return f = f.get(y.key === null ? d : y.key) || null,
                c(a, f, y, E);
            case lt:
                var _ = y._init;
                return w(f, a, d, _(y._payload), E)
            }
            if (Nn(y) || vn(y))
                return f = f.get(d) || null,
                h(a, f, y, E, null);
            gr(a, y)
        }
        return null
    }
    function k(f, a, d, y) {
        for (var E = null, _ = null, N = a, j = a = 0, H = null; N !== null && j < d.length; j++) {
            N.index > j ? (H = N,
            N = null) : H = N.sibling;
            var R = p(f, N, d[j], y);
            if (R === null) {
                N === null && (N = H);
                break
            }
            e && N && R.alternate === null && t(f, N),
            a = o(R, a, j),
            _ === null ? E = R : _.sibling = R,
            _ = R,
            N = H
        }
        if (j === d.length)
            return n(f, N),
            Q && _t(f, j),
            E;
        if (N === null) {
            for (; j < d.length; j++)
                N = m(f, d[j], y),
                N !== null && (a = o(N, a, j),
                _ === null ? E = N : _.sibling = N,
                _ = N);
            return Q && _t(f, j),
            E
        }
        for (N = r(f, N); j < d.length; j++)
            H = w(N, f, j, d[j], y),
            H !== null && (e && H.alternate !== null && N.delete(H.key === null ? j : H.key),
            a = o(H, a, j),
            _ === null ? E = H : _.sibling = H,
            _ = H);
        return e && N.forEach(function(xe) {
            return t(f, xe)
        }),
        Q && _t(f, j),
        E
    }
    function S(f, a, d, y) {
        var E = vn(d);
        if (typeof E != "function")
            throw Error(g(150));
        if (d = E.call(d),
        d == null)
            throw Error(g(151));
        for (var _ = E = null, N = a, j = a = 0, H = null, R = d.next(); N !== null && !R.done; j++,
        R = d.next()) {
            N.index > j ? (H = N,
            N = null) : H = N.sibling;
            var xe = p(f, N, R.value, y);
            if (xe === null) {
                N === null && (N = H);
                break
            }
            e && N && xe.alternate === null && t(f, N),
            a = o(xe, a, j),
            _ === null ? E = xe : _.sibling = xe,
            _ = xe,
            N = H
        }
        if (R.done)
            return n(f, N),
            Q && _t(f, j),
            E;
        if (N === null) {
            for (; !R.done; j++,
            R = d.next())
                R = m(f, R.value, y),
                R !== null && (a = o(R, a, j),
                _ === null ? E = R : _.sibling = R,
                _ = R);
            return Q && _t(f, j),
            E
        }
        for (N = r(f, N); !R.done; j++,
        R = d.next())
            R = w(N, f, j, R.value, y),
            R !== null && (e && R.alternate !== null && N.delete(R.key === null ? j : R.key),
            a = o(R, a, j),
            _ === null ? E = R : _.sibling = R,
            _ = R);
        return e && N.forEach(function(P) {
            return t(f, P)
        }),
        Q && _t(f, j),
        E
    }
    function D(f, a, d, y) {
        if (typeof d == "object" && d !== null && d.type === Bt && d.key === null && (d = d.props.children),
        typeof d == "object" && d !== null) {
            switch (d.$$typeof) {
            case ur:
                e: {
                    for (var E = d.key, _ = a; _ !== null; ) {
                        if (_.key === E) {
                            if (E = d.type,
                            E === Bt) {
                                if (_.tag === 7) {
                                    n(f, _.sibling),
                                    a = l(_, d.props.children),
                                    a.return = f,
                                    f = a;
                                    break e
                                }
                            } else if (_.elementType === E || typeof E == "object" && E !== null && E.$$typeof === lt && xu(E) === _.type) {
                                n(f, _.sibling),
                                a = l(_, d.props),
                                a.ref = kn(f, _, d),
                                a.return = f,
                                f = a;
                                break e
                            }
                            n(f, _);
                            break
                        } else
                            t(f, _);
                        _ = _.sibling
                    }
                    d.type === Bt ? (a = Rt(d.props.children, f.mode, y, d.key),
                    a.return = f,
                    f = a) : (y = Or(d.type, d.key, d.props, null, f.mode, y),
                    y.ref = kn(f, a, d),
                    y.return = f,
                    f = y)
                }
                return i(f);
            case Vt:
                e: {
                    for (_ = d.key; a !== null; ) {
                        if (a.key === _)
                            if (a.tag === 4 && a.stateNode.containerInfo === d.containerInfo && a.stateNode.implementation === d.implementation) {
                                n(f, a.sibling),
                                a = l(a, d.children || []),
                                a.return = f,
                                f = a;
                                break e
                            } else {
                                n(f, a);
                                break
                            }
                        else
                            t(f, a);
                        a = a.sibling
                    }
                    a = Xl(d, f.mode, y),
                    a.return = f,
                    f = a
                }
                return i(f);
            case lt:
                return _ = d._init,
                D(f, a, _(d._payload), y)
            }
            if (Nn(d))
                return k(f, a, d, y);
            if (vn(d))
                return S(f, a, d, y);
            gr(f, d)
        }
        return typeof d == "string" && d !== "" || typeof d == "number" ? (d = "" + d,
        a !== null && a.tag === 6 ? (n(f, a.sibling),
        a = l(a, d),
        a.return = f,
        f = a) : (n(f, a),
        a = Yl(d, f.mode, y),
        a.return = f,
        f = a),
        i(f)) : n(f, a)
    }
    return D
}
var an = ia(!0)
  , ua = ia(!1)
  , Gr = kt(null)
  , Zr = null
  , Zt = null
  , di = null;
function pi() {
    di = Zt = Zr = null
}
function mi(e) {
    var t = Gr.current;
    B(Gr),
    e._currentValue = t
}
function _o(e, t, n) {
    for (; e !== null; ) {
        var r = e.alternate;
        if ((e.childLanes & t) !== t ? (e.childLanes |= t,
        r !== null && (r.childLanes |= t)) : r !== null && (r.childLanes & t) !== t && (r.childLanes |= t),
        e === n)
            break;
        e = e.return
    }
}
function rn(e, t) {
    Zr = e,
    di = Zt = null,
    e = e.dependencies,
    e !== null && e.firstContext !== null && (e.lanes & t && (ve = !0),
    e.firstContext = null)
}
function Re(e) {
    var t = e._currentValue;
    if (di !== e)
        if (e = {
            context: e,
            memoizedValue: t,
            next: null
        },
        Zt === null) {
            if (Zr === null)
                throw Error(g(308));
            Zt = e,
            Zr.dependencies = {
                lanes: 0,
                firstContext: e
            }
        } else
            Zt = Zt.next = e;
    return t
}
var zt = null;
function hi(e) {
    zt === null ? zt = [e] : zt.push(e)
}
function sa(e, t, n, r) {
    var l = t.interleaved;
    return l === null ? (n.next = n,
    hi(t)) : (n.next = l.next,
    l.next = n),
    t.interleaved = n,
    et(e, r)
}
function et(e, t) {
    e.lanes |= t;
    var n = e.alternate;
    for (n !== null && (n.lanes |= t),
    n = e,
    e = e.return; e !== null; )
        e.childLanes |= t,
        n = e.alternate,
        n !== null && (n.childLanes |= t),
        n = e,
        e = e.return;
    return n.tag === 3 ? n.stateNode : null
}
var ot = !1;
function vi(e) {
    e.updateQueue = {
        baseState: e.memoizedState,
        firstBaseUpdate: null,
        lastBaseUpdate: null,
        shared: {
            pending: null,
            interleaved: null,
            lanes: 0
        },
        effects: null
    }
}
function aa(e, t) {
    e = e.updateQueue,
    t.updateQueue === e && (t.updateQueue = {
        baseState: e.baseState,
        firstBaseUpdate: e.firstBaseUpdate,
        lastBaseUpdate: e.lastBaseUpdate,
        shared: e.shared,
        effects: e.effects
    })
}
function Je(e, t) {
    return {
        eventTime: e,
        lane: t,
        tag: 0,
        payload: null,
        callback: null,
        next: null
    }
}
function mt(e, t, n) {
    var r = e.updateQueue;
    if (r === null)
        return null;
    if (r = r.shared,
    F & 2) {
        var l = r.pending;
        return l === null ? t.next = t : (t.next = l.next,
        l.next = t),
        r.pending = t,
        et(e, n)
    }
    return l = r.interleaved,
    l === null ? (t.next = t,
    hi(r)) : (t.next = l.next,
    l.next = t),
    r.interleaved = t,
    et(e, n)
}
function zr(e, t, n) {
    if (t = t.updateQueue,
    t !== null && (t = t.shared,
    (n & 4194240) !== 0)) {
        var r = t.lanes;
        r &= e.pendingLanes,
        n |= r,
        t.lanes = n,
        ti(e, n)
    }
}
function ku(e, t) {
    var n = e.updateQueue
      , r = e.alternate;
    if (r !== null && (r = r.updateQueue,
    n === r)) {
        var l = null
          , o = null;
        if (n = n.firstBaseUpdate,
        n !== null) {
            do {
                var i = {
                    eventTime: n.eventTime,
                    lane: n.lane,
                    tag: n.tag,
                    payload: n.payload,
                    callback: n.callback,
                    next: null
                };
                o === null ? l = o = i : o = o.next = i,
                n = n.next
            } while (n !== null);
            o === null ? l = o = t : o = o.next = t
        } else
            l = o = t;
        n = {
            baseState: r.baseState,
            firstBaseUpdate: l,
            lastBaseUpdate: o,
            shared: r.shared,
            effects: r.effects
        },
        e.updateQueue = n;
        return
    }
    e = n.lastBaseUpdate,
    e === null ? n.firstBaseUpdate = t : e.next = t,
    n.lastBaseUpdate = t
}
function Jr(e, t, n, r) {
    var l = e.updateQueue;
    ot = !1;
    var o = l.firstBaseUpdate
      , i = l.lastBaseUpdate
      , u = l.shared.pending;
    if (u !== null) {
        l.shared.pending = null;
        var s = u
          , c = s.next;
        s.next = null,
        i === null ? o = c : i.next = c,
        i = s;
        var h = e.alternate;
        h !== null && (h = h.updateQueue,
        u = h.lastBaseUpdate,
        u !== i && (u === null ? h.firstBaseUpdate = c : u.next = c,
        h.lastBaseUpdate = s))
    }
    if (o !== null) {
        var m = l.baseState;
        i = 0,
        h = c = s = null,
        u = o;
        do {
            var p = u.lane
              , w = u.eventTime;
            if ((r & p) === p) {
                h !== null && (h = h.next = {
                    eventTime: w,
                    lane: 0,
                    tag: u.tag,
                    payload: u.payload,
                    callback: u.callback,
                    next: null
                });
                e: {
                    var k = e
                      , S = u;
                    switch (p = t,
                    w = n,
                    S.tag) {
                    case 1:
                        if (k = S.payload,
                        typeof k == "function") {
                            m = k.call(w, m, p);
                            break e
                        }
                        m = k;
                        break e;
                    case 3:
                        k.flags = k.flags & -65537 | 128;
                    case 0:
                        if (k = S.payload,
                        p = typeof k == "function" ? k.call(w, m, p) : k,
                        p == null)
                            break e;
                        m = G({}, m, p);
                        break e;
                    case 2:
                        ot = !0
                    }
                }
                u.callback !== null && u.lane !== 0 && (e.flags |= 64,
                p = l.effects,
                p === null ? l.effects = [u] : p.push(u))
            } else
                w = {
                    eventTime: w,
                    lane: p,
                    tag: u.tag,
                    payload: u.payload,
                    callback: u.callback,
                    next: null
                },
                h === null ? (c = h = w,
                s = m) : h = h.next = w,
                i |= p;
            if (u = u.next,
            u === null) {
                if (u = l.shared.pending,
                u === null)
                    break;
                p = u,
                u = p.next,
                p.next = null,
                l.lastBaseUpdate = p,
                l.shared.pending = null
            }
        } while (!0);
        if (h === null && (s = m),
        l.baseState = s,
        l.firstBaseUpdate = c,
        l.lastBaseUpdate = h,
        t = l.shared.interleaved,
        t !== null) {
            l = t;
            do
                i |= l.lane,
                l = l.next;
            while (l !== t)
        } else
            o === null && (l.shared.lanes = 0);
        Dt |= i,
        e.lanes = i,
        e.memoizedState = m
    }
}
function Su(e, t, n) {
    if (e = t.effects,
    t.effects = null,
    e !== null)
        for (t = 0; t < e.length; t++) {
            var r = e[t]
              , l = r.callback;
            if (l !== null) {
                if (r.callback = null,
                r = n,
                typeof l != "function")
                    throw Error(g(191, l));
                l.call(r)
            }
        }
}
var lr = {}
  , Ke = kt(lr)
  , Xn = kt(lr)
  , Gn = kt(lr);
function Lt(e) {
    if (e === lr)
        throw Error(g(174));
    return e
}
function yi(e, t) {
    switch (A(Gn, t),
    A(Xn, e),
    A(Ke, lr),
    e = t.nodeType,
    e) {
    case 9:
    case 11:
        t = (t = t.documentElement) ? t.namespaceURI : oo(null, "");
        break;
    default:
        e = e === 8 ? t.parentNode : t,
        t = e.namespaceURI || null,
        e = e.tagName,
        t = oo(t, e)
    }
    B(Ke),
    A(Ke, t)
}
function cn() {
    B(Ke),
    B(Xn),
    B(Gn)
}
function ca(e) {
    Lt(Gn.current);
    var t = Lt(Ke.current)
      , n = oo(t, e.type);
    t !== n && (A(Xn, e),
    A(Ke, n))
}
function gi(e) {
    Xn.current === e && (B(Ke),
    B(Xn))
}
var Y = kt(0);
function qr(e) {
    for (var t = e; t !== null; ) {
        if (t.tag === 13) {
            var n = t.memoizedState;
            if (n !== null && (n = n.dehydrated,
            n === null || n.data === "$?" || n.data === "$!"))
                return t
        } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
            if (t.flags & 128)
                return t
        } else if (t.child !== null) {
            t.child.return = t,
            t = t.child;
            continue
        }
        if (t === e)
            break;
        for (; t.sibling === null; ) {
            if (t.return === null || t.return === e)
                return null;
            t = t.return
        }
        t.sibling.return = t.return,
        t = t.sibling
    }
    return null
}
var Vl = [];
function wi() {
    for (var e = 0; e < Vl.length; e++)
        Vl[e]._workInProgressVersionPrimary = null;
    Vl.length = 0
}
var Lr = nt.ReactCurrentDispatcher
  , Bl = nt.ReactCurrentBatchConfig
  , Ot = 0
  , X = null
  , b = null
  , te = null
  , br = !1
  , Mn = !1
  , Zn = 0
  , td = 0;
function ie() {
    throw Error(g(321))
}
function xi(e, t) {
    if (t === null)
        return !1;
    for (var n = 0; n < t.length && n < e.length; n++)
        if (!Ve(e[n], t[n]))
            return !1;
    return !0
}
function ki(e, t, n, r, l, o) {
    if (Ot = o,
    X = t,
    t.memoizedState = null,
    t.updateQueue = null,
    t.lanes = 0,
    Lr.current = e === null || e.memoizedState === null ? od : id,
    e = n(r, l),
    Mn) {
        o = 0;
        do {
            if (Mn = !1,
            Zn = 0,
            25 <= o)
                throw Error(g(301));
            o += 1,
            te = b = null,
            t.updateQueue = null,
            Lr.current = ud,
            e = n(r, l)
        } while (Mn)
    }
    if (Lr.current = el,
    t = b !== null && b.next !== null,
    Ot = 0,
    te = b = X = null,
    br = !1,
    t)
        throw Error(g(300));
    return e
}
function Si() {
    var e = Zn !== 0;
    return Zn = 0,
    e
}
function He() {
    var e = {
        memoizedState: null,
        baseState: null,
        baseQueue: null,
        queue: null,
        next: null
    };
    return te === null ? X.memoizedState = te = e : te = te.next = e,
    te
}
function Me() {
    if (b === null) {
        var e = X.alternate;
        e = e !== null ? e.memoizedState : null
    } else
        e = b.next;
    var t = te === null ? X.memoizedState : te.next;
    if (t !== null)
        te = t,
        b = e;
    else {
        if (e === null)
            throw Error(g(310));
        b = e,
        e = {
            memoizedState: b.memoizedState,
            baseState: b.baseState,
            baseQueue: b.baseQueue,
            queue: b.queue,
            next: null
        },
        te === null ? X.memoizedState = te = e : te = te.next = e
    }
    return te
}
function Jn(e, t) {
    return typeof t == "function" ? t(e) : t
}
function Hl(e) {
    var t = Me()
      , n = t.queue;
    if (n === null)
        throw Error(g(311));
    n.lastRenderedReducer = e;
    var r = b
      , l = r.baseQueue
      , o = n.pending;
    if (o !== null) {
        if (l !== null) {
            var i = l.next;
            l.next = o.next,
            o.next = i
        }
        r.baseQueue = l = o,
        n.pending = null
    }
    if (l !== null) {
        o = l.next,
        r = r.baseState;
        var u = i = null
          , s = null
          , c = o;
        do {
            var h = c.lane;
            if ((Ot & h) === h)
                s !== null && (s = s.next = {
                    lane: 0,
                    action: c.action,
                    hasEagerState: c.hasEagerState,
                    eagerState: c.eagerState,
                    next: null
                }),
                r = c.hasEagerState ? c.eagerState : e(r, c.action);
            else {
                var m = {
                    lane: h,
                    action: c.action,
                    hasEagerState: c.hasEagerState,
                    eagerState: c.eagerState,
                    next: null
                };
                s === null ? (u = s = m,
                i = r) : s = s.next = m,
                X.lanes |= h,
                Dt |= h
            }
            c = c.next
        } while (c !== null && c !== o);
        s === null ? i = r : s.next = u,
        Ve(r, t.memoizedState) || (ve = !0),
        t.memoizedState = r,
        t.baseState = i,
        t.baseQueue = s,
        n.lastRenderedState = r
    }
    if (e = n.interleaved,
    e !== null) {
        l = e;
        do
            o = l.lane,
            X.lanes |= o,
            Dt |= o,
            l = l.next;
        while (l !== e)
    } else
        l === null && (n.lanes = 0);
    return [t.memoizedState, n.dispatch]
}
function Wl(e) {
    var t = Me()
      , n = t.queue;
    if (n === null)
        throw Error(g(311));
    n.lastRenderedReducer = e;
    var r = n.dispatch
      , l = n.pending
      , o = t.memoizedState;
    if (l !== null) {
        n.pending = null;
        var i = l = l.next;
        do
            o = e(o, i.action),
            i = i.next;
        while (i !== l);
        Ve(o, t.memoizedState) || (ve = !0),
        t.memoizedState = o,
        t.baseQueue === null && (t.baseState = o),
        n.lastRenderedState = o
    }
    return [o, r]
}
function fa() {}
function da(e, t) {
    var n = X
      , r = Me()
      , l = t()
      , o = !Ve(r.memoizedState, l);
    if (o && (r.memoizedState = l,
    ve = !0),
    r = r.queue,
    Ei(ha.bind(null, n, r, e), [e]),
    r.getSnapshot !== t || o || te !== null && te.memoizedState.tag & 1) {
        if (n.flags |= 2048,
        qn(9, ma.bind(null, n, r, l, t), void 0, null),
        ne === null)
            throw Error(g(349));
        Ot & 30 || pa(n, t, l)
    }
    return l
}
function pa(e, t, n) {
    e.flags |= 16384,
    e = {
        getSnapshot: t,
        value: n
    },
    t = X.updateQueue,
    t === null ? (t = {
        lastEffect: null,
        stores: null
    },
    X.updateQueue = t,
    t.stores = [e]) : (n = t.stores,
    n === null ? t.stores = [e] : n.push(e))
}
function ma(e, t, n, r) {
    t.value = n,
    t.getSnapshot = r,
    va(t) && ya(e)
}
function ha(e, t, n) {
    return n(function() {
        va(t) && ya(e)
    })
}
function va(e) {
    var t = e.getSnapshot;
    e = e.value;
    try {
        var n = t();
        return !Ve(e, n)
    } catch {
        return !0
    }
}
function ya(e) {
    var t = et(e, 1);
    t !== null && $e(t, e, 1, -1)
}
function Eu(e) {
    var t = He();
    return typeof e == "function" && (e = e()),
    t.memoizedState = t.baseState = e,
    e = {
        pending: null,
        interleaved: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: Jn,
        lastRenderedState: e
    },
    t.queue = e,
    e = e.dispatch = ld.bind(null, X, e),
    [t.memoizedState, e]
}
function qn(e, t, n, r) {
    return e = {
        tag: e,
        create: t,
        destroy: n,
        deps: r,
        next: null
    },
    t = X.updateQueue,
    t === null ? (t = {
        lastEffect: null,
        stores: null
    },
    X.updateQueue = t,
    t.lastEffect = e.next = e) : (n = t.lastEffect,
    n === null ? t.lastEffect = e.next = e : (r = n.next,
    n.next = e,
    e.next = r,
    t.lastEffect = e)),
    e
}
function ga() {
    return Me().memoizedState
}
function Tr(e, t, n, r) {
    var l = He();
    X.flags |= e,
    l.memoizedState = qn(1 | t, n, void 0, r === void 0 ? null : r)
}
function pl(e, t, n, r) {
    var l = Me();
    r = r === void 0 ? null : r;
    var o = void 0;
    if (b !== null) {
        var i = b.memoizedState;
        if (o = i.destroy,
        r !== null && xi(r, i.deps)) {
            l.memoizedState = qn(t, n, o, r);
            return
        }
    }
    X.flags |= e,
    l.memoizedState = qn(1 | t, n, o, r)
}
function Cu(e, t) {
    return Tr(8390656, 8, e, t)
}
function Ei(e, t) {
    return pl(2048, 8, e, t)
}
function wa(e, t) {
    return pl(4, 2, e, t)
}
function xa(e, t) {
    return pl(4, 4, e, t)
}
function ka(e, t) {
    if (typeof t == "function")
        return e = e(),
        t(e),
        function() {
            t(null)
        }
        ;
    if (t != null)
        return e = e(),
        t.current = e,
        function() {
            t.current = null
        }
}
function Sa(e, t, n) {
    return n = n != null ? n.concat([e]) : null,
    pl(4, 4, ka.bind(null, t, e), n)
}
function Ci() {}
function Ea(e, t) {
    var n = Me();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && xi(t, r[1]) ? r[0] : (n.memoizedState = [e, t],
    e)
}
function Ca(e, t) {
    var n = Me();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && xi(t, r[1]) ? r[0] : (e = e(),
    n.memoizedState = [e, t],
    e)
}
function Na(e, t, n) {
    return Ot & 21 ? (Ve(n, t) || (n = Ls(),
    X.lanes |= n,
    Dt |= n,
    e.baseState = !0),
    t) : (e.baseState && (e.baseState = !1,
    ve = !0),
    e.memoizedState = n)
}
function nd(e, t) {
    var n = O;
    O = n !== 0 && 4 > n ? n : 4,
    e(!0);
    var r = Bl.transition;
    Bl.transition = {};
    try {
        e(!1),
        t()
    } finally {
        O = n,
        Bl.transition = r
    }
}
function _a() {
    return Me().memoizedState
}
function rd(e, t, n) {
    var r = vt(e);
    if (n = {
        lane: r,
        action: n,
        hasEagerState: !1,
        eagerState: null,
        next: null
    },
    Pa(e))
        ja(t, n);
    else if (n = sa(e, t, n, r),
    n !== null) {
        var l = de();
        $e(n, e, r, l),
        za(n, t, r)
    }
}
function ld(e, t, n) {
    var r = vt(e)
      , l = {
        lane: r,
        action: n,
        hasEagerState: !1,
        eagerState: null,
        next: null
    };
    if (Pa(e))
        ja(t, l);
    else {
        var o = e.alternate;
        if (e.lanes === 0 && (o === null || o.lanes === 0) && (o = t.lastRenderedReducer,
        o !== null))
            try {
                var i = t.lastRenderedState
                  , u = o(i, n);
                if (l.hasEagerState = !0,
                l.eagerState = u,
                Ve(u, i)) {
                    var s = t.interleaved;
                    s === null ? (l.next = l,
                    hi(t)) : (l.next = s.next,
                    s.next = l),
                    t.interleaved = l;
                    return
                }
            } catch {} finally {}
        n = sa(e, t, l, r),
        n !== null && (l = de(),
        $e(n, e, r, l),
        za(n, t, r))
    }
}
function Pa(e) {
    var t = e.alternate;
    return e === X || t !== null && t === X
}
function ja(e, t) {
    Mn = br = !0;
    var n = e.pending;
    n === null ? t.next = t : (t.next = n.next,
    n.next = t),
    e.pending = t
}
function za(e, t, n) {
    if (n & 4194240) {
        var r = t.lanes;
        r &= e.pendingLanes,
        n |= r,
        t.lanes = n,
        ti(e, n)
    }
}
var el = {
    readContext: Re,
    useCallback: ie,
    useContext: ie,
    useEffect: ie,
    useImperativeHandle: ie,
    useInsertionEffect: ie,
    useLayoutEffect: ie,
    useMemo: ie,
    useReducer: ie,
    useRef: ie,
    useState: ie,
    useDebugValue: ie,
    useDeferredValue: ie,
    useTransition: ie,
    useMutableSource: ie,
    useSyncExternalStore: ie,
    useId: ie,
    unstable_isNewReconciler: !1
}
  , od = {
    readContext: Re,
    useCallback: function(e, t) {
        return He().memoizedState = [e, t === void 0 ? null : t],
        e
    },
    useContext: Re,
    useEffect: Cu,
    useImperativeHandle: function(e, t, n) {
        return n = n != null ? n.concat([e]) : null,
        Tr(4194308, 4, ka.bind(null, t, e), n)
    },
    useLayoutEffect: function(e, t) {
        return Tr(4194308, 4, e, t)
    },
    useInsertionEffect: function(e, t) {
        return Tr(4, 2, e, t)
    },
    useMemo: function(e, t) {
        var n = He();
        return t = t === void 0 ? null : t,
        e = e(),
        n.memoizedState = [e, t],
        e
    },
    useReducer: function(e, t, n) {
        var r = He();
        return t = n !== void 0 ? n(t) : t,
        r.memoizedState = r.baseState = t,
        e = {
            pending: null,
            interleaved: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: e,
            lastRenderedState: t
        },
        r.queue = e,
        e = e.dispatch = rd.bind(null, X, e),
        [r.memoizedState, e]
    },
    useRef: function(e) {
        var t = He();
        return e = {
            current: e
        },
        t.memoizedState = e
    },
    useState: Eu,
    useDebugValue: Ci,
    useDeferredValue: function(e) {
        return He().memoizedState = e
    },
    useTransition: function() {
        var e = Eu(!1)
          , t = e[0];
        return e = nd.bind(null, e[1]),
        He().memoizedState = e,
        [t, e]
    },
    useMutableSource: function() {},
    useSyncExternalStore: function(e, t, n) {
        var r = X
          , l = He();
        if (Q) {
            if (n === void 0)
                throw Error(g(407));
            n = n()
        } else {
            if (n = t(),
            ne === null)
                throw Error(g(349));
            Ot & 30 || pa(r, t, n)
        }
        l.memoizedState = n;
        var o = {
            value: n,
            getSnapshot: t
        };
        return l.queue = o,
        Cu(ha.bind(null, r, o, e), [e]),
        r.flags |= 2048,
        qn(9, ma.bind(null, r, o, n, t), void 0, null),
        n
    },
    useId: function() {
        var e = He()
          , t = ne.identifierPrefix;
        if (Q) {
            var n = Ze
              , r = Ge;
            n = (r & ~(1 << 32 - Ae(r) - 1)).toString(32) + n,
            t = ":" + t + "R" + n,
            n = Zn++,
            0 < n && (t += "H" + n.toString(32)),
            t += ":"
        } else
            n = td++,
            t = ":" + t + "r" + n.toString(32) + ":";
        return e.memoizedState = t
    },
    unstable_isNewReconciler: !1
}
  , id = {
    readContext: Re,
    useCallback: Ea,
    useContext: Re,
    useEffect: Ei,
    useImperativeHandle: Sa,
    useInsertionEffect: wa,
    useLayoutEffect: xa,
    useMemo: Ca,
    useReducer: Hl,
    useRef: ga,
    useState: function() {
        return Hl(Jn)
    },
    useDebugValue: Ci,
    useDeferredValue: function(e) {
        var t = Me();
        return Na(t, b.memoizedState, e)
    },
    useTransition: function() {
        var e = Hl(Jn)[0]
          , t = Me().memoizedState;
        return [e, t]
    },
    useMutableSource: fa,
    useSyncExternalStore: da,
    useId: _a,
    unstable_isNewReconciler: !1
}
  , ud = {
    readContext: Re,
    useCallback: Ea,
    useContext: Re,
    useEffect: Ei,
    useImperativeHandle: Sa,
    useInsertionEffect: wa,
    useLayoutEffect: xa,
    useMemo: Ca,
    useReducer: Wl,
    useRef: ga,
    useState: function() {
        return Wl(Jn)
    },
    useDebugValue: Ci,
    useDeferredValue: function(e) {
        var t = Me();
        return b === null ? t.memoizedState = e : Na(t, b.memoizedState, e)
    },
    useTransition: function() {
        var e = Wl(Jn)[0]
          , t = Me().memoizedState;
        return [e, t]
    },
    useMutableSource: fa,
    useSyncExternalStore: da,
    useId: _a,
    unstable_isNewReconciler: !1
};
function De(e, t) {
    if (e && e.defaultProps) {
        t = G({}, t),
        e = e.defaultProps;
        for (var n in e)
            t[n] === void 0 && (t[n] = e[n]);
        return t
    }
    return t
}
function Po(e, t, n, r) {
    t = e.memoizedState,
    n = n(r, t),
    n = n == null ? t : G({}, t, n),
    e.memoizedState = n,
    e.lanes === 0 && (e.updateQueue.baseState = n)
}
var ml = {
    isMounted: function(e) {
        return (e = e._reactInternals) ? At(e) === e : !1
    },
    enqueueSetState: function(e, t, n) {
        e = e._reactInternals;
        var r = de()
          , l = vt(e)
          , o = Je(r, l);
        o.payload = t,
        n != null && (o.callback = n),
        t = mt(e, o, l),
        t !== null && ($e(t, e, l, r),
        zr(t, e, l))
    },
    enqueueReplaceState: function(e, t, n) {
        e = e._reactInternals;
        var r = de()
          , l = vt(e)
          , o = Je(r, l);
        o.tag = 1,
        o.payload = t,
        n != null && (o.callback = n),
        t = mt(e, o, l),
        t !== null && ($e(t, e, l, r),
        zr(t, e, l))
    },
    enqueueForceUpdate: function(e, t) {
        e = e._reactInternals;
        var n = de()
          , r = vt(e)
          , l = Je(n, r);
        l.tag = 2,
        t != null && (l.callback = t),
        t = mt(e, l, r),
        t !== null && ($e(t, e, r, n),
        zr(t, e, r))
    }
};
function Nu(e, t, n, r, l, o, i) {
    return e = e.stateNode,
    typeof e.shouldComponentUpdate == "function" ? e.shouldComponentUpdate(r, o, i) : t.prototype && t.prototype.isPureReactComponent ? !Wn(n, r) || !Wn(l, o) : !0
}
function La(e, t, n) {
    var r = !1
      , l = wt
      , o = t.contextType;
    return typeof o == "object" && o !== null ? o = Re(o) : (l = ge(t) ? Mt : ce.current,
    r = t.contextTypes,
    o = (r = r != null) ? un(e, l) : wt),
    t = new t(n,o),
    e.memoizedState = t.state !== null && t.state !== void 0 ? t.state : null,
    t.updater = ml,
    e.stateNode = t,
    t._reactInternals = e,
    r && (e = e.stateNode,
    e.__reactInternalMemoizedUnmaskedChildContext = l,
    e.__reactInternalMemoizedMaskedChildContext = o),
    t
}
function _u(e, t, n, r) {
    e = t.state,
    typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(n, r),
    typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(n, r),
    t.state !== e && ml.enqueueReplaceState(t, t.state, null)
}
function jo(e, t, n, r) {
    var l = e.stateNode;
    l.props = n,
    l.state = e.memoizedState,
    l.refs = {},
    vi(e);
    var o = t.contextType;
    typeof o == "object" && o !== null ? l.context = Re(o) : (o = ge(t) ? Mt : ce.current,
    l.context = un(e, o)),
    l.state = e.memoizedState,
    o = t.getDerivedStateFromProps,
    typeof o == "function" && (Po(e, t, o, n),
    l.state = e.memoizedState),
    typeof t.getDerivedStateFromProps == "function" || typeof l.getSnapshotBeforeUpdate == "function" || typeof l.UNSAFE_componentWillMount != "function" && typeof l.componentWillMount != "function" || (t = l.state,
    typeof l.componentWillMount == "function" && l.componentWillMount(),
    typeof l.UNSAFE_componentWillMount == "function" && l.UNSAFE_componentWillMount(),
    t !== l.state && ml.enqueueReplaceState(l, l.state, null),
    Jr(e, n, l, r),
    l.state = e.memoizedState),
    typeof l.componentDidMount == "function" && (e.flags |= 4194308)
}
function fn(e, t) {
    try {
        var n = ""
          , r = t;
        do
            n += Fc(r),
            r = r.return;
        while (r);
        var l = n
    } catch (o) {
        l = `
Error generating stack: ` + o.message + `
` + o.stack
    }
    return {
        value: e,
        source: t,
        stack: l,
        digest: null
    }
}
function Ql(e, t, n) {
    return {
        value: e,
        source: null,
        stack: n ?? null,
        digest: t ?? null
    }
}
function zo(e, t) {
    try {
        console.error(t.value)
    } catch (n) {
        setTimeout(function() {
            throw n
        })
    }
}
var sd = typeof WeakMap == "function" ? WeakMap : Map;
function Ta(e, t, n) {
    n = Je(-1, n),
    n.tag = 3,
    n.payload = {
        element: null
    };
    var r = t.value;
    return n.callback = function() {
        nl || (nl = !0,
        Ao = r),
        zo(e, t)
    }
    ,
    n
}
function Ra(e, t, n) {
    n = Je(-1, n),
    n.tag = 3;
    var r = e.type.getDerivedStateFromError;
    if (typeof r == "function") {
        var l = t.value;
        n.payload = function() {
            return r(l)
        }
        ,
        n.callback = function() {
            zo(e, t)
        }
    }
    var o = e.stateNode;
    return o !== null && typeof o.componentDidCatch == "function" && (n.callback = function() {
        zo(e, t),
        typeof r != "function" && (ht === null ? ht = new Set([this]) : ht.add(this));
        var i = t.stack;
        this.componentDidCatch(t.value, {
            componentStack: i !== null ? i : ""
        })
    }
    ),
    n
}
function Pu(e, t, n) {
    var r = e.pingCache;
    if (r === null) {
        r = e.pingCache = new sd;
        var l = new Set;
        r.set(t, l)
    } else
        l = r.get(t),
        l === void 0 && (l = new Set,
        r.set(t, l));
    l.has(n) || (l.add(n),
    e = Sd.bind(null, e, t, n),
    t.then(e, e))
}
function ju(e) {
    do {
        var t;
        if ((t = e.tag === 13) && (t = e.memoizedState,
        t = t !== null ? t.dehydrated !== null : !0),
        t)
            return e;
        e = e.return
    } while (e !== null);
    return null
}
function zu(e, t, n, r, l) {
    return e.mode & 1 ? (e.flags |= 65536,
    e.lanes = l,
    e) : (e === t ? e.flags |= 65536 : (e.flags |= 128,
    n.flags |= 131072,
    n.flags &= -52805,
    n.tag === 1 && (n.alternate === null ? n.tag = 17 : (t = Je(-1, 1),
    t.tag = 2,
    mt(n, t, 1))),
    n.lanes |= 1),
    e)
}
var ad = nt.ReactCurrentOwner
  , ve = !1;
function fe(e, t, n, r) {
    t.child = e === null ? ua(t, null, n, r) : an(t, e.child, n, r)
}
function Lu(e, t, n, r, l) {
    n = n.render;
    var o = t.ref;
    return rn(t, l),
    r = ki(e, t, n, r, o, l),
    n = Si(),
    e !== null && !ve ? (t.updateQueue = e.updateQueue,
    t.flags &= -2053,
    e.lanes &= ~l,
    tt(e, t, l)) : (Q && n && ai(t),
    t.flags |= 1,
    fe(e, t, r, l),
    t.child)
}
function Tu(e, t, n, r, l) {
    if (e === null) {
        var o = n.type;
        return typeof o == "function" && !Ri(o) && o.defaultProps === void 0 && n.compare === null && n.defaultProps === void 0 ? (t.tag = 15,
        t.type = o,
        Ma(e, t, o, r, l)) : (e = Or(n.type, null, r, t, t.mode, l),
        e.ref = t.ref,
        e.return = t,
        t.child = e)
    }
    if (o = e.child,
    !(e.lanes & l)) {
        var i = o.memoizedProps;
        if (n = n.compare,
        n = n !== null ? n : Wn,
        n(i, r) && e.ref === t.ref)
            return tt(e, t, l)
    }
    return t.flags |= 1,
    e = yt(o, r),
    e.ref = t.ref,
    e.return = t,
    t.child = e
}
function Ma(e, t, n, r, l) {
    if (e !== null) {
        var o = e.memoizedProps;
        if (Wn(o, r) && e.ref === t.ref)
            if (ve = !1,
            t.pendingProps = r = o,
            (e.lanes & l) !== 0)
                e.flags & 131072 && (ve = !0);
            else
                return t.lanes = e.lanes,
                tt(e, t, l)
    }
    return Lo(e, t, n, r, l)
}
function Fa(e, t, n) {
    var r = t.pendingProps
      , l = r.children
      , o = e !== null ? e.memoizedState : null;
    if (r.mode === "hidden")
        if (!(t.mode & 1))
            t.memoizedState = {
                baseLanes: 0,
                cachePool: null,
                transitions: null
            },
            A(qt, Se),
            Se |= n;
        else {
            if (!(n & 1073741824))
                return e = o !== null ? o.baseLanes | n : n,
                t.lanes = t.childLanes = 1073741824,
                t.memoizedState = {
                    baseLanes: e,
                    cachePool: null,
                    transitions: null
                },
                t.updateQueue = null,
                A(qt, Se),
                Se |= e,
                null;
            t.memoizedState = {
                baseLanes: 0,
                cachePool: null,
                transitions: null
            },
            r = o !== null ? o.baseLanes : n,
            A(qt, Se),
            Se |= r
        }
    else
        o !== null ? (r = o.baseLanes | n,
        t.memoizedState = null) : r = n,
        A(qt, Se),
        Se |= r;
    return fe(e, t, l, n),
    t.child
}
function Oa(e, t) {
    var n = t.ref;
    (e === null && n !== null || e !== null && e.ref !== n) && (t.flags |= 512,
    t.flags |= 2097152)
}
function Lo(e, t, n, r, l) {
    var o = ge(n) ? Mt : ce.current;
    return o = un(t, o),
    rn(t, l),
    n = ki(e, t, n, r, o, l),
    r = Si(),
    e !== null && !ve ? (t.updateQueue = e.updateQueue,
    t.flags &= -2053,
    e.lanes &= ~l,
    tt(e, t, l)) : (Q && r && ai(t),
    t.flags |= 1,
    fe(e, t, n, l),
    t.child)
}
function Ru(e, t, n, r, l) {
    if (ge(n)) {
        var o = !0;
        Kr(t)
    } else
        o = !1;
    if (rn(t, l),
    t.stateNode === null)
        Rr(e, t),
        La(t, n, r),
        jo(t, n, r, l),
        r = !0;
    else if (e === null) {
        var i = t.stateNode
          , u = t.memoizedProps;
        i.props = u;
        var s = i.context
          , c = n.contextType;
        typeof c == "object" && c !== null ? c = Re(c) : (c = ge(n) ? Mt : ce.current,
        c = un(t, c));
        var h = n.getDerivedStateFromProps
          , m = typeof h == "function" || typeof i.getSnapshotBeforeUpdate == "function";
        m || typeof i.UNSAFE_componentWillReceiveProps != "function" && typeof i.componentWillReceiveProps != "function" || (u !== r || s !== c) && _u(t, i, r, c),
        ot = !1;
        var p = t.memoizedState;
        i.state = p,
        Jr(t, r, i, l),
        s = t.memoizedState,
        u !== r || p !== s || ye.current || ot ? (typeof h == "function" && (Po(t, n, h, r),
        s = t.memoizedState),
        (u = ot || Nu(t, n, u, r, p, s, c)) ? (m || typeof i.UNSAFE_componentWillMount != "function" && typeof i.componentWillMount != "function" || (typeof i.componentWillMount == "function" && i.componentWillMount(),
        typeof i.UNSAFE_componentWillMount == "function" && i.UNSAFE_componentWillMount()),
        typeof i.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof i.componentDidMount == "function" && (t.flags |= 4194308),
        t.memoizedProps = r,
        t.memoizedState = s),
        i.props = r,
        i.state = s,
        i.context = c,
        r = u) : (typeof i.componentDidMount == "function" && (t.flags |= 4194308),
        r = !1)
    } else {
        i = t.stateNode,
        aa(e, t),
        u = t.memoizedProps,
        c = t.type === t.elementType ? u : De(t.type, u),
        i.props = c,
        m = t.pendingProps,
        p = i.context,
        s = n.contextType,
        typeof s == "object" && s !== null ? s = Re(s) : (s = ge(n) ? Mt : ce.current,
        s = un(t, s));
        var w = n.getDerivedStateFromProps;
        (h = typeof w == "function" || typeof i.getSnapshotBeforeUpdate == "function") || typeof i.UNSAFE_componentWillReceiveProps != "function" && typeof i.componentWillReceiveProps != "function" || (u !== m || p !== s) && _u(t, i, r, s),
        ot = !1,
        p = t.memoizedState,
        i.state = p,
        Jr(t, r, i, l);
        var k = t.memoizedState;
        u !== m || p !== k || ye.current || ot ? (typeof w == "function" && (Po(t, n, w, r),
        k = t.memoizedState),
        (c = ot || Nu(t, n, c, r, p, k, s) || !1) ? (h || typeof i.UNSAFE_componentWillUpdate != "function" && typeof i.componentWillUpdate != "function" || (typeof i.componentWillUpdate == "function" && i.componentWillUpdate(r, k, s),
        typeof i.UNSAFE_componentWillUpdate == "function" && i.UNSAFE_componentWillUpdate(r, k, s)),
        typeof i.componentDidUpdate == "function" && (t.flags |= 4),
        typeof i.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof i.componentDidUpdate != "function" || u === e.memoizedProps && p === e.memoizedState || (t.flags |= 4),
        typeof i.getSnapshotBeforeUpdate != "function" || u === e.memoizedProps && p === e.memoizedState || (t.flags |= 1024),
        t.memoizedProps = r,
        t.memoizedState = k),
        i.props = r,
        i.state = k,
        i.context = s,
        r = c) : (typeof i.componentDidUpdate != "function" || u === e.memoizedProps && p === e.memoizedState || (t.flags |= 4),
        typeof i.getSnapshotBeforeUpdate != "function" || u === e.memoizedProps && p === e.memoizedState || (t.flags |= 1024),
        r = !1)
    }
    return To(e, t, n, r, o, l)
}
function To(e, t, n, r, l, o) {
    Oa(e, t);
    var i = (t.flags & 128) !== 0;
    if (!r && !i)
        return l && yu(t, n, !1),
        tt(e, t, o);
    r = t.stateNode,
    ad.current = t;
    var u = i && typeof n.getDerivedStateFromError != "function" ? null : r.render();
    return t.flags |= 1,
    e !== null && i ? (t.child = an(t, e.child, null, o),
    t.child = an(t, null, u, o)) : fe(e, t, u, o),
    t.memoizedState = r.state,
    l && yu(t, n, !0),
    t.child
}
function Da(e) {
    var t = e.stateNode;
    t.pendingContext ? vu(e, t.pendingContext, t.pendingContext !== t.context) : t.context && vu(e, t.context, !1),
    yi(e, t.containerInfo)
}
function Mu(e, t, n, r, l) {
    return sn(),
    fi(l),
    t.flags |= 256,
    fe(e, t, n, r),
    t.child
}
var Ro = {
    dehydrated: null,
    treeContext: null,
    retryLane: 0
};
function Mo(e) {
    return {
        baseLanes: e,
        cachePool: null,
        transitions: null
    }
}
function Ia(e, t, n) {
    var r = t.pendingProps, l = Y.current, o = !1, i = (t.flags & 128) !== 0, u;
    if ((u = i) || (u = e !== null && e.memoizedState === null ? !1 : (l & 2) !== 0),
    u ? (o = !0,
    t.flags &= -129) : (e === null || e.memoizedState !== null) && (l |= 1),
    A(Y, l & 1),
    e === null)
        return No(t),
        e = t.memoizedState,
        e !== null && (e = e.dehydrated,
        e !== null) ? (t.mode & 1 ? e.data === "$!" ? t.lanes = 8 : t.lanes = 1073741824 : t.lanes = 1,
        null) : (i = r.children,
        e = r.fallback,
        o ? (r = t.mode,
        o = t.child,
        i = {
            mode: "hidden",
            children: i
        },
        !(r & 1) && o !== null ? (o.childLanes = 0,
        o.pendingProps = i) : o = yl(i, r, 0, null),
        e = Rt(e, r, n, null),
        o.return = t,
        e.return = t,
        o.sibling = e,
        t.child = o,
        t.child.memoizedState = Mo(n),
        t.memoizedState = Ro,
        e) : Ni(t, i));
    if (l = e.memoizedState,
    l !== null && (u = l.dehydrated,
    u !== null))
        return cd(e, t, i, r, u, l, n);
    if (o) {
        o = r.fallback,
        i = t.mode,
        l = e.child,
        u = l.sibling;
        var s = {
            mode: "hidden",
            children: r.children
        };
        return !(i & 1) && t.child !== l ? (r = t.child,
        r.childLanes = 0,
        r.pendingProps = s,
        t.deletions = null) : (r = yt(l, s),
        r.subtreeFlags = l.subtreeFlags & 14680064),
        u !== null ? o = yt(u, o) : (o = Rt(o, i, n, null),
        o.flags |= 2),
        o.return = t,
        r.return = t,
        r.sibling = o,
        t.child = r,
        r = o,
        o = t.child,
        i = e.child.memoizedState,
        i = i === null ? Mo(n) : {
            baseLanes: i.baseLanes | n,
            cachePool: null,
            transitions: i.transitions
        },
        o.memoizedState = i,
        o.childLanes = e.childLanes & ~n,
        t.memoizedState = Ro,
        r
    }
    return o = e.child,
    e = o.sibling,
    r = yt(o, {
        mode: "visible",
        children: r.children
    }),
    !(t.mode & 1) && (r.lanes = n),
    r.return = t,
    r.sibling = null,
    e !== null && (n = t.deletions,
    n === null ? (t.deletions = [e],
    t.flags |= 16) : n.push(e)),
    t.child = r,
    t.memoizedState = null,
    r
}
function Ni(e, t) {
    return t = yl({
        mode: "visible",
        children: t
    }, e.mode, 0, null),
    t.return = e,
    e.child = t
}
function wr(e, t, n, r) {
    return r !== null && fi(r),
    an(t, e.child, null, n),
    e = Ni(t, t.pendingProps.children),
    e.flags |= 2,
    t.memoizedState = null,
    e
}
function cd(e, t, n, r, l, o, i) {
    if (n)
        return t.flags & 256 ? (t.flags &= -257,
        r = Ql(Error(g(422))),
        wr(e, t, i, r)) : t.memoizedState !== null ? (t.child = e.child,
        t.flags |= 128,
        null) : (o = r.fallback,
        l = t.mode,
        r = yl({
            mode: "visible",
            children: r.children
        }, l, 0, null),
        o = Rt(o, l, i, null),
        o.flags |= 2,
        r.return = t,
        o.return = t,
        r.sibling = o,
        t.child = r,
        t.mode & 1 && an(t, e.child, null, i),
        t.child.memoizedState = Mo(i),
        t.memoizedState = Ro,
        o);
    if (!(t.mode & 1))
        return wr(e, t, i, null);
    if (l.data === "$!") {
        if (r = l.nextSibling && l.nextSibling.dataset,
        r)
            var u = r.dgst;
        return r = u,
        o = Error(g(419)),
        r = Ql(o, r, void 0),
        wr(e, t, i, r)
    }
    if (u = (i & e.childLanes) !== 0,
    ve || u) {
        if (r = ne,
        r !== null) {
            switch (i & -i) {
            case 4:
                l = 2;
                break;
            case 16:
                l = 8;
                break;
            case 64:
            case 128:
            case 256:
            case 512:
            case 1024:
            case 2048:
            case 4096:
            case 8192:
            case 16384:
            case 32768:
            case 65536:
            case 131072:
            case 262144:
            case 524288:
            case 1048576:
            case 2097152:
            case 4194304:
            case 8388608:
            case 16777216:
            case 33554432:
            case 67108864:
                l = 32;
                break;
            case 536870912:
                l = 268435456;
                break;
            default:
                l = 0
            }
            l = l & (r.suspendedLanes | i) ? 0 : l,
            l !== 0 && l !== o.retryLane && (o.retryLane = l,
            et(e, l),
            $e(r, e, l, -1))
        }
        return Ti(),
        r = Ql(Error(g(421))),
        wr(e, t, i, r)
    }
    return l.data === "$?" ? (t.flags |= 128,
    t.child = e.child,
    t = Ed.bind(null, e),
    l._reactRetry = t,
    null) : (e = o.treeContext,
    Ee = pt(l.nextSibling),
    Ce = t,
    Q = !0,
    Ue = null,
    e !== null && (je[ze++] = Ge,
    je[ze++] = Ze,
    je[ze++] = Ft,
    Ge = e.id,
    Ze = e.overflow,
    Ft = t),
    t = Ni(t, r.children),
    t.flags |= 4096,
    t)
}
function Fu(e, t, n) {
    e.lanes |= t;
    var r = e.alternate;
    r !== null && (r.lanes |= t),
    _o(e.return, t, n)
}
function Kl(e, t, n, r, l) {
    var o = e.memoizedState;
    o === null ? e.memoizedState = {
        isBackwards: t,
        rendering: null,
        renderingStartTime: 0,
        last: r,
        tail: n,
        tailMode: l
    } : (o.isBackwards = t,
    o.rendering = null,
    o.renderingStartTime = 0,
    o.last = r,
    o.tail = n,
    o.tailMode = l)
}
function Ua(e, t, n) {
    var r = t.pendingProps
      , l = r.revealOrder
      , o = r.tail;
    if (fe(e, t, r.children, n),
    r = Y.current,
    r & 2)
        r = r & 1 | 2,
        t.flags |= 128;
    else {
        if (e !== null && e.flags & 128)
            e: for (e = t.child; e !== null; ) {
                if (e.tag === 13)
                    e.memoizedState !== null && Fu(e, n, t);
                else if (e.tag === 19)
                    Fu(e, n, t);
                else if (e.child !== null) {
                    e.child.return = e,
                    e = e.child;
                    continue
                }
                if (e === t)
                    break e;
                for (; e.sibling === null; ) {
                    if (e.return === null || e.return === t)
                        break e;
                    e = e.return
                }
                e.sibling.return = e.return,
                e = e.sibling
            }
        r &= 1
    }
    if (A(Y, r),
    !(t.mode & 1))
        t.memoizedState = null;
    else
        switch (l) {
        case "forwards":
            for (n = t.child,
            l = null; n !== null; )
                e = n.alternate,
                e !== null && qr(e) === null && (l = n),
                n = n.sibling;
            n = l,
            n === null ? (l = t.child,
            t.child = null) : (l = n.sibling,
            n.sibling = null),
            Kl(t, !1, l, n, o);
            break;
        case "backwards":
            for (n = null,
            l = t.child,
            t.child = null; l !== null; ) {
                if (e = l.alternate,
                e !== null && qr(e) === null) {
                    t.child = l;
                    break
                }
                e = l.sibling,
                l.sibling = n,
                n = l,
                l = e
            }
            Kl(t, !0, n, null, o);
            break;
        case "together":
            Kl(t, !1, null, null, void 0);
            break;
        default:
            t.memoizedState = null
        }
    return t.child
}
function Rr(e, t) {
    !(t.mode & 1) && e !== null && (e.alternate = null,
    t.alternate = null,
    t.flags |= 2)
}
function tt(e, t, n) {
    if (e !== null && (t.dependencies = e.dependencies),
    Dt |= t.lanes,
    !(n & t.childLanes))
        return null;
    if (e !== null && t.child !== e.child)
        throw Error(g(153));
    if (t.child !== null) {
        for (e = t.child,
        n = yt(e, e.pendingProps),
        t.child = n,
        n.return = t; e.sibling !== null; )
            e = e.sibling,
            n = n.sibling = yt(e, e.pendingProps),
            n.return = t;
        n.sibling = null
    }
    return t.child
}
function fd(e, t, n) {
    switch (t.tag) {
    case 3:
        Da(t),
        sn();
        break;
    case 5:
        ca(t);
        break;
    case 1:
        ge(t.type) && Kr(t);
        break;
    case 4:
        yi(t, t.stateNode.containerInfo);
        break;
    case 10:
        var r = t.type._context
          , l = t.memoizedProps.value;
        A(Gr, r._currentValue),
        r._currentValue = l;
        break;
    case 13:
        if (r = t.memoizedState,
        r !== null)
            return r.dehydrated !== null ? (A(Y, Y.current & 1),
            t.flags |= 128,
            null) : n & t.child.childLanes ? Ia(e, t, n) : (A(Y, Y.current & 1),
            e = tt(e, t, n),
            e !== null ? e.sibling : null);
        A(Y, Y.current & 1);
        break;
    case 19:
        if (r = (n & t.childLanes) !== 0,
        e.flags & 128) {
            if (r)
                return Ua(e, t, n);
            t.flags |= 128
        }
        if (l = t.memoizedState,
        l !== null && (l.rendering = null,
        l.tail = null,
        l.lastEffect = null),
        A(Y, Y.current),
        r)
            break;
        return null;
    case 22:
    case 23:
        return t.lanes = 0,
        Fa(e, t, n)
    }
    return tt(e, t, n)
}
var Aa, Fo, $a, Va;
Aa = function(e, t) {
    for (var n = t.child; n !== null; ) {
        if (n.tag === 5 || n.tag === 6)
            e.appendChild(n.stateNode);
        else if (n.tag !== 4 && n.child !== null) {
            n.child.return = n,
            n = n.child;
            continue
        }
        if (n === t)
            break;
        for (; n.sibling === null; ) {
            if (n.return === null || n.return === t)
                return;
            n = n.return
        }
        n.sibling.return = n.return,
        n = n.sibling
    }
}
;
Fo = function() {}
;
$a = function(e, t, n, r) {
    var l = e.memoizedProps;
    if (l !== r) {
        e = t.stateNode,
        Lt(Ke.current);
        var o = null;
        switch (n) {
        case "input":
            l = to(e, l),
            r = to(e, r),
            o = [];
            break;
        case "select":
            l = G({}, l, {
                value: void 0
            }),
            r = G({}, r, {
                value: void 0
            }),
            o = [];
            break;
        case "textarea":
            l = lo(e, l),
            r = lo(e, r),
            o = [];
            break;
        default:
            typeof l.onClick != "function" && typeof r.onClick == "function" && (e.onclick = Wr)
        }
        io(n, r);
        var i;
        n = null;
        for (c in l)
            if (!r.hasOwnProperty(c) && l.hasOwnProperty(c) && l[c] != null)
                if (c === "style") {
                    var u = l[c];
                    for (i in u)
                        u.hasOwnProperty(i) && (n || (n = {}),
                        n[i] = "")
                } else
                    c !== "dangerouslySetInnerHTML" && c !== "children" && c !== "suppressContentEditableWarning" && c !== "suppressHydrationWarning" && c !== "autoFocus" && (In.hasOwnProperty(c) ? o || (o = []) : (o = o || []).push(c, null));
        for (c in r) {
            var s = r[c];
            if (u = l != null ? l[c] : void 0,
            r.hasOwnProperty(c) && s !== u && (s != null || u != null))
                if (c === "style")
                    if (u) {
                        for (i in u)
                            !u.hasOwnProperty(i) || s && s.hasOwnProperty(i) || (n || (n = {}),
                            n[i] = "");
                        for (i in s)
                            s.hasOwnProperty(i) && u[i] !== s[i] && (n || (n = {}),
                            n[i] = s[i])
                    } else
                        n || (o || (o = []),
                        o.push(c, n)),
                        n = s;
                else
                    c === "dangerouslySetInnerHTML" ? (s = s ? s.__html : void 0,
                    u = u ? u.__html : void 0,
                    s != null && u !== s && (o = o || []).push(c, s)) : c === "children" ? typeof s != "string" && typeof s != "number" || (o = o || []).push(c, "" + s) : c !== "suppressContentEditableWarning" && c !== "suppressHydrationWarning" && (In.hasOwnProperty(c) ? (s != null && c === "onScroll" && V("scroll", e),
                    o || u === s || (o = [])) : (o = o || []).push(c, s))
        }
        n && (o = o || []).push("style", n);
        var c = o;
        (t.updateQueue = c) && (t.flags |= 4)
    }
}
;
Va = function(e, t, n, r) {
    n !== r && (t.flags |= 4)
}
;
function Sn(e, t) {
    if (!Q)
        switch (e.tailMode) {
        case "hidden":
            t = e.tail;
            for (var n = null; t !== null; )
                t.alternate !== null && (n = t),
                t = t.sibling;
            n === null ? e.tail = null : n.sibling = null;
            break;
        case "collapsed":
            n = e.tail;
            for (var r = null; n !== null; )
                n.alternate !== null && (r = n),
                n = n.sibling;
            r === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : r.sibling = null
        }
}
function ue(e) {
    var t = e.alternate !== null && e.alternate.child === e.child
      , n = 0
      , r = 0;
    if (t)
        for (var l = e.child; l !== null; )
            n |= l.lanes | l.childLanes,
            r |= l.subtreeFlags & 14680064,
            r |= l.flags & 14680064,
            l.return = e,
            l = l.sibling;
    else
        for (l = e.child; l !== null; )
            n |= l.lanes | l.childLanes,
            r |= l.subtreeFlags,
            r |= l.flags,
            l.return = e,
            l = l.sibling;
    return e.subtreeFlags |= r,
    e.childLanes = n,
    t
}
function dd(e, t, n) {
    var r = t.pendingProps;
    switch (ci(t),
    t.tag) {
    case 2:
    case 16:
    case 15:
    case 0:
    case 11:
    case 7:
    case 8:
    case 12:
    case 9:
    case 14:
        return ue(t),
        null;
    case 1:
        return ge(t.type) && Qr(),
        ue(t),
        null;
    case 3:
        return r = t.stateNode,
        cn(),
        B(ye),
        B(ce),
        wi(),
        r.pendingContext && (r.context = r.pendingContext,
        r.pendingContext = null),
        (e === null || e.child === null) && (yr(t) ? t.flags |= 4 : e === null || e.memoizedState.isDehydrated && !(t.flags & 256) || (t.flags |= 1024,
        Ue !== null && (Bo(Ue),
        Ue = null))),
        Fo(e, t),
        ue(t),
        null;
    case 5:
        gi(t);
        var l = Lt(Gn.current);
        if (n = t.type,
        e !== null && t.stateNode != null)
            $a(e, t, n, r, l),
            e.ref !== t.ref && (t.flags |= 512,
            t.flags |= 2097152);
        else {
            if (!r) {
                if (t.stateNode === null)
                    throw Error(g(166));
                return ue(t),
                null
            }
            if (e = Lt(Ke.current),
            yr(t)) {
                r = t.stateNode,
                n = t.type;
                var o = t.memoizedProps;
                switch (r[We] = t,
                r[Yn] = o,
                e = (t.mode & 1) !== 0,
                n) {
                case "dialog":
                    V("cancel", r),
                    V("close", r);
                    break;
                case "iframe":
                case "object":
                case "embed":
                    V("load", r);
                    break;
                case "video":
                case "audio":
                    for (l = 0; l < Pn.length; l++)
                        V(Pn[l], r);
                    break;
                case "source":
                    V("error", r);
                    break;
                case "img":
                case "image":
                case "link":
                    V("error", r),
                    V("load", r);
                    break;
                case "details":
                    V("toggle", r);
                    break;
                case "input":
                    Hi(r, o),
                    V("invalid", r);
                    break;
                case "select":
                    r._wrapperState = {
                        wasMultiple: !!o.multiple
                    },
                    V("invalid", r);
                    break;
                case "textarea":
                    Qi(r, o),
                    V("invalid", r)
                }
                io(n, o),
                l = null;
                for (var i in o)
                    if (o.hasOwnProperty(i)) {
                        var u = o[i];
                        i === "children" ? typeof u == "string" ? r.textContent !== u && (o.suppressHydrationWarning !== !0 && vr(r.textContent, u, e),
                        l = ["children", u]) : typeof u == "number" && r.textContent !== "" + u && (o.suppressHydrationWarning !== !0 && vr(r.textContent, u, e),
                        l = ["children", "" + u]) : In.hasOwnProperty(i) && u != null && i === "onScroll" && V("scroll", r)
                    }
                switch (n) {
                case "input":
                    sr(r),
                    Wi(r, o, !0);
                    break;
                case "textarea":
                    sr(r),
                    Ki(r);
                    break;
                case "select":
                case "option":
                    break;
                default:
                    typeof o.onClick == "function" && (r.onclick = Wr)
                }
                r = l,
                t.updateQueue = r,
                r !== null && (t.flags |= 4)
            } else {
                i = l.nodeType === 9 ? l : l.ownerDocument,
                e === "http://www.w3.org/1999/xhtml" && (e = hs(n)),
                e === "http://www.w3.org/1999/xhtml" ? n === "script" ? (e = i.createElement("div"),
                e.innerHTML = "<script><\/script>",
                e = e.removeChild(e.firstChild)) : typeof r.is == "string" ? e = i.createElement(n, {
                    is: r.is
                }) : (e = i.createElement(n),
                n === "select" && (i = e,
                r.multiple ? i.multiple = !0 : r.size && (i.size = r.size))) : e = i.createElementNS(e, n),
                e[We] = t,
                e[Yn] = r,
                Aa(e, t, !1, !1),
                t.stateNode = e;
                e: {
                    switch (i = uo(n, r),
                    n) {
                    case "dialog":
                        V("cancel", e),
                        V("close", e),
                        l = r;
                        break;
                    case "iframe":
                    case "object":
                    case "embed":
                        V("load", e),
                        l = r;
                        break;
                    case "video":
                    case "audio":
                        for (l = 0; l < Pn.length; l++)
                            V(Pn[l], e);
                        l = r;
                        break;
                    case "source":
                        V("error", e),
                        l = r;
                        break;
                    case "img":
                    case "image":
                    case "link":
                        V("error", e),
                        V("load", e),
                        l = r;
                        break;
                    case "details":
                        V("toggle", e),
                        l = r;
                        break;
                    case "input":
                        Hi(e, r),
                        l = to(e, r),
                        V("invalid", e);
                        break;
                    case "option":
                        l = r;
                        break;
                    case "select":
                        e._wrapperState = {
                            wasMultiple: !!r.multiple
                        },
                        l = G({}, r, {
                            value: void 0
                        }),
                        V("invalid", e);
                        break;
                    case "textarea":
                        Qi(e, r),
                        l = lo(e, r),
                        V("invalid", e);
                        break;
                    default:
                        l = r
                    }
                    io(n, l),
                    u = l;
                    for (o in u)
                        if (u.hasOwnProperty(o)) {
                            var s = u[o];
                            o === "style" ? gs(e, s) : o === "dangerouslySetInnerHTML" ? (s = s ? s.__html : void 0,
                            s != null && vs(e, s)) : o === "children" ? typeof s == "string" ? (n !== "textarea" || s !== "") && Un(e, s) : typeof s == "number" && Un(e, "" + s) : o !== "suppressContentEditableWarning" && o !== "suppressHydrationWarning" && o !== "autoFocus" && (In.hasOwnProperty(o) ? s != null && o === "onScroll" && V("scroll", e) : s != null && Go(e, o, s, i))
                        }
                    switch (n) {
                    case "input":
                        sr(e),
                        Wi(e, r, !1);
                        break;
                    case "textarea":
                        sr(e),
                        Ki(e);
                        break;
                    case "option":
                        r.value != null && e.setAttribute("value", "" + gt(r.value));
                        break;
                    case "select":
                        e.multiple = !!r.multiple,
                        o = r.value,
                        o != null ? bt(e, !!r.multiple, o, !1) : r.defaultValue != null && bt(e, !!r.multiple, r.defaultValue, !0);
                        break;
                    default:
                        typeof l.onClick == "function" && (e.onclick = Wr)
                    }
                    switch (n) {
                    case "button":
                    case "input":
                    case "select":
                    case "textarea":
                        r = !!r.autoFocus;
                        break e;
                    case "img":
                        r = !0;
                        break e;
                    default:
                        r = !1
                    }
                }
                r && (t.flags |= 4)
            }
            t.ref !== null && (t.flags |= 512,
            t.flags |= 2097152)
        }
        return ue(t),
        null;
    case 6:
        if (e && t.stateNode != null)
            Va(e, t, e.memoizedProps, r);
        else {
            if (typeof r != "string" && t.stateNode === null)
                throw Error(g(166));
            if (n = Lt(Gn.current),
            Lt(Ke.current),
            yr(t)) {
                if (r = t.stateNode,
                n = t.memoizedProps,
                r[We] = t,
                (o = r.nodeValue !== n) && (e = Ce,
                e !== null))
                    switch (e.tag) {
                    case 3:
                        vr(r.nodeValue, n, (e.mode & 1) !== 0);
                        break;
                    case 5:
                        e.memoizedProps.suppressHydrationWarning !== !0 && vr(r.nodeValue, n, (e.mode & 1) !== 0)
                    }
                o && (t.flags |= 4)
            } else
                r = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(r),
                r[We] = t,
                t.stateNode = r
        }
        return ue(t),
        null;
    case 13:
        if (B(Y),
        r = t.memoizedState,
        e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
            if (Q && Ee !== null && t.mode & 1 && !(t.flags & 128))
                oa(),
                sn(),
                t.flags |= 98560,
                o = !1;
            else if (o = yr(t),
            r !== null && r.dehydrated !== null) {
                if (e === null) {
                    if (!o)
                        throw Error(g(318));
                    if (o = t.memoizedState,
                    o = o !== null ? o.dehydrated : null,
                    !o)
                        throw Error(g(317));
                    o[We] = t
                } else
                    sn(),
                    !(t.flags & 128) && (t.memoizedState = null),
                    t.flags |= 4;
                ue(t),
                o = !1
            } else
                Ue !== null && (Bo(Ue),
                Ue = null),
                o = !0;
            if (!o)
                return t.flags & 65536 ? t : null
        }
        return t.flags & 128 ? (t.lanes = n,
        t) : (r = r !== null,
        r !== (e !== null && e.memoizedState !== null) && r && (t.child.flags |= 8192,
        t.mode & 1 && (e === null || Y.current & 1 ? ee === 0 && (ee = 3) : Ti())),
        t.updateQueue !== null && (t.flags |= 4),
        ue(t),
        null);
    case 4:
        return cn(),
        Fo(e, t),
        e === null && Qn(t.stateNode.containerInfo),
        ue(t),
        null;
    case 10:
        return mi(t.type._context),
        ue(t),
        null;
    case 17:
        return ge(t.type) && Qr(),
        ue(t),
        null;
    case 19:
        if (B(Y),
        o = t.memoizedState,
        o === null)
            return ue(t),
            null;
        if (r = (t.flags & 128) !== 0,
        i = o.rendering,
        i === null)
            if (r)
                Sn(o, !1);
            else {
                if (ee !== 0 || e !== null && e.flags & 128)
                    for (e = t.child; e !== null; ) {
                        if (i = qr(e),
                        i !== null) {
                            for (t.flags |= 128,
                            Sn(o, !1),
                            r = i.updateQueue,
                            r !== null && (t.updateQueue = r,
                            t.flags |= 4),
                            t.subtreeFlags = 0,
                            r = n,
                            n = t.child; n !== null; )
                                o = n,
                                e = r,
                                o.flags &= 14680066,
                                i = o.alternate,
                                i === null ? (o.childLanes = 0,
                                o.lanes = e,
                                o.child = null,
                                o.subtreeFlags = 0,
                                o.memoizedProps = null,
                                o.memoizedState = null,
                                o.updateQueue = null,
                                o.dependencies = null,
                                o.stateNode = null) : (o.childLanes = i.childLanes,
                                o.lanes = i.lanes,
                                o.child = i.child,
                                o.subtreeFlags = 0,
                                o.deletions = null,
                                o.memoizedProps = i.memoizedProps,
                                o.memoizedState = i.memoizedState,
                                o.updateQueue = i.updateQueue,
                                o.type = i.type,
                                e = i.dependencies,
                                o.dependencies = e === null ? null : {
                                    lanes: e.lanes,
                                    firstContext: e.firstContext
                                }),
                                n = n.sibling;
                            return A(Y, Y.current & 1 | 2),
                            t.child
                        }
                        e = e.sibling
                    }
                o.tail !== null && J() > dn && (t.flags |= 128,
                r = !0,
                Sn(o, !1),
                t.lanes = 4194304)
            }
        else {
            if (!r)
                if (e = qr(i),
                e !== null) {
                    if (t.flags |= 128,
                    r = !0,
                    n = e.updateQueue,
                    n !== null && (t.updateQueue = n,
                    t.flags |= 4),
                    Sn(o, !0),
                    o.tail === null && o.tailMode === "hidden" && !i.alternate && !Q)
                        return ue(t),
                        null
                } else
                    2 * J() - o.renderingStartTime > dn && n !== 1073741824 && (t.flags |= 128,
                    r = !0,
                    Sn(o, !1),
                    t.lanes = 4194304);
            o.isBackwards ? (i.sibling = t.child,
            t.child = i) : (n = o.last,
            n !== null ? n.sibling = i : t.child = i,
            o.last = i)
        }
        return o.tail !== null ? (t = o.tail,
        o.rendering = t,
        o.tail = t.sibling,
        o.renderingStartTime = J(),
        t.sibling = null,
        n = Y.current,
        A(Y, r ? n & 1 | 2 : n & 1),
        t) : (ue(t),
        null);
    case 22:
    case 23:
        return Li(),
        r = t.memoizedState !== null,
        e !== null && e.memoizedState !== null !== r && (t.flags |= 8192),
        r && t.mode & 1 ? Se & 1073741824 && (ue(t),
        t.subtreeFlags & 6 && (t.flags |= 8192)) : ue(t),
        null;
    case 24:
        return null;
    case 25:
        return null
    }
    throw Error(g(156, t.tag))
}
function pd(e, t) {
    switch (ci(t),
    t.tag) {
    case 1:
        return ge(t.type) && Qr(),
        e = t.flags,
        e & 65536 ? (t.flags = e & -65537 | 128,
        t) : null;
    case 3:
        return cn(),
        B(ye),
        B(ce),
        wi(),
        e = t.flags,
        e & 65536 && !(e & 128) ? (t.flags = e & -65537 | 128,
        t) : null;
    case 5:
        return gi(t),
        null;
    case 13:
        if (B(Y),
        e = t.memoizedState,
        e !== null && e.dehydrated !== null) {
            if (t.alternate === null)
                throw Error(g(340));
            sn()
        }
        return e = t.flags,
        e & 65536 ? (t.flags = e & -65537 | 128,
        t) : null;
    case 19:
        return B(Y),
        null;
    case 4:
        return cn(),
        null;
    case 10:
        return mi(t.type._context),
        null;
    case 22:
    case 23:
        return Li(),
        null;
    case 24:
        return null;
    default:
        return null
    }
}
var xr = !1
  , ae = !1
  , md = typeof WeakSet == "function" ? WeakSet : Set
  , C = null;
function Jt(e, t) {
    var n = e.ref;
    if (n !== null)
        if (typeof n == "function")
            try {
                n(null)
            } catch (r) {
                Z(e, t, r)
            }
        else
            n.current = null
}
function Oo(e, t, n) {
    try {
        n()
    } catch (r) {
        Z(e, t, r)
    }
}
var Ou = !1;
function hd(e, t) {
    if (go = Vr,
    e = Ks(),
    si(e)) {
        if ("selectionStart"in e)
            var n = {
                start: e.selectionStart,
                end: e.selectionEnd
            };
        else
            e: {
                n = (n = e.ownerDocument) && n.defaultView || window;
                var r = n.getSelection && n.getSelection();
                if (r && r.rangeCount !== 0) {
                    n = r.anchorNode;
                    var l = r.anchorOffset
                      , o = r.focusNode;
                    r = r.focusOffset;
                    try {
                        n.nodeType,
                        o.nodeType
                    } catch {
                        n = null;
                        break e
                    }
                    var i = 0
                      , u = -1
                      , s = -1
                      , c = 0
                      , h = 0
                      , m = e
                      , p = null;
                    t: for (; ; ) {
                        for (var w; m !== n || l !== 0 && m.nodeType !== 3 || (u = i + l),
                        m !== o || r !== 0 && m.nodeType !== 3 || (s = i + r),
                        m.nodeType === 3 && (i += m.nodeValue.length),
                        (w = m.firstChild) !== null; )
                            p = m,
                            m = w;
                        for (; ; ) {
                            if (m === e)
                                break t;
                            if (p === n && ++c === l && (u = i),
                            p === o && ++h === r && (s = i),
                            (w = m.nextSibling) !== null)
                                break;
                            m = p,
                            p = m.parentNode
                        }
                        m = w
                    }
                    n = u === -1 || s === -1 ? null : {
                        start: u,
                        end: s
                    }
                } else
                    n = null
            }
        n = n || {
            start: 0,
            end: 0
        }
    } else
        n = null;
    for (wo = {
        focusedElem: e,
        selectionRange: n
    },
    Vr = !1,
    C = t; C !== null; )
        if (t = C,
        e = t.child,
        (t.subtreeFlags & 1028) !== 0 && e !== null)
            e.return = t,
            C = e;
        else
            for (; C !== null; ) {
                t = C;
                try {
                    var k = t.alternate;
                    if (t.flags & 1024)
                        switch (t.tag) {
                        case 0:
                        case 11:
                        case 15:
                            break;
                        case 1:
                            if (k !== null) {
                                var S = k.memoizedProps
                                  , D = k.memoizedState
                                  , f = t.stateNode
                                  , a = f.getSnapshotBeforeUpdate(t.elementType === t.type ? S : De(t.type, S), D);
                                f.__reactInternalSnapshotBeforeUpdate = a
                            }
                            break;
                        case 3:
                            var d = t.stateNode.containerInfo;
                            d.nodeType === 1 ? d.textContent = "" : d.nodeType === 9 && d.documentElement && d.removeChild(d.documentElement);
                            break;
                        case 5:
                        case 6:
                        case 4:
                        case 17:
                            break;
                        default:
                            throw Error(g(163))
                        }
                } catch (y) {
                    Z(t, t.return, y)
                }
                if (e = t.sibling,
                e !== null) {
                    e.return = t.return,
                    C = e;
                    break
                }
                C = t.return
            }
    return k = Ou,
    Ou = !1,
    k
}
function Fn(e, t, n) {
    var r = t.updateQueue;
    if (r = r !== null ? r.lastEffect : null,
    r !== null) {
        var l = r = r.next;
        do {
            if ((l.tag & e) === e) {
                var o = l.destroy;
                l.destroy = void 0,
                o !== void 0 && Oo(t, n, o)
            }
            l = l.next
        } while (l !== r)
    }
}
function hl(e, t) {
    if (t = t.updateQueue,
    t = t !== null ? t.lastEffect : null,
    t !== null) {
        var n = t = t.next;
        do {
            if ((n.tag & e) === e) {
                var r = n.create;
                n.destroy = r()
            }
            n = n.next
        } while (n !== t)
    }
}
function Do(e) {
    var t = e.ref;
    if (t !== null) {
        var n = e.stateNode;
        switch (e.tag) {
        case 5:
            e = n;
            break;
        default:
            e = n
        }
        typeof t == "function" ? t(e) : t.current = e
    }
}
function Ba(e) {
    var t = e.alternate;
    t !== null && (e.alternate = null,
    Ba(t)),
    e.child = null,
    e.deletions = null,
    e.sibling = null,
    e.tag === 5 && (t = e.stateNode,
    t !== null && (delete t[We],
    delete t[Yn],
    delete t[So],
    delete t[Jf],
    delete t[qf])),
    e.stateNode = null,
    e.return = null,
    e.dependencies = null,
    e.memoizedProps = null,
    e.memoizedState = null,
    e.pendingProps = null,
    e.stateNode = null,
    e.updateQueue = null
}
function Ha(e) {
    return e.tag === 5 || e.tag === 3 || e.tag === 4
}
function Du(e) {
    e: for (; ; ) {
        for (; e.sibling === null; ) {
            if (e.return === null || Ha(e.return))
                return null;
            e = e.return
        }
        for (e.sibling.return = e.return,
        e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 18; ) {
            if (e.flags & 2 || e.child === null || e.tag === 4)
                continue e;
            e.child.return = e,
            e = e.child
        }
        if (!(e.flags & 2))
            return e.stateNode
    }
}
function Io(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6)
        e = e.stateNode,
        t ? n.nodeType === 8 ? n.parentNode.insertBefore(e, t) : n.insertBefore(e, t) : (n.nodeType === 8 ? (t = n.parentNode,
        t.insertBefore(e, n)) : (t = n,
        t.appendChild(e)),
        n = n._reactRootContainer,
        n != null || t.onclick !== null || (t.onclick = Wr));
    else if (r !== 4 && (e = e.child,
    e !== null))
        for (Io(e, t, n),
        e = e.sibling; e !== null; )
            Io(e, t, n),
            e = e.sibling
}
function Uo(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6)
        e = e.stateNode,
        t ? n.insertBefore(e, t) : n.appendChild(e);
    else if (r !== 4 && (e = e.child,
    e !== null))
        for (Uo(e, t, n),
        e = e.sibling; e !== null; )
            Uo(e, t, n),
            e = e.sibling
}
var re = null
  , Ie = !1;
function rt(e, t, n) {
    for (n = n.child; n !== null; )
        Wa(e, t, n),
        n = n.sibling
}
function Wa(e, t, n) {
    if (Qe && typeof Qe.onCommitFiberUnmount == "function")
        try {
            Qe.onCommitFiberUnmount(ul, n)
        } catch {}
    switch (n.tag) {
    case 5:
        ae || Jt(n, t);
    case 6:
        var r = re
          , l = Ie;
        re = null,
        rt(e, t, n),
        re = r,
        Ie = l,
        re !== null && (Ie ? (e = re,
        n = n.stateNode,
        e.nodeType === 8 ? e.parentNode.removeChild(n) : e.removeChild(n)) : re.removeChild(n.stateNode));
        break;
    case 18:
        re !== null && (Ie ? (e = re,
        n = n.stateNode,
        e.nodeType === 8 ? Al(e.parentNode, n) : e.nodeType === 1 && Al(e, n),
        Bn(e)) : Al(re, n.stateNode));
        break;
    case 4:
        r = re,
        l = Ie,
        re = n.stateNode.containerInfo,
        Ie = !0,
        rt(e, t, n),
        re = r,
        Ie = l;
        break;
    case 0:
    case 11:
    case 14:
    case 15:
        if (!ae && (r = n.updateQueue,
        r !== null && (r = r.lastEffect,
        r !== null))) {
            l = r = r.next;
            do {
                var o = l
                  , i = o.destroy;
                o = o.tag,
                i !== void 0 && (o & 2 || o & 4) && Oo(n, t, i),
                l = l.next
            } while (l !== r)
        }
        rt(e, t, n);
        break;
    case 1:
        if (!ae && (Jt(n, t),
        r = n.stateNode,
        typeof r.componentWillUnmount == "function"))
            try {
                r.props = n.memoizedProps,
                r.state = n.memoizedState,
                r.componentWillUnmount()
            } catch (u) {
                Z(n, t, u)
            }
        rt(e, t, n);
        break;
    case 21:
        rt(e, t, n);
        break;
    case 22:
        n.mode & 1 ? (ae = (r = ae) || n.memoizedState !== null,
        rt(e, t, n),
        ae = r) : rt(e, t, n);
        break;
    default:
        rt(e, t, n)
    }
}
function Iu(e) {
    var t = e.updateQueue;
    if (t !== null) {
        e.updateQueue = null;
        var n = e.stateNode;
        n === null && (n = e.stateNode = new md),
        t.forEach(function(r) {
            var l = Cd.bind(null, e, r);
            n.has(r) || (n.add(r),
            r.then(l, l))
        })
    }
}
function Oe(e, t) {
    var n = t.deletions;
    if (n !== null)
        for (var r = 0; r < n.length; r++) {
            var l = n[r];
            try {
                var o = e
                  , i = t
                  , u = i;
                e: for (; u !== null; ) {
                    switch (u.tag) {
                    case 5:
                        re = u.stateNode,
                        Ie = !1;
                        break e;
                    case 3:
                        re = u.stateNode.containerInfo,
                        Ie = !0;
                        break e;
                    case 4:
                        re = u.stateNode.containerInfo,
                        Ie = !0;
                        break e
                    }
                    u = u.return
                }
                if (re === null)
                    throw Error(g(160));
                Wa(o, i, l),
                re = null,
                Ie = !1;
                var s = l.alternate;
                s !== null && (s.return = null),
                l.return = null
            } catch (c) {
                Z(l, t, c)
            }
        }
    if (t.subtreeFlags & 12854)
        for (t = t.child; t !== null; )
            Qa(t, e),
            t = t.sibling
}
function Qa(e, t) {
    var n = e.alternate
      , r = e.flags;
    switch (e.tag) {
    case 0:
    case 11:
    case 14:
    case 15:
        if (Oe(t, e),
        Be(e),
        r & 4) {
            try {
                Fn(3, e, e.return),
                hl(3, e)
            } catch (S) {
                Z(e, e.return, S)
            }
            try {
                Fn(5, e, e.return)
            } catch (S) {
                Z(e, e.return, S)
            }
        }
        break;
    case 1:
        Oe(t, e),
        Be(e),
        r & 512 && n !== null && Jt(n, n.return);
        break;
    case 5:
        if (Oe(t, e),
        Be(e),
        r & 512 && n !== null && Jt(n, n.return),
        e.flags & 32) {
            var l = e.stateNode;
            try {
                Un(l, "")
            } catch (S) {
                Z(e, e.return, S)
            }
        }
        if (r & 4 && (l = e.stateNode,
        l != null)) {
            var o = e.memoizedProps
              , i = n !== null ? n.memoizedProps : o
              , u = e.type
              , s = e.updateQueue;
            if (e.updateQueue = null,
            s !== null)
                try {
                    u === "input" && o.type === "radio" && o.name != null && ps(l, o),
                    uo(u, i);
                    var c = uo(u, o);
                    for (i = 0; i < s.length; i += 2) {
                        var h = s[i]
                          , m = s[i + 1];
                        h === "style" ? gs(l, m) : h === "dangerouslySetInnerHTML" ? vs(l, m) : h === "children" ? Un(l, m) : Go(l, h, m, c)
                    }
                    switch (u) {
                    case "input":
                        no(l, o);
                        break;
                    case "textarea":
                        ms(l, o);
                        break;
                    case "select":
                        var p = l._wrapperState.wasMultiple;
                        l._wrapperState.wasMultiple = !!o.multiple;
                        var w = o.value;
                        w != null ? bt(l, !!o.multiple, w, !1) : p !== !!o.multiple && (o.defaultValue != null ? bt(l, !!o.multiple, o.defaultValue, !0) : bt(l, !!o.multiple, o.multiple ? [] : "", !1))
                    }
                    l[Yn] = o
                } catch (S) {
                    Z(e, e.return, S)
                }
        }
        break;
    case 6:
        if (Oe(t, e),
        Be(e),
        r & 4) {
            if (e.stateNode === null)
                throw Error(g(162));
            l = e.stateNode,
            o = e.memoizedProps;
            try {
                l.nodeValue = o
            } catch (S) {
                Z(e, e.return, S)
            }
        }
        break;
    case 3:
        if (Oe(t, e),
        Be(e),
        r & 4 && n !== null && n.memoizedState.isDehydrated)
            try {
                Bn(t.containerInfo)
            } catch (S) {
                Z(e, e.return, S)
            }
        break;
    case 4:
        Oe(t, e),
        Be(e);
        break;
    case 13:
        Oe(t, e),
        Be(e),
        l = e.child,
        l.flags & 8192 && (o = l.memoizedState !== null,
        l.stateNode.isHidden = o,
        !o || l.alternate !== null && l.alternate.memoizedState !== null || (ji = J())),
        r & 4 && Iu(e);
        break;
    case 22:
        if (h = n !== null && n.memoizedState !== null,
        e.mode & 1 ? (ae = (c = ae) || h,
        Oe(t, e),
        ae = c) : Oe(t, e),
        Be(e),
        r & 8192) {
            if (c = e.memoizedState !== null,
            (e.stateNode.isHidden = c) && !h && e.mode & 1)
                for (C = e,
                h = e.child; h !== null; ) {
                    for (m = C = h; C !== null; ) {
                        switch (p = C,
                        w = p.child,
                        p.tag) {
                        case 0:
                        case 11:
                        case 14:
                        case 15:
                            Fn(4, p, p.return);
                            break;
                        case 1:
                            Jt(p, p.return);
                            var k = p.stateNode;
                            if (typeof k.componentWillUnmount == "function") {
                                r = p,
                                n = p.return;
                                try {
                                    t = r,
                                    k.props = t.memoizedProps,
                                    k.state = t.memoizedState,
                                    k.componentWillUnmount()
                                } catch (S) {
                                    Z(r, n, S)
                                }
                            }
                            break;
                        case 5:
                            Jt(p, p.return);
                            break;
                        case 22:
                            if (p.memoizedState !== null) {
                                Au(m);
                                continue
                            }
                        }
                        w !== null ? (w.return = p,
                        C = w) : Au(m)
                    }
                    h = h.sibling
                }
            e: for (h = null,
            m = e; ; ) {
                if (m.tag === 5) {
                    if (h === null) {
                        h = m;
                        try {
                            l = m.stateNode,
                            c ? (o = l.style,
                            typeof o.setProperty == "function" ? o.setProperty("display", "none", "important") : o.display = "none") : (u = m.stateNode,
                            s = m.memoizedProps.style,
                            i = s != null && s.hasOwnProperty("display") ? s.display : null,
                            u.style.display = ys("display", i))
                        } catch (S) {
                            Z(e, e.return, S)
                        }
                    }
                } else if (m.tag === 6) {
                    if (h === null)
                        try {
                            m.stateNode.nodeValue = c ? "" : m.memoizedProps
                        } catch (S) {
                            Z(e, e.return, S)
                        }
                } else if ((m.tag !== 22 && m.tag !== 23 || m.memoizedState === null || m === e) && m.child !== null) {
                    m.child.return = m,
                    m = m.child;
                    continue
                }
                if (m === e)
                    break e;
                for (; m.sibling === null; ) {
                    if (m.return === null || m.return === e)
                        break e;
                    h === m && (h = null),
                    m = m.return
                }
                h === m && (h = null),
                m.sibling.return = m.return,
                m = m.sibling
            }
        }
        break;
    case 19:
        Oe(t, e),
        Be(e),
        r & 4 && Iu(e);
        break;
    case 21:
        break;
    default:
        Oe(t, e),
        Be(e)
    }
}
function Be(e) {
    var t = e.flags;
    if (t & 2) {
        try {
            e: {
                for (var n = e.return; n !== null; ) {
                    if (Ha(n)) {
                        var r = n;
                        break e
                    }
                    n = n.return
                }
                throw Error(g(160))
            }
            switch (r.tag) {
            case 5:
                var l = r.stateNode;
                r.flags & 32 && (Un(l, ""),
                r.flags &= -33);
                var o = Du(e);
                Uo(e, o, l);
                break;
            case 3:
            case 4:
                var i = r.stateNode.containerInfo
                  , u = Du(e);
                Io(e, u, i);
                break;
            default:
                throw Error(g(161))
            }
        } catch (s) {
            Z(e, e.return, s)
        }
        e.flags &= -3
    }
    t & 4096 && (e.flags &= -4097)
}
function vd(e, t, n) {
    C = e,
    Ka(e)
}
function Ka(e, t, n) {
    for (var r = (e.mode & 1) !== 0; C !== null; ) {
        var l = C
          , o = l.child;
        if (l.tag === 22 && r) {
            var i = l.memoizedState !== null || xr;
            if (!i) {
                var u = l.alternate
                  , s = u !== null && u.memoizedState !== null || ae;
                u = xr;
                var c = ae;
                if (xr = i,
                (ae = s) && !c)
                    for (C = l; C !== null; )
                        i = C,
                        s = i.child,
                        i.tag === 22 && i.memoizedState !== null ? $u(l) : s !== null ? (s.return = i,
                        C = s) : $u(l);
                for (; o !== null; )
                    C = o,
                    Ka(o),
                    o = o.sibling;
                C = l,
                xr = u,
                ae = c
            }
            Uu(e)
        } else
            l.subtreeFlags & 8772 && o !== null ? (o.return = l,
            C = o) : Uu(e)
    }
}
function Uu(e) {
    for (; C !== null; ) {
        var t = C;
        if (t.flags & 8772) {
            var n = t.alternate;
            try {
                if (t.flags & 8772)
                    switch (t.tag) {
                    case 0:
                    case 11:
                    case 15:
                        ae || hl(5, t);
                        break;
                    case 1:
                        var r = t.stateNode;
                        if (t.flags & 4 && !ae)
                            if (n === null)
                                r.componentDidMount();
                            else {
                                var l = t.elementType === t.type ? n.memoizedProps : De(t.type, n.memoizedProps);
                                r.componentDidUpdate(l, n.memoizedState, r.__reactInternalSnapshotBeforeUpdate)
                            }
                        var o = t.updateQueue;
                        o !== null && Su(t, o, r);
                        break;
                    case 3:
                        var i = t.updateQueue;
                        if (i !== null) {
                            if (n = null,
                            t.child !== null)
                                switch (t.child.tag) {
                                case 5:
                                    n = t.child.stateNode;
                                    break;
                                case 1:
                                    n = t.child.stateNode
                                }
                            Su(t, i, n)
                        }
                        break;
                    case 5:
                        var u = t.stateNode;
                        if (n === null && t.flags & 4) {
                            n = u;
                            var s = t.memoizedProps;
                            switch (t.type) {
                            case "button":
                            case "input":
                            case "select":
                            case "textarea":
                                s.autoFocus && n.focus();
                                break;
                            case "img":
                                s.src && (n.src = s.src)
                            }
                        }
                        break;
                    case 6:
                        break;
                    case 4:
                        break;
                    case 12:
                        break;
                    case 13:
                        if (t.memoizedState === null) {
                            var c = t.alternate;
                            if (c !== null) {
                                var h = c.memoizedState;
                                if (h !== null) {
                                    var m = h.dehydrated;
                                    m !== null && Bn(m)
                                }
                            }
                        }
                        break;
                    case 19:
                    case 17:
                    case 21:
                    case 22:
                    case 23:
                    case 25:
                        break;
                    default:
                        throw Error(g(163))
                    }
                ae || t.flags & 512 && Do(t)
            } catch (p) {
                Z(t, t.return, p)
            }
        }
        if (t === e) {
            C = null;
            break
        }
        if (n = t.sibling,
        n !== null) {
            n.return = t.return,
            C = n;
            break
        }
        C = t.return
    }
}
function Au(e) {
    for (; C !== null; ) {
        var t = C;
        if (t === e) {
            C = null;
            break
        }
        var n = t.sibling;
        if (n !== null) {
            n.return = t.return,
            C = n;
            break
        }
        C = t.return
    }
}
function $u(e) {
    for (; C !== null; ) {
        var t = C;
        try {
            switch (t.tag) {
            case 0:
            case 11:
            case 15:
                var n = t.return;
                try {
                    hl(4, t)
                } catch (s) {
                    Z(t, n, s)
                }
                break;
            case 1:
                var r = t.stateNode;
                if (typeof r.componentDidMount == "function") {
                    var l = t.return;
                    try {
                        r.componentDidMount()
                    } catch (s) {
                        Z(t, l, s)
                    }
                }
                var o = t.return;
                try {
                    Do(t)
                } catch (s) {
                    Z(t, o, s)
                }
                break;
            case 5:
                var i = t.return;
                try {
                    Do(t)
                } catch (s) {
                    Z(t, i, s)
                }
            }
        } catch (s) {
            Z(t, t.return, s)
        }
        if (t === e) {
            C = null;
            break
        }
        var u = t.sibling;
        if (u !== null) {
            u.return = t.return,
            C = u;
            break
        }
        C = t.return
    }
}
var yd = Math.ceil
  , tl = nt.ReactCurrentDispatcher
  , _i = nt.ReactCurrentOwner
  , Te = nt.ReactCurrentBatchConfig
  , F = 0
  , ne = null
  , q = null
  , le = 0
  , Se = 0
  , qt = kt(0)
  , ee = 0
  , bn = null
  , Dt = 0
  , vl = 0
  , Pi = 0
  , On = null
  , he = null
  , ji = 0
  , dn = 1 / 0
  , Ye = null
  , nl = !1
  , Ao = null
  , ht = null
  , kr = !1
  , at = null
  , rl = 0
  , Dn = 0
  , $o = null
  , Mr = -1
  , Fr = 0;
function de() {
    return F & 6 ? J() : Mr !== -1 ? Mr : Mr = J()
}
function vt(e) {
    return e.mode & 1 ? F & 2 && le !== 0 ? le & -le : ed.transition !== null ? (Fr === 0 && (Fr = Ls()),
    Fr) : (e = O,
    e !== 0 || (e = window.event,
    e = e === void 0 ? 16 : Is(e.type)),
    e) : 1
}
function $e(e, t, n, r) {
    if (50 < Dn)
        throw Dn = 0,
        $o = null,
        Error(g(185));
    tr(e, n, r),
    (!(F & 2) || e !== ne) && (e === ne && (!(F & 2) && (vl |= n),
    ee === 4 && ut(e, le)),
    we(e, r),
    n === 1 && F === 0 && !(t.mode & 1) && (dn = J() + 500,
    dl && St()))
}
function we(e, t) {
    var n = e.callbackNode;
    bc(e, t);
    var r = $r(e, e === ne ? le : 0);
    if (r === 0)
        n !== null && Gi(n),
        e.callbackNode = null,
        e.callbackPriority = 0;
    else if (t = r & -r,
    e.callbackPriority !== t) {
        if (n != null && Gi(n),
        t === 1)
            e.tag === 0 ? bf(Vu.bind(null, e)) : na(Vu.bind(null, e)),
            Gf(function() {
                !(F & 6) && St()
            }),
            n = null;
        else {
            switch (Ts(r)) {
            case 1:
                n = ei;
                break;
            case 4:
                n = js;
                break;
            case 16:
                n = Ar;
                break;
            case 536870912:
                n = zs;
                break;
            default:
                n = Ar
            }
            n = ec(n, Ya.bind(null, e))
        }
        e.callbackPriority = t,
        e.callbackNode = n
    }
}
function Ya(e, t) {
    if (Mr = -1,
    Fr = 0,
    F & 6)
        throw Error(g(327));
    var n = e.callbackNode;
    if (ln() && e.callbackNode !== n)
        return null;
    var r = $r(e, e === ne ? le : 0);
    if (r === 0)
        return null;
    if (r & 30 || r & e.expiredLanes || t)
        t = ll(e, r);
    else {
        t = r;
        var l = F;
        F |= 2;
        var o = Ga();
        (ne !== e || le !== t) && (Ye = null,
        dn = J() + 500,
        Tt(e, t));
        do
            try {
                xd();
                break
            } catch (u) {
                Xa(e, u)
            }
        while (!0);
        pi(),
        tl.current = o,
        F = l,
        q !== null ? t = 0 : (ne = null,
        le = 0,
        t = ee)
    }
    if (t !== 0) {
        if (t === 2 && (l = po(e),
        l !== 0 && (r = l,
        t = Vo(e, l))),
        t === 1)
            throw n = bn,
            Tt(e, 0),
            ut(e, r),
            we(e, J()),
            n;
        if (t === 6)
            ut(e, r);
        else {
            if (l = e.current.alternate,
            !(r & 30) && !gd(l) && (t = ll(e, r),
            t === 2 && (o = po(e),
            o !== 0 && (r = o,
            t = Vo(e, o))),
            t === 1))
                throw n = bn,
                Tt(e, 0),
                ut(e, r),
                we(e, J()),
                n;
            switch (e.finishedWork = l,
            e.finishedLanes = r,
            t) {
            case 0:
            case 1:
                throw Error(g(345));
            case 2:
                Pt(e, he, Ye);
                break;
            case 3:
                if (ut(e, r),
                (r & 130023424) === r && (t = ji + 500 - J(),
                10 < t)) {
                    if ($r(e, 0) !== 0)
                        break;
                    if (l = e.suspendedLanes,
                    (l & r) !== r) {
                        de(),
                        e.pingedLanes |= e.suspendedLanes & l;
                        break
                    }
                    e.timeoutHandle = ko(Pt.bind(null, e, he, Ye), t);
                    break
                }
                Pt(e, he, Ye);
                break;
            case 4:
                if (ut(e, r),
                (r & 4194240) === r)
                    break;
                for (t = e.eventTimes,
                l = -1; 0 < r; ) {
                    var i = 31 - Ae(r);
                    o = 1 << i,
                    i = t[i],
                    i > l && (l = i),
                    r &= ~o
                }
                if (r = l,
                r = J() - r,
                r = (120 > r ? 120 : 480 > r ? 480 : 1080 > r ? 1080 : 1920 > r ? 1920 : 3e3 > r ? 3e3 : 4320 > r ? 4320 : 1960 * yd(r / 1960)) - r,
                10 < r) {
                    e.timeoutHandle = ko(Pt.bind(null, e, he, Ye), r);
                    break
                }
                Pt(e, he, Ye);
                break;
            case 5:
                Pt(e, he, Ye);
                break;
            default:
                throw Error(g(329))
            }
        }
    }
    return we(e, J()),
    e.callbackNode === n ? Ya.bind(null, e) : null
}
function Vo(e, t) {
    var n = On;
    return e.current.memoizedState.isDehydrated && (Tt(e, t).flags |= 256),
    e = ll(e, t),
    e !== 2 && (t = he,
    he = n,
    t !== null && Bo(t)),
    e
}
function Bo(e) {
    he === null ? he = e : he.push.apply(he, e)
}
function gd(e) {
    for (var t = e; ; ) {
        if (t.flags & 16384) {
            var n = t.updateQueue;
            if (n !== null && (n = n.stores,
            n !== null))
                for (var r = 0; r < n.length; r++) {
                    var l = n[r]
                      , o = l.getSnapshot;
                    l = l.value;
                    try {
                        if (!Ve(o(), l))
                            return !1
                    } catch {
                        return !1
                    }
                }
        }
        if (n = t.child,
        t.subtreeFlags & 16384 && n !== null)
            n.return = t,
            t = n;
        else {
            if (t === e)
                break;
            for (; t.sibling === null; ) {
                if (t.return === null || t.return === e)
                    return !0;
                t = t.return
            }
            t.sibling.return = t.return,
            t = t.sibling
        }
    }
    return !0
}
function ut(e, t) {
    for (t &= ~Pi,
    t &= ~vl,
    e.suspendedLanes |= t,
    e.pingedLanes &= ~t,
    e = e.expirationTimes; 0 < t; ) {
        var n = 31 - Ae(t)
          , r = 1 << n;
        e[n] = -1,
        t &= ~r
    }
}
function Vu(e) {
    if (F & 6)
        throw Error(g(327));
    ln();
    var t = $r(e, 0);
    if (!(t & 1))
        return we(e, J()),
        null;
    var n = ll(e, t);
    if (e.tag !== 0 && n === 2) {
        var r = po(e);
        r !== 0 && (t = r,
        n = Vo(e, r))
    }
    if (n === 1)
        throw n = bn,
        Tt(e, 0),
        ut(e, t),
        we(e, J()),
        n;
    if (n === 6)
        throw Error(g(345));
    return e.finishedWork = e.current.alternate,
    e.finishedLanes = t,
    Pt(e, he, Ye),
    we(e, J()),
    null
}
function zi(e, t) {
    var n = F;
    F |= 1;
    try {
        return e(t)
    } finally {
        F = n,
        F === 0 && (dn = J() + 500,
        dl && St())
    }
}
function It(e) {
    at !== null && at.tag === 0 && !(F & 6) && ln();
    var t = F;
    F |= 1;
    var n = Te.transition
      , r = O;
    try {
        if (Te.transition = null,
        O = 1,
        e)
            return e()
    } finally {
        O = r,
        Te.transition = n,
        F = t,
        !(F & 6) && St()
    }
}
function Li() {
    Se = qt.current,
    B(qt)
}
function Tt(e, t) {
    e.finishedWork = null,
    e.finishedLanes = 0;
    var n = e.timeoutHandle;
    if (n !== -1 && (e.timeoutHandle = -1,
    Xf(n)),
    q !== null)
        for (n = q.return; n !== null; ) {
            var r = n;
            switch (ci(r),
            r.tag) {
            case 1:
                r = r.type.childContextTypes,
                r != null && Qr();
                break;
            case 3:
                cn(),
                B(ye),
                B(ce),
                wi();
                break;
            case 5:
                gi(r);
                break;
            case 4:
                cn();
                break;
            case 13:
                B(Y);
                break;
            case 19:
                B(Y);
                break;
            case 10:
                mi(r.type._context);
                break;
            case 22:
            case 23:
                Li()
            }
            n = n.return
        }
    if (ne = e,
    q = e = yt(e.current, null),
    le = Se = t,
    ee = 0,
    bn = null,
    Pi = vl = Dt = 0,
    he = On = null,
    zt !== null) {
        for (t = 0; t < zt.length; t++)
            if (n = zt[t],
            r = n.interleaved,
            r !== null) {
                n.interleaved = null;
                var l = r.next
                  , o = n.pending;
                if (o !== null) {
                    var i = o.next;
                    o.next = l,
                    r.next = i
                }
                n.pending = r
            }
        zt = null
    }
    return e
}
function Xa(e, t) {
    do {
        var n = q;
        try {
            if (pi(),
            Lr.current = el,
            br) {
                for (var r = X.memoizedState; r !== null; ) {
                    var l = r.queue;
                    l !== null && (l.pending = null),
                    r = r.next
                }
                br = !1
            }
            if (Ot = 0,
            te = b = X = null,
            Mn = !1,
            Zn = 0,
            _i.current = null,
            n === null || n.return === null) {
                ee = 1,
                bn = t,
                q = null;
                break
            }
            e: {
                var o = e
                  , i = n.return
                  , u = n
                  , s = t;
                if (t = le,
                u.flags |= 32768,
                s !== null && typeof s == "object" && typeof s.then == "function") {
                    var c = s
                      , h = u
                      , m = h.tag;
                    if (!(h.mode & 1) && (m === 0 || m === 11 || m === 15)) {
                        var p = h.alternate;
                        p ? (h.updateQueue = p.updateQueue,
                        h.memoizedState = p.memoizedState,
                        h.lanes = p.lanes) : (h.updateQueue = null,
                        h.memoizedState = null)
                    }
                    var w = ju(i);
                    if (w !== null) {
                        w.flags &= -257,
                        zu(w, i, u, o, t),
                        w.mode & 1 && Pu(o, c, t),
                        t = w,
                        s = c;
                        var k = t.updateQueue;
                        if (k === null) {
                            var S = new Set;
                            S.add(s),
                            t.updateQueue = S
                        } else
                            k.add(s);
                        break e
                    } else {
                        if (!(t & 1)) {
                            Pu(o, c, t),
                            Ti();
                            break e
                        }
                        s = Error(g(426))
                    }
                } else if (Q && u.mode & 1) {
                    var D = ju(i);
                    if (D !== null) {
                        !(D.flags & 65536) && (D.flags |= 256),
                        zu(D, i, u, o, t),
                        fi(fn(s, u));
                        break e
                    }
                }
                o = s = fn(s, u),
                ee !== 4 && (ee = 2),
                On === null ? On = [o] : On.push(o),
                o = i;
                do {
                    switch (o.tag) {
                    case 3:
                        o.flags |= 65536,
                        t &= -t,
                        o.lanes |= t;
                        var f = Ta(o, s, t);
                        ku(o, f);
                        break e;
                    case 1:
                        u = s;
                        var a = o.type
                          , d = o.stateNode;
                        if (!(o.flags & 128) && (typeof a.getDerivedStateFromError == "function" || d !== null && typeof d.componentDidCatch == "function" && (ht === null || !ht.has(d)))) {
                            o.flags |= 65536,
                            t &= -t,
                            o.lanes |= t;
                            var y = Ra(o, u, t);
                            ku(o, y);
                            break e
                        }
                    }
                    o = o.return
                } while (o !== null)
            }
            Ja(n)
        } catch (E) {
            t = E,
            q === n && n !== null && (q = n = n.return);
            continue
        }
        break
    } while (!0)
}
function Ga() {
    var e = tl.current;
    return tl.current = el,
    e === null ? el : e
}
function Ti() {
    (ee === 0 || ee === 3 || ee === 2) && (ee = 4),
    ne === null || !(Dt & 268435455) && !(vl & 268435455) || ut(ne, le)
}
function ll(e, t) {
    var n = F;
    F |= 2;
    var r = Ga();
    (ne !== e || le !== t) && (Ye = null,
    Tt(e, t));
    do
        try {
            wd();
            break
        } catch (l) {
            Xa(e, l)
        }
    while (!0);
    if (pi(),
    F = n,
    tl.current = r,
    q !== null)
        throw Error(g(261));
    return ne = null,
    le = 0,
    ee
}
function wd() {
    for (; q !== null; )
        Za(q)
}
function xd() {
    for (; q !== null && !Wc(); )
        Za(q)
}
function Za(e) {
    var t = ba(e.alternate, e, Se);
    e.memoizedProps = e.pendingProps,
    t === null ? Ja(e) : q = t,
    _i.current = null
}
function Ja(e) {
    var t = e;
    do {
        var n = t.alternate;
        if (e = t.return,
        t.flags & 32768) {
            if (n = pd(n, t),
            n !== null) {
                n.flags &= 32767,
                q = n;
                return
            }
            if (e !== null)
                e.flags |= 32768,
                e.subtreeFlags = 0,
                e.deletions = null;
            else {
                ee = 6,
                q = null;
                return
            }
        } else if (n = dd(n, t, Se),
        n !== null) {
            q = n;
            return
        }
        if (t = t.sibling,
        t !== null) {
            q = t;
            return
        }
        q = t = e
    } while (t !== null);
    ee === 0 && (ee = 5)
}
function Pt(e, t, n) {
    var r = O
      , l = Te.transition;
    try {
        Te.transition = null,
        O = 1,
        kd(e, t, n, r)
    } finally {
        Te.transition = l,
        O = r
    }
    return null
}
function kd(e, t, n, r) {
    do
        ln();
    while (at !== null);
    if (F & 6)
        throw Error(g(327));
    n = e.finishedWork;
    var l = e.finishedLanes;
    if (n === null)
        return null;
    if (e.finishedWork = null,
    e.finishedLanes = 0,
    n === e.current)
        throw Error(g(177));
    e.callbackNode = null,
    e.callbackPriority = 0;
    var o = n.lanes | n.childLanes;
    if (ef(e, o),
    e === ne && (q = ne = null,
    le = 0),
    !(n.subtreeFlags & 2064) && !(n.flags & 2064) || kr || (kr = !0,
    ec(Ar, function() {
        return ln(),
        null
    })),
    o = (n.flags & 15990) !== 0,
    n.subtreeFlags & 15990 || o) {
        o = Te.transition,
        Te.transition = null;
        var i = O;
        O = 1;
        var u = F;
        F |= 4,
        _i.current = null,
        hd(e, n),
        Qa(n, e),
        Vf(wo),
        Vr = !!go,
        wo = go = null,
        e.current = n,
        vd(n),
        Qc(),
        F = u,
        O = i,
        Te.transition = o
    } else
        e.current = n;
    if (kr && (kr = !1,
    at = e,
    rl = l),
    o = e.pendingLanes,
    o === 0 && (ht = null),
    Xc(n.stateNode),
    we(e, J()),
    t !== null)
        for (r = e.onRecoverableError,
        n = 0; n < t.length; n++)
            l = t[n],
            r(l.value, {
                componentStack: l.stack,
                digest: l.digest
            });
    if (nl)
        throw nl = !1,
        e = Ao,
        Ao = null,
        e;
    return rl & 1 && e.tag !== 0 && ln(),
    o = e.pendingLanes,
    o & 1 ? e === $o ? Dn++ : (Dn = 0,
    $o = e) : Dn = 0,
    St(),
    null
}
function ln() {
    if (at !== null) {
        var e = Ts(rl)
          , t = Te.transition
          , n = O;
        try {
            if (Te.transition = null,
            O = 16 > e ? 16 : e,
            at === null)
                var r = !1;
            else {
                if (e = at,
                at = null,
                rl = 0,
                F & 6)
                    throw Error(g(331));
                var l = F;
                for (F |= 4,
                C = e.current; C !== null; ) {
                    var o = C
                      , i = o.child;
                    if (C.flags & 16) {
                        var u = o.deletions;
                        if (u !== null) {
                            for (var s = 0; s < u.length; s++) {
                                var c = u[s];
                                for (C = c; C !== null; ) {
                                    var h = C;
                                    switch (h.tag) {
                                    case 0:
                                    case 11:
                                    case 15:
                                        Fn(8, h, o)
                                    }
                                    var m = h.child;
                                    if (m !== null)
                                        m.return = h,
                                        C = m;
                                    else
                                        for (; C !== null; ) {
                                            h = C;
                                            var p = h.sibling
                                              , w = h.return;
                                            if (Ba(h),
                                            h === c) {
                                                C = null;
                                                break
                                            }
                                            if (p !== null) {
                                                p.return = w,
                                                C = p;
                                                break
                                            }
                                            C = w
                                        }
                                }
                            }
                            var k = o.alternate;
                            if (k !== null) {
                                var S = k.child;
                                if (S !== null) {
                                    k.child = null;
                                    do {
                                        var D = S.sibling;
                                        S.sibling = null,
                                        S = D
                                    } while (S !== null)
                                }
                            }
                            C = o
                        }
                    }
                    if (o.subtreeFlags & 2064 && i !== null)
                        i.return = o,
                        C = i;
                    else
                        e: for (; C !== null; ) {
                            if (o = C,
                            o.flags & 2048)
                                switch (o.tag) {
                                case 0:
                                case 11:
                                case 15:
                                    Fn(9, o, o.return)
                                }
                            var f = o.sibling;
                            if (f !== null) {
                                f.return = o.return,
                                C = f;
                                break e
                            }
                            C = o.return
                        }
                }
                var a = e.current;
                for (C = a; C !== null; ) {
                    i = C;
                    var d = i.child;
                    if (i.subtreeFlags & 2064 && d !== null)
                        d.return = i,
                        C = d;
                    else
                        e: for (i = a; C !== null; ) {
                            if (u = C,
                            u.flags & 2048)
                                try {
                                    switch (u.tag) {
                                    case 0:
                                    case 11:
                                    case 15:
                                        hl(9, u)
                                    }
                                } catch (E) {
                                    Z(u, u.return, E)
                                }
                            if (u === i) {
                                C = null;
                                break e
                            }
                            var y = u.sibling;
                            if (y !== null) {
                                y.return = u.return,
                                C = y;
                                break e
                            }
                            C = u.return
                        }
                }
                if (F = l,
                St(),
                Qe && typeof Qe.onPostCommitFiberRoot == "function")
                    try {
                        Qe.onPostCommitFiberRoot(ul, e)
                    } catch {}
                r = !0
            }
            return r
        } finally {
            O = n,
            Te.transition = t
        }
    }
    return !1
}
function Bu(e, t, n) {
    t = fn(n, t),
    t = Ta(e, t, 1),
    e = mt(e, t, 1),
    t = de(),
    e !== null && (tr(e, 1, t),
    we(e, t))
}
function Z(e, t, n) {
    if (e.tag === 3)
        Bu(e, e, n);
    else
        for (; t !== null; ) {
            if (t.tag === 3) {
                Bu(t, e, n);
                break
            } else if (t.tag === 1) {
                var r = t.stateNode;
                if (typeof t.type.getDerivedStateFromError == "function" || typeof r.componentDidCatch == "function" && (ht === null || !ht.has(r))) {
                    e = fn(n, e),
                    e = Ra(t, e, 1),
                    t = mt(t, e, 1),
                    e = de(),
                    t !== null && (tr(t, 1, e),
                    we(t, e));
                    break
                }
            }
            t = t.return
        }
}
function Sd(e, t, n) {
    var r = e.pingCache;
    r !== null && r.delete(t),
    t = de(),
    e.pingedLanes |= e.suspendedLanes & n,
    ne === e && (le & n) === n && (ee === 4 || ee === 3 && (le & 130023424) === le && 500 > J() - ji ? Tt(e, 0) : Pi |= n),
    we(e, t)
}
function qa(e, t) {
    t === 0 && (e.mode & 1 ? (t = fr,
    fr <<= 1,
    !(fr & 130023424) && (fr = 4194304)) : t = 1);
    var n = de();
    e = et(e, t),
    e !== null && (tr(e, t, n),
    we(e, n))
}
function Ed(e) {
    var t = e.memoizedState
      , n = 0;
    t !== null && (n = t.retryLane),
    qa(e, n)
}
function Cd(e, t) {
    var n = 0;
    switch (e.tag) {
    case 13:
        var r = e.stateNode
          , l = e.memoizedState;
        l !== null && (n = l.retryLane);
        break;
    case 19:
        r = e.stateNode;
        break;
    default:
        throw Error(g(314))
    }
    r !== null && r.delete(t),
    qa(e, n)
}
var ba;
ba = function(e, t, n) {
    if (e !== null)
        if (e.memoizedProps !== t.pendingProps || ye.current)
            ve = !0;
        else {
            if (!(e.lanes & n) && !(t.flags & 128))
                return ve = !1,
                fd(e, t, n);
            ve = !!(e.flags & 131072)
        }
    else
        ve = !1,
        Q && t.flags & 1048576 && ra(t, Xr, t.index);
    switch (t.lanes = 0,
    t.tag) {
    case 2:
        var r = t.type;
        Rr(e, t),
        e = t.pendingProps;
        var l = un(t, ce.current);
        rn(t, n),
        l = ki(null, t, r, e, l, n);
        var o = Si();
        return t.flags |= 1,
        typeof l == "object" && l !== null && typeof l.render == "function" && l.$$typeof === void 0 ? (t.tag = 1,
        t.memoizedState = null,
        t.updateQueue = null,
        ge(r) ? (o = !0,
        Kr(t)) : o = !1,
        t.memoizedState = l.state !== null && l.state !== void 0 ? l.state : null,
        vi(t),
        l.updater = ml,
        t.stateNode = l,
        l._reactInternals = t,
        jo(t, r, e, n),
        t = To(null, t, r, !0, o, n)) : (t.tag = 0,
        Q && o && ai(t),
        fe(null, t, l, n),
        t = t.child),
        t;
    case 16:
        r = t.elementType;
        e: {
            switch (Rr(e, t),
            e = t.pendingProps,
            l = r._init,
            r = l(r._payload),
            t.type = r,
            l = t.tag = _d(r),
            e = De(r, e),
            l) {
            case 0:
                t = Lo(null, t, r, e, n);
                break e;
            case 1:
                t = Ru(null, t, r, e, n);
                break e;
            case 11:
                t = Lu(null, t, r, e, n);
                break e;
            case 14:
                t = Tu(null, t, r, De(r.type, e), n);
                break e
            }
            throw Error(g(306, r, ""))
        }
        return t;
    case 0:
        return r = t.type,
        l = t.pendingProps,
        l = t.elementType === r ? l : De(r, l),
        Lo(e, t, r, l, n);
    case 1:
        return r = t.type,
        l = t.pendingProps,
        l = t.elementType === r ? l : De(r, l),
        Ru(e, t, r, l, n);
    case 3:
        e: {
            if (Da(t),
            e === null)
                throw Error(g(387));
            r = t.pendingProps,
            o = t.memoizedState,
            l = o.element,
            aa(e, t),
            Jr(t, r, null, n);
            var i = t.memoizedState;
            if (r = i.element,
            o.isDehydrated)
                if (o = {
                    element: r,
                    isDehydrated: !1,
                    cache: i.cache,
                    pendingSuspenseBoundaries: i.pendingSuspenseBoundaries,
                    transitions: i.transitions
                },
                t.updateQueue.baseState = o,
                t.memoizedState = o,
                t.flags & 256) {
                    l = fn(Error(g(423)), t),
                    t = Mu(e, t, r, n, l);
                    break e
                } else if (r !== l) {
                    l = fn(Error(g(424)), t),
                    t = Mu(e, t, r, n, l);
                    break e
                } else
                    for (Ee = pt(t.stateNode.containerInfo.firstChild),
                    Ce = t,
                    Q = !0,
                    Ue = null,
                    n = ua(t, null, r, n),
                    t.child = n; n; )
                        n.flags = n.flags & -3 | 4096,
                        n = n.sibling;
            else {
                if (sn(),
                r === l) {
                    t = tt(e, t, n);
                    break e
                }
                fe(e, t, r, n)
            }
            t = t.child
        }
        return t;
    case 5:
        return ca(t),
        e === null && No(t),
        r = t.type,
        l = t.pendingProps,
        o = e !== null ? e.memoizedProps : null,
        i = l.children,
        xo(r, l) ? i = null : o !== null && xo(r, o) && (t.flags |= 32),
        Oa(e, t),
        fe(e, t, i, n),
        t.child;
    case 6:
        return e === null && No(t),
        null;
    case 13:
        return Ia(e, t, n);
    case 4:
        return yi(t, t.stateNode.containerInfo),
        r = t.pendingProps,
        e === null ? t.child = an(t, null, r, n) : fe(e, t, r, n),
        t.child;
    case 11:
        return r = t.type,
        l = t.pendingProps,
        l = t.elementType === r ? l : De(r, l),
        Lu(e, t, r, l, n);
    case 7:
        return fe(e, t, t.pendingProps, n),
        t.child;
    case 8:
        return fe(e, t, t.pendingProps.children, n),
        t.child;
    case 12:
        return fe(e, t, t.pendingProps.children, n),
        t.child;
    case 10:
        e: {
            if (r = t.type._context,
            l = t.pendingProps,
            o = t.memoizedProps,
            i = l.value,
            A(Gr, r._currentValue),
            r._currentValue = i,
            o !== null)
                if (Ve(o.value, i)) {
                    if (o.children === l.children && !ye.current) {
                        t = tt(e, t, n);
                        break e
                    }
                } else
                    for (o = t.child,
                    o !== null && (o.return = t); o !== null; ) {
                        var u = o.dependencies;
                        if (u !== null) {
                            i = o.child;
                            for (var s = u.firstContext; s !== null; ) {
                                if (s.context === r) {
                                    if (o.tag === 1) {
                                        s = Je(-1, n & -n),
                                        s.tag = 2;
                                        var c = o.updateQueue;
                                        if (c !== null) {
                                            c = c.shared;
                                            var h = c.pending;
                                            h === null ? s.next = s : (s.next = h.next,
                                            h.next = s),
                                            c.pending = s
                                        }
                                    }
                                    o.lanes |= n,
                                    s = o.alternate,
                                    s !== null && (s.lanes |= n),
                                    _o(o.return, n, t),
                                    u.lanes |= n;
                                    break
                                }
                                s = s.next
                            }
                        } else if (o.tag === 10)
                            i = o.type === t.type ? null : o.child;
                        else if (o.tag === 18) {
                            if (i = o.return,
                            i === null)
                                throw Error(g(341));
                            i.lanes |= n,
                            u = i.alternate,
                            u !== null && (u.lanes |= n),
                            _o(i, n, t),
                            i = o.sibling
                        } else
                            i = o.child;
                        if (i !== null)
                            i.return = o;
                        else
                            for (i = o; i !== null; ) {
                                if (i === t) {
                                    i = null;
                                    break
                                }
                                if (o = i.sibling,
                                o !== null) {
                                    o.return = i.return,
                                    i = o;
                                    break
                                }
                                i = i.return
                            }
                        o = i
                    }
            fe(e, t, l.children, n),
            t = t.child
        }
        return t;
    case 9:
        return l = t.type,
        r = t.pendingProps.children,
        rn(t, n),
        l = Re(l),
        r = r(l),
        t.flags |= 1,
        fe(e, t, r, n),
        t.child;
    case 14:
        return r = t.type,
        l = De(r, t.pendingProps),
        l = De(r.type, l),
        Tu(e, t, r, l, n);
    case 15:
        return Ma(e, t, t.type, t.pendingProps, n);
    case 17:
        return r = t.type,
        l = t.pendingProps,
        l = t.elementType === r ? l : De(r, l),
        Rr(e, t),
        t.tag = 1,
        ge(r) ? (e = !0,
        Kr(t)) : e = !1,
        rn(t, n),
        La(t, r, l),
        jo(t, r, l, n),
        To(null, t, r, !0, e, n);
    case 19:
        return Ua(e, t, n);
    case 22:
        return Fa(e, t, n)
    }
    throw Error(g(156, t.tag))
}
;
function ec(e, t) {
    return Ps(e, t)
}
function Nd(e, t, n, r) {
    this.tag = e,
    this.key = n,
    this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null,
    this.index = 0,
    this.ref = null,
    this.pendingProps = t,
    this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null,
    this.mode = r,
    this.subtreeFlags = this.flags = 0,
    this.deletions = null,
    this.childLanes = this.lanes = 0,
    this.alternate = null
}
function Le(e, t, n, r) {
    return new Nd(e,t,n,r)
}
function Ri(e) {
    return e = e.prototype,
    !(!e || !e.isReactComponent)
}
function _d(e) {
    if (typeof e == "function")
        return Ri(e) ? 1 : 0;
    if (e != null) {
        if (e = e.$$typeof,
        e === Jo)
            return 11;
        if (e === qo)
            return 14
    }
    return 2
}
function yt(e, t) {
    var n = e.alternate;
    return n === null ? (n = Le(e.tag, t, e.key, e.mode),
    n.elementType = e.elementType,
    n.type = e.type,
    n.stateNode = e.stateNode,
    n.alternate = e,
    e.alternate = n) : (n.pendingProps = t,
    n.type = e.type,
    n.flags = 0,
    n.subtreeFlags = 0,
    n.deletions = null),
    n.flags = e.flags & 14680064,
    n.childLanes = e.childLanes,
    n.lanes = e.lanes,
    n.child = e.child,
    n.memoizedProps = e.memoizedProps,
    n.memoizedState = e.memoizedState,
    n.updateQueue = e.updateQueue,
    t = e.dependencies,
    n.dependencies = t === null ? null : {
        lanes: t.lanes,
        firstContext: t.firstContext
    },
    n.sibling = e.sibling,
    n.index = e.index,
    n.ref = e.ref,
    n
}
function Or(e, t, n, r, l, o) {
    var i = 2;
    if (r = e,
    typeof e == "function")
        Ri(e) && (i = 1);
    else if (typeof e == "string")
        i = 5;
    else
        e: switch (e) {
        case Bt:
            return Rt(n.children, l, o, t);
        case Zo:
            i = 8,
            l |= 8;
            break;
        case Jl:
            return e = Le(12, n, t, l | 2),
            e.elementType = Jl,
            e.lanes = o,
            e;
        case ql:
            return e = Le(13, n, t, l),
            e.elementType = ql,
            e.lanes = o,
            e;
        case bl:
            return e = Le(19, n, t, l),
            e.elementType = bl,
            e.lanes = o,
            e;
        case cs:
            return yl(n, l, o, t);
        default:
            if (typeof e == "object" && e !== null)
                switch (e.$$typeof) {
                case ss:
                    i = 10;
                    break e;
                case as:
                    i = 9;
                    break e;
                case Jo:
                    i = 11;
                    break e;
                case qo:
                    i = 14;
                    break e;
                case lt:
                    i = 16,
                    r = null;
                    break e
                }
            throw Error(g(130, e == null ? e : typeof e, ""))
        }
    return t = Le(i, n, t, l),
    t.elementType = e,
    t.type = r,
    t.lanes = o,
    t
}
function Rt(e, t, n, r) {
    return e = Le(7, e, r, t),
    e.lanes = n,
    e
}
function yl(e, t, n, r) {
    return e = Le(22, e, r, t),
    e.elementType = cs,
    e.lanes = n,
    e.stateNode = {
        isHidden: !1
    },
    e
}
function Yl(e, t, n) {
    return e = Le(6, e, null, t),
    e.lanes = n,
    e
}
function Xl(e, t, n) {
    return t = Le(4, e.children !== null ? e.children : [], e.key, t),
    t.lanes = n,
    t.stateNode = {
        containerInfo: e.containerInfo,
        pendingChildren: null,
        implementation: e.implementation
    },
    t
}
function Pd(e, t, n, r, l) {
    this.tag = t,
    this.containerInfo = e,
    this.finishedWork = this.pingCache = this.current = this.pendingChildren = null,
    this.timeoutHandle = -1,
    this.callbackNode = this.pendingContext = this.context = null,
    this.callbackPriority = 0,
    this.eventTimes = jl(0),
    this.expirationTimes = jl(-1),
    this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0,
    this.entanglements = jl(0),
    this.identifierPrefix = r,
    this.onRecoverableError = l,
    this.mutableSourceEagerHydrationData = null
}
function Mi(e, t, n, r, l, o, i, u, s) {
    return e = new Pd(e,t,n,u,s),
    t === 1 ? (t = 1,
    o === !0 && (t |= 8)) : t = 0,
    o = Le(3, null, null, t),
    e.current = o,
    o.stateNode = e,
    o.memoizedState = {
        element: r,
        isDehydrated: n,
        cache: null,
        transitions: null,
        pendingSuspenseBoundaries: null
    },
    vi(o),
    e
}
function jd(e, t, n) {
    var r = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
        $$typeof: Vt,
        key: r == null ? null : "" + r,
        children: e,
        containerInfo: t,
        implementation: n
    }
}
function tc(e) {
    if (!e)
        return wt;
    e = e._reactInternals;
    e: {
        if (At(e) !== e || e.tag !== 1)
            throw Error(g(170));
        var t = e;
        do {
            switch (t.tag) {
            case 3:
                t = t.stateNode.context;
                break e;
            case 1:
                if (ge(t.type)) {
                    t = t.stateNode.__reactInternalMemoizedMergedChildContext;
                    break e
                }
            }
            t = t.return
        } while (t !== null);
        throw Error(g(171))
    }
    if (e.tag === 1) {
        var n = e.type;
        if (ge(n))
            return ta(e, n, t)
    }
    return t
}
function nc(e, t, n, r, l, o, i, u, s) {
    return e = Mi(n, r, !0, e, l, o, i, u, s),
    e.context = tc(null),
    n = e.current,
    r = de(),
    l = vt(n),
    o = Je(r, l),
    o.callback = t ?? null,
    mt(n, o, l),
    e.current.lanes = l,
    tr(e, l, r),
    we(e, r),
    e
}
function gl(e, t, n, r) {
    var l = t.current
      , o = de()
      , i = vt(l);
    return n = tc(n),
    t.context === null ? t.context = n : t.pendingContext = n,
    t = Je(o, i),
    t.payload = {
        element: e
    },
    r = r === void 0 ? null : r,
    r !== null && (t.callback = r),
    e = mt(l, t, i),
    e !== null && ($e(e, l, i, o),
    zr(e, l, i)),
    i
}
function ol(e) {
    if (e = e.current,
    !e.child)
        return null;
    switch (e.child.tag) {
    case 5:
        return e.child.stateNode;
    default:
        return e.child.stateNode
    }
}
function Hu(e, t) {
    if (e = e.memoizedState,
    e !== null && e.dehydrated !== null) {
        var n = e.retryLane;
        e.retryLane = n !== 0 && n < t ? n : t
    }
}
function Fi(e, t) {
    Hu(e, t),
    (e = e.alternate) && Hu(e, t)
}
function zd() {
    return null
}
var rc = typeof reportError == "function" ? reportError : function(e) {
    console.error(e)
}
;
function Oi(e) {
    this._internalRoot = e
}
wl.prototype.render = Oi.prototype.render = function(e) {
    var t = this._internalRoot;
    if (t === null)
        throw Error(g(409));
    gl(e, t, null, null)
}
;
wl.prototype.unmount = Oi.prototype.unmount = function() {
    var e = this._internalRoot;
    if (e !== null) {
        this._internalRoot = null;
        var t = e.containerInfo;
        It(function() {
            gl(null, e, null, null)
        }),
        t[be] = null
    }
}
;
function wl(e) {
    this._internalRoot = e
}
wl.prototype.unstable_scheduleHydration = function(e) {
    if (e) {
        var t = Fs();
        e = {
            blockedOn: null,
            target: e,
            priority: t
        };
        for (var n = 0; n < it.length && t !== 0 && t < it[n].priority; n++)
            ;
        it.splice(n, 0, e),
        n === 0 && Ds(e)
    }
}
;
function Di(e) {
    return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11)
}
function xl(e) {
    return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11 && (e.nodeType !== 8 || e.nodeValue !== " react-mount-point-unstable "))
}
function Wu() {}
function Ld(e, t, n, r, l) {
    if (l) {
        if (typeof r == "function") {
            var o = r;
            r = function() {
                var c = ol(i);
                o.call(c)
            }
        }
        var i = nc(t, r, e, 0, null, !1, !1, "", Wu);
        return e._reactRootContainer = i,
        e[be] = i.current,
        Qn(e.nodeType === 8 ? e.parentNode : e),
        It(),
        i
    }
    for (; l = e.lastChild; )
        e.removeChild(l);
    if (typeof r == "function") {
        var u = r;
        r = function() {
            var c = ol(s);
            u.call(c)
        }
    }
    var s = Mi(e, 0, !1, null, null, !1, !1, "", Wu);
    return e._reactRootContainer = s,
    e[be] = s.current,
    Qn(e.nodeType === 8 ? e.parentNode : e),
    It(function() {
        gl(t, s, n, r)
    }),
    s
}
function kl(e, t, n, r, l) {
    var o = n._reactRootContainer;
    if (o) {
        var i = o;
        if (typeof l == "function") {
            var u = l;
            l = function() {
                var s = ol(i);
                u.call(s)
            }
        }
        gl(t, i, e, l)
    } else
        i = Ld(n, t, e, l, r);
    return ol(i)
}
Rs = function(e) {
    switch (e.tag) {
    case 3:
        var t = e.stateNode;
        if (t.current.memoizedState.isDehydrated) {
            var n = _n(t.pendingLanes);
            n !== 0 && (ti(t, n | 1),
            we(t, J()),
            !(F & 6) && (dn = J() + 500,
            St()))
        }
        break;
    case 13:
        It(function() {
            var r = et(e, 1);
            if (r !== null) {
                var l = de();
                $e(r, e, 1, l)
            }
        }),
        Fi(e, 1)
    }
}
;
ni = function(e) {
    if (e.tag === 13) {
        var t = et(e, 134217728);
        if (t !== null) {
            var n = de();
            $e(t, e, 134217728, n)
        }
        Fi(e, 134217728)
    }
}
;
Ms = function(e) {
    if (e.tag === 13) {
        var t = vt(e)
          , n = et(e, t);
        if (n !== null) {
            var r = de();
            $e(n, e, t, r)
        }
        Fi(e, t)
    }
}
;
Fs = function() {
    return O
}
;
Os = function(e, t) {
    var n = O;
    try {
        return O = e,
        t()
    } finally {
        O = n
    }
}
;
ao = function(e, t, n) {
    switch (t) {
    case "input":
        if (no(e, n),
        t = n.name,
        n.type === "radio" && t != null) {
            for (n = e; n.parentNode; )
                n = n.parentNode;
            for (n = n.querySelectorAll("input[name=" + JSON.stringify("" + t) + '][type="radio"]'),
            t = 0; t < n.length; t++) {
                var r = n[t];
                if (r !== e && r.form === e.form) {
                    var l = fl(r);
                    if (!l)
                        throw Error(g(90));
                    ds(r),
                    no(r, l)
                }
            }
        }
        break;
    case "textarea":
        ms(e, n);
        break;
    case "select":
        t = n.value,
        t != null && bt(e, !!n.multiple, t, !1)
    }
}
;
ks = zi;
Ss = It;
var Td = {
    usingClientEntryPoint: !1,
    Events: [rr, Kt, fl, ws, xs, zi]
}
  , En = {
    findFiberByHostInstance: jt,
    bundleType: 0,
    version: "18.3.1",
    rendererPackageName: "react-dom"
}
  , Rd = {
    bundleType: En.bundleType,
    version: En.version,
    rendererPackageName: En.rendererPackageName,
    rendererConfig: En.rendererConfig,
    overrideHookState: null,
    overrideHookStateDeletePath: null,
    overrideHookStateRenamePath: null,
    overrideProps: null,
    overridePropsDeletePath: null,
    overridePropsRenamePath: null,
    setErrorHandler: null,
    setSuspenseHandler: null,
    scheduleUpdate: null,
    currentDispatcherRef: nt.ReactCurrentDispatcher,
    findHostInstanceByFiber: function(e) {
        return e = Ns(e),
        e === null ? null : e.stateNode
    },
    findFiberByHostInstance: En.findFiberByHostInstance || zd,
    findHostInstancesForRefresh: null,
    scheduleRefresh: null,
    scheduleRoot: null,
    setRefreshHandler: null,
    getCurrentFiber: null,
    reconcilerVersion: "18.3.1-next-f1338f8080-20240426"
};
if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var Sr = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!Sr.isDisabled && Sr.supportsFiber)
        try {
            ul = Sr.inject(Rd),
            Qe = Sr
        } catch {}
}
_e.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Td;
_e.createPortal = function(e, t) {
    var n = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
    if (!Di(t))
        throw Error(g(200));
    return jd(e, t, null, n)
}
;
_e.createRoot = function(e, t) {
    if (!Di(e))
        throw Error(g(299));
    var n = !1
      , r = ""
      , l = rc;
    return t != null && (t.unstable_strictMode === !0 && (n = !0),
    t.identifierPrefix !== void 0 && (r = t.identifierPrefix),
    t.onRecoverableError !== void 0 && (l = t.onRecoverableError)),
    t = Mi(e, 1, !1, null, null, n, !1, r, l),
    e[be] = t.current,
    Qn(e.nodeType === 8 ? e.parentNode : e),
    new Oi(t)
}
;
_e.findDOMNode = function(e) {
    if (e == null)
        return null;
    if (e.nodeType === 1)
        return e;
    var t = e._reactInternals;
    if (t === void 0)
        throw typeof e.render == "function" ? Error(g(188)) : (e = Object.keys(e).join(","),
        Error(g(268, e)));
    return e = Ns(t),
    e = e === null ? null : e.stateNode,
    e
}
;
_e.flushSync = function(e) {
    return It(e)
}
;
_e.hydrate = function(e, t, n) {
    if (!xl(t))
        throw Error(g(200));
    return kl(null, e, t, !0, n)
}
;
_e.hydrateRoot = function(e, t, n) {
    if (!Di(e))
        throw Error(g(405));
    var r = n != null && n.hydratedSources || null
      , l = !1
      , o = ""
      , i = rc;
    if (n != null && (n.unstable_strictMode === !0 && (l = !0),
    n.identifierPrefix !== void 0 && (o = n.identifierPrefix),
    n.onRecoverableError !== void 0 && (i = n.onRecoverableError)),
    t = nc(t, null, e, 1, n ?? null, l, !1, o, i),
    e[be] = t.current,
    Qn(e),
    r)
        for (e = 0; e < r.length; e++)
            n = r[e],
            l = n._getVersion,
            l = l(n._source),
            t.mutableSourceEagerHydrationData == null ? t.mutableSourceEagerHydrationData = [n, l] : t.mutableSourceEagerHydrationData.push(n, l);
    return new wl(t)
}
;
_e.render = function(e, t, n) {
    if (!xl(t))
        throw Error(g(200));
    return kl(null, e, t, !1, n)
}
;
_e.unmountComponentAtNode = function(e) {
    if (!xl(e))
        throw Error(g(40));
    return e._reactRootContainer ? (It(function() {
        kl(null, null, e, !1, function() {
            e._reactRootContainer = null,
            e[be] = null
        })
    }),
    !0) : !1
}
;
_e.unstable_batchedUpdates = zi;
_e.unstable_renderSubtreeIntoContainer = function(e, t, n, r) {
    if (!xl(n))
        throw Error(g(200));
    if (e == null || e._reactInternals === void 0)
        throw Error(g(38));
    return kl(e, t, n, !1, r)
}
;
_e.version = "18.3.1-next-f1338f8080-20240426";
function lc() {
    if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"))
        try {
            __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(lc)
        } catch (e) {
            console.error(e)
        }
}
lc(),
ls.exports = _e;
var Md = ls.exports
  , Qu = Md;
Gl.createRoot = Qu.createRoot,
Gl.hydrateRoot = Qu.hydrateRoot;
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
var Fd = {
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2,
    strokeLinecap: "round",
    strokeLinejoin: "round"
};
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Od = e => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase().trim()
  , Fe = (e, t) => {
    const n = se.forwardRef( ({color: r="currentColor", size: l=24, strokeWidth: o=2, absoluteStrokeWidth: i, className: u="", children: s, ...c}, h) => se.createElement("svg", {
        ref: h,
        ...Fd,
        width: l,
        height: l,
        stroke: r,
        strokeWidth: i ? Number(o) * 24 / Number(l) : o,
        className: ["lucide", `lucide-${Od(e)}`, u].join(" "),
        ...c
    }, [...t.map( ([m,p]) => se.createElement(m, p)), ...Array.isArray(s) ? s : [s]]));
    return n.displayName = `${e}`,
    n
}
;
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Dd = Fe("AlertCircle", [["circle", {
    cx: "12",
    cy: "12",
    r: "10",
    key: "1mglay"
}], ["line", {
    x1: "12",
    x2: "12",
    y1: "8",
    y2: "12",
    key: "1pkeuh"
}], ["line", {
    x1: "12",
    x2: "12.01",
    y1: "16",
    y2: "16",
    key: "4dfq90"
}]]);
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Id = Fe("ArrowRight", [["path", {
    d: "M5 12h14",
    key: "1ays0h"
}], ["path", {
    d: "m12 5 7 7-7 7",
    key: "xquz4c"
}]]);
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Ud = Fe("Code", [["polyline", {
    points: "16 18 22 12 16 6",
    key: "z7tu5w"
}], ["polyline", {
    points: "8 6 2 12 8 18",
    key: "1eg1df"
}]]);
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Ad = Fe("Copy", [["rect", {
    width: "14",
    height: "14",
    x: "8",
    y: "8",
    rx: "2",
    ry: "2",
    key: "17jyea"
}], ["path", {
    d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",
    key: "zix9uf"
}]]);
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Ku = Fe("Download", [["path", {
    d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
    key: "ih7n3h"
}], ["polyline", {
    points: "7 10 12 15 17 10",
    key: "2ggqvy"
}], ["line", {
    x1: "12",
    x2: "12",
    y1: "15",
    y2: "3",
    key: "1vk2je"
}]]);
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const $d = Fe("Film", [["rect", {
    width: "18",
    height: "18",
    x: "3",
    y: "3",
    rx: "2",
    key: "afitv7"
}], ["path", {
    d: "M7 3v18",
    key: "bbkbws"
}], ["path", {
    d: "M3 7.5h4",
    key: "zfgn84"
}], ["path", {
    d: "M3 12h18",
    key: "1i2n21"
}], ["path", {
    d: "M3 16.5h4",
    key: "1230mu"
}], ["path", {
    d: "M17 3v18",
    key: "in4fa5"
}], ["path", {
    d: "M17 7.5h4",
    key: "myr1c1"
}], ["path", {
    d: "M17 16.5h4",
    key: "go4c1d"
}]]);
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Vd = Fe("Lightbulb", [["path", {
    d: "M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5",
    key: "1gvzjb"
}], ["path", {
    d: "M9 18h6",
    key: "x1upvd"
}], ["path", {
    d: "M10 22h4",
    key: "ceow96"
}]]);
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Bd = Fe("Link", [["path", {
    d: "M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71",
    key: "1cjeqo"
}], ["path", {
    d: "M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71",
    key: "19qd67"
}]]);
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Er = Fe("Loader2", [["path", {
    d: "M21 12a9 9 0 1 1-6.219-8.56",
    key: "13zald"
}]]);
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Hd = Fe("MessageCircle", [["path", {
    d: "M7.9 20A9 9 0 1 0 4 16.1L2 22Z",
    key: "vv11sd"
}]]);
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Wd = Fe("MessageSquare", [["path", {
    d: "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",
    key: "1lielz"
}]]);
/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Qd = Fe("Sparkles", [["path", {
    d: "m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z",
    key: "17u4zn"
}], ["path", {
    d: "M5 3v4",
    key: "bklmnn"
}], ["path", {
    d: "M19 17v4",
    key: "iiml17"
}], ["path", {
    d: "M3 5h4",
    key: "nem4j1"
}], ["path", {
    d: "M17 19h4",
    key: "lbex7p"
}]])
  , Kd = [{
    name: "Bilibili",
    slug: "bilibili",
    color: "#00A1D6"
}, {
    name: "Bluesky",
    slug: "bluesky",
    color: "#0285FF"
}, {
    name: "Dailymotion",
    slug: "dailymotion",
    color: "#FFFFFF"
}, {
    name: "Facebook",
    slug: "facebook",
    color: "#1877F2"
}, {
    name: "Instagram",
    slug: "instagram",
    color: "#E4405F"
}, {
    name: "Loom",
    slug: "loom",
    color: "#625DF5"
}, {
    name: "Ok.ru",
    slug: "odnoklassniki",
    color: "#EE8208"
}, {
    name: "Pinterest",
    slug: "pinterest",
    color: "#BD081C"
}, {
    name: "Reddit",
    slug: "reddit",
    color: "#FF4500"
}, {
    name: "Rutube",
    slug: "rutube",
    color: "#00C7FF"
}, {
    name: "Snapchat",
    slug: "snapchat",
    color: "#FFFC00"
}, {
    name: "Soundcloud",
    slug: "soundcloud",
    color: "#FF3300"
}, {
    name: "Streamable",
    slug: "streamable",
    color: "#0F90FA"
}, {
    name: "TikTok",
    slug: "tiktok",
    color: "#000000"
}, {
    name: "Tumblr",
    slug: "tumblr",
    color: "#36465D"
}, {
    name: "Twitch",
    slug: "twitch",
    color: "#9146FF"
}, {
    name: "Twitter/X",
    slug: "x",
    color: "#000000"
}, {
    name: "Vimeo",
    slug: "vimeo",
    color: "#1AB7EA"
}, {
    name: "VK",
    slug: "vk",
    color: "#0077FF"
}, {
    name: "YouTube",
    slug: "youtube",
    color: "#FF0000"
}, {
    name: "Spotify",
    slug: "spotify",
    color: "#1DB954"
}]
  , Yd = () => {
    const [e,t] = se.useState("")
      , [n,r] = se.useState(!1)
      , [l,o] = se.useState(null)
      , [i,u] = se.useState(null)
      , [s,c] = se.useState(!1)
      , [h,m] = se.useState(!1)
      , [p,w] = se.useState(null)
      , [k,S] = se.useState(null)
      , D = se.useRef(null)
      , f = se.useRef(null)
      , a = P => {
        t(P.target.value),
        l && o(null)
    }
      , d = async () => {
        try {
            const P = await navigator.clipboard.readText();
            t(P)
        } catch {}
    }
      , y = P => !(typeof P != "string" || !P.startsWith("http") || /\.(jpg|jpeg|png|webp|gif|svg|bmp|tiff)$/i.test(P))
      , E = P => {
        if (!P)
            return null;
        if (typeof P == "string")
            return y(P) ? P : null;
        const T = ["hd", "sd", "mp4", "video", "stream", "download_url", "download"];
        for (const U of T)
            if (P[U] && y(P[U]))
                return P[U];
        const I = ["url", "link", "src"];
        for (const U of I)
            if (P[U] && y(P[U]))
                return P[U];
        if (typeof P == "object")
            for (const U in P) {
                if (["thumbnail", "image", "cover", "poster", "avatars", "author"].includes(U.toLowerCase()))
                    continue;
                const $ = E(P[U]);
                if ($)
                    return $
            }
        return null
    }
      , _ = async P => {
        try {
            const T = await fetch(P);
            if (T.ok) {
                const I = T.headers.get("content-type");
                if (I && I.includes("application/json"))
                    return await T.json()
            }
        } catch {
            console.warn("Direct fetch failed, attempting Proxy 1...")
        }
        try {
            const T = `https://corsproxy.io/?${encodeURIComponent(P)}`
              , I = await fetch(T);
            if (I.ok)
                return await I.json()
        } catch {
            console.warn("Proxy 1 failed, attempting Proxy 2...")
        }
        try {
            const T = `https://tele-social.vercel.app/down?url=${encodeURIComponent(P)}`
              , I = await fetch(T);
            if (I.ok) {
                const U = await I.json();
                if (U.contents)
                    try {
                        return JSON.parse(U.contents)
                    } catch {
                        console.error("Failed to parse AllOrigins response")
                    }
            }
        } catch {
            console.warn("All proxies failed.")
        }
        throw new Error("Unable to fetch video info. Network might be blocked or URL is invalid.")
    }
      , N = async () => {
        if (e.trim()) {
            r(!0),
            o(null),
            u(null),
            w(null);
            try {
                const P = `https://tele-social.vercel.app/down?url=${encodeURIComponent(e)}`
                  , T = await _(P);
                console.log("API Response:", T);
                const I = E(T)
                  , U = T.title || T.text || T.caption || "Downloaded Video"
                  , $ = T.thumbnail || T.image || T.cover || null
                  , ke = T.author || "Unknown";
                if (I)
                    u({
                        downloadUrl: I,
                        title: U,
                        thumbnail: $,
                        author: ke,
                        source: T
                    }),
                    setTimeout( () => {
                        var x;
                        (x = D.current) == null || x.scrollIntoView({
                            behavior: "smooth",
                            block: "start"
                        })
                    }
                    , 100);
                else
                    throw new Error("Could not find a valid video link. The link might be private or an image.")
            } catch (P) {
                console.error(P),
                o(P.message || "An unexpected error occurred. Please check the URL.")
            } finally {
                r(!1)
            }
        }
    }
      , j = async P => {
        var I, U, $, ke, x;
        if (!i)
            return;
        m(!0),
        S(P),
        w(null);
        const T = "";
        try {
            let z = "";
            if (P === "caption" ? z = `You are a social media expert. Generate a catchy, engaging caption and 15 relevant viral hashtags for a video titled "${i.title}" by creator "${i.author}". The platform is likely a short-form video site. Return the caption first, then a line break, then the hashtags.` : P === "ideas" && (z = `You are a creative director. Based on the video titled "${i.title}" by creator "${i.author}", suggest 5 unique and engaging follow-up video ideas or remix concepts that a creator could make next. Format as a numbered list with short descriptions.`),
            !T)
                throw new Error("API Key is missing in the code.");
            const L = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=${T}`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    contents: [{
                        parts: [{
                            text: z
                        }]
                    }]
                })
            });
            if (!L.ok)
                throw new Error("AI Generation failed. Please try again.");
            const K = (x = (ke = ($ = (U = (I = (await L.json()).candidates) == null ? void 0 : I[0]) == null ? void 0 : U.content) == null ? void 0 : $.parts) == null ? void 0 : ke[0]) == null ? void 0 : x.text;
            if (K)
                w(K),
                setTimeout( () => {
                    var Et;
                    (Et = f.current) == null || Et.scrollIntoView({
                        behavior: "smooth",
                        block: "start"
                    })
                }
                , 100);
            else
                throw new Error("No output from AI.")
        } catch (z) {
            console.error("Gemini API Error:", z),
            w("AI feature requires a valid API Key in src/App.jsx code. Please add it to use this feature.")
        } finally {
            m(!1)
        }
    }
      , H = (P, T) => {
        const I = document.createElement("a");
        I.href = P,
        I.download = T,
        document.body.appendChild(I),
        I.click(),
        document.body.removeChild(I),
        window.URL.revokeObjectURL(P)
    }
      , R = async (P, T) => {
        c(!0);
        try {
            const U = (T || "video").replace(/[\/\\:*?"<>|]/g, "").substring(0, 50).trim() || "video"
              , $ = Math.floor(Math.random() * 1e4);
            let ke = `${U}_${$}.mp4`;
            const x = await fetch(P);
            if (!x.ok)
                throw new Error("Direct fetch failed");
            const z = await x.blob()
              , L = window.URL.createObjectURL(z);
            H(L, ke)
        } catch {
            console.warn("Direct download blocked (CORS), attempting Proxy Tunnel...");
            try {
                const U = `https://corsproxy.io/?${encodeURIComponent(P)}`
                  , $ = await fetch(U);
                if (!$.ok)
                    throw new Error("Proxy fetch failed");
                const ke = await $.blob()
                  , x = window.URL.createObjectURL(ke)
                  , L = (T || "video").replace(/[\/\\:*?"<>|]/g, "").substring(0, 50).trim() || "video"
                  , W = Math.floor(Math.random() * 1e4);
                let K = `${L}_${W}.mp4`;
                H(x, K)
            } catch (U) {
                console.warn("Proxy tunnel failed, falling back to new tab.", U);
                const $ = document.createElement("a");
                $.href = P;
                const x = (T || "video").replace(/[\/\\:*?"<>|]/g, "").substring(0, 50).trim() || "video"
                  , z = Math.floor(Math.random() * 1e4);
                $.download = `${x}_${z}.mp4`,
                $.target = "_blank",
                $.rel = "noopener noreferrer",
                document.body.appendChild($),
                $.click(),
                document.body.removeChild($)
            }
        } finally {
            c(!1)
        }
    }
      , xe = async P => {
        try {
            await navigator.clipboard.writeText(P)
        } catch (T) {
            console.error("Failed to copy", T)
        }
    }
    ;
    return v.jsxs("div", {
        className: "min-h-screen bg-slate-950 text-slate-200 font-sans selection:bg-indigo-500/30",
        children: [v.jsxs("div", {
            className: "fixed inset-0 z-0 overflow-hidden pointer-events-none",
            children: [v.jsx("div", {
                className: "absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-600/20 rounded-full blur-[120px]"
            }), v.jsx("div", {
                className: "absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-purple-600/20 rounded-full blur-[120px]"
            })]
        }), v.jsxs("div", {
            className: "relative z-10 max-w-5xl mx-auto px-4 py-8 flex flex-col min-h-screen",
            children: [v.jsxs("header", {
                className: "flex items-center justify-between mb-16",
                children: [v.jsxs("div", {
                    className: "flex items-center gap-2",
                    children: [v.jsx("div", {
                        className: "w-10 h-10 bg-gradient-to-tr from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20",
                        children: v.jsx(Ku, {
                            className: "text-white w-6 h-6"
                        })
                    }), v.jsx("div", {
                        children: v.jsx("span", {
                            className: "text-2xl font-bold tracking-tight text-white block leading-none",
                            children: "HOWLER Social"
                        })
                    })]
                }), v.jsxs("div", {
                    className: "hidden md:flex items-center gap-6 text-sm font-medium text-slate-400",
                    children: [v.jsx("span", {
                        className: "hover:text-white transition-colors cursor-pointer",
                        children: "How it works"
                    }), v.jsx("span", {
                        className: "hover:text-white transition-colors cursor-pointer",
                        children: "Supported Sites"
                    }), v.jsx("a", {
                        href: "#",
                        className: "hover:text-white transition-colors",
                        children: "API"
                    })]
                })]
            }), v.jsxs("main", {
                className: "flex-grow flex flex-col items-center justify-center text-center mb-12",
                children: [v.jsxs("div", {
                    className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900/50 border border-slate-800 text-xs font-medium text-indigo-400 mb-6 animate-fade-in-up",
                    children: [v.jsxs("span", {
                        className: "relative flex h-2 w-2",
                        children: [v.jsx("span", {
                            className: "animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"
                        }), v.jsx("span", {
                            className: "relative inline-flex rounded-full h-2 w-2 bg-indigo-500"
                        })]
                    }), "Supports 20+ Social Platforms"]
                }), v.jsxs("h1", {
                    className: "text-4xl md:text-6xl font-extrabold text-white mb-2 tracking-tight leading-tight",
                    children: ["NIGHT-HOWLER ", v.jsx("br", {
                        className: "hidden md:block"
                    }), v.jsx("span", {
                        className: "text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400",
                        children: "Media Downloader"
                    })]
                }), v.jsxs("div", {
                    className: "mb-8 flex items-center justify-center gap-2 opacity-80 hover:opacity-100 transition-opacity",
                    children: [v.jsx(Ud, {
                        className: "w-4 h-4 text-indigo-400"
                    }), v.jsxs("span", {
                        className: "text-sm font-medium text-slate-400 tracking-wide uppercase",
                        children: ["Developed by ", v.jsx("span", {
                            className: "text-indigo-300",
                            children: "NIGHT-HOWLER"
                        })]
                    })]
                }), v.jsx("p", {
                    className: "text-lg text-slate-400 max-w-2xl mb-10 leading-relaxed",
                    children: "Download videos directly from your favorite social networks. No ads, no new tabs, just paste and save."
                }), v.jsxs("div", {
                    className: "w-full max-w-2xl relative group",
                    children: [v.jsx("div", {
                        className: "absolute -inset-1 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"
                    }), v.jsxs("div", {
                        className: "relative bg-slate-900 ring-1 ring-slate-800 rounded-2xl p-2 flex flex-col md:flex-row items-center gap-2 shadow-2xl",
                        children: [v.jsxs("div", {
                            className: "flex-grow flex items-center w-full md:w-auto px-4 h-12 md:h-14",
                            children: [v.jsx(Bd, {
                                className: "w-5 h-5 text-slate-500 mr-3"
                            }), v.jsx("input", {
                                type: "text",
                                placeholder: "Paste video URL here...",
                                className: "bg-transparent border-none outline-none text-slate-200 placeholder-slate-500 w-full h-full text-lg",
                                value: e,
                                onChange: a,
                                onKeyDown: P => P.key === "Enter" && N()
                            }), e && v.jsx("button", {
                                onClick: () => t(""),
                                className: "text-slate-600 hover:text-slate-400 p-1",
                                children: "✕"
                            })]
                        }), v.jsx("button", {
                            onClick: N,
                            disabled: n || !e,
                            className: "w-full md:w-auto h-12 md:h-14 px-8 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold transition-all shadow-lg shadow-indigo-500/20 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 whitespace-nowrap",
                            children: n ? v.jsx(Er, {
                                className: "w-5 h-5 animate-spin"
                            }) : v.jsxs(v.Fragment, {
                                children: ["Download", v.jsx(Id, {
                                    className: "w-4 h-4"
                                })]
                            })
                        })]
                    }), v.jsx("div", {
                        className: "absolute right-0 -bottom-8",
                        children: v.jsx("button", {
                            onClick: d,
                            className: "text-xs text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1",
                            children: "Paste from clipboard"
                        })
                    })]
                }), l && v.jsxs("div", {
                    className: "mt-8 p-4 bg-red-500/10 border border-red-500/20 rounded-xl text-red-200 flex items-center gap-3 animate-fade-in text-left max-w-xl mx-auto",
                    children: [v.jsx(Dd, {
                        className: "w-5 h-5 text-red-400 flex-shrink-0"
                    }), v.jsx("p", {
                        children: l
                    })]
                })]
            }), i && v.jsx("div", {
                ref: D,
                className: "w-full max-w-3xl mx-auto mb-20 animate-fade-in-up",
                children: v.jsxs("div", {
                    className: "bg-slate-900/80 backdrop-blur-xl border border-slate-700/50 rounded-3xl overflow-hidden shadow-2xl",
                    children: [v.jsxs("div", {
                        className: "p-6 md:p-8 flex flex-col md:flex-row gap-8 items-start",
                        children: [v.jsxs("div", {
                            className: "w-full md:w-1/2 aspect-video bg-slate-800 rounded-2xl overflow-hidden relative shadow-inner group",
                            children: [i.thumbnail ? v.jsx("img", {
                                src: i.thumbnail,
                                alt: i.title,
                                className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            }) : v.jsx("div", {
                                className: "w-full h-full flex items-center justify-center text-slate-600",
                                children: v.jsx($d, {
                                    className: "w-12 h-12 opacity-50"
                                })
                            }), v.jsx("div", {
                                className: "absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors"
                            })]
                        }), v.jsxs("div", {
                            className: "w-full md:w-1/2 flex flex-col justify-between min-h-[200px]",
                            children: [v.jsxs("div", {
                                children: [v.jsxs("div", {
                                    className: "flex items-center gap-2 mb-3",
                                    children: [v.jsx("span", {
                                        className: "px-2 py-0.5 rounded text-[10px] font-bold bg-green-500/20 text-green-400 border border-green-500/20 uppercase tracking-wider",
                                        children: "Ready"
                                    }), v.jsx("span", {
                                        className: "text-xs text-slate-500",
                                        children: i.author
                                    })]
                                }), v.jsx("h3", {
                                    className: "text-xl font-bold text-white mb-2 line-clamp-2 leading-snug",
                                    children: i.title
                                })]
                            }), v.jsxs("div", {
                                className: "mt-6 flex flex-col gap-3",
                                children: [v.jsx("button", {
                                    onClick: () => R(i.downloadUrl, i.title),
                                    disabled: s,
                                    className: "w-full py-4 bg-white hover:bg-slate-200 text-slate-900 rounded-xl font-bold text-lg flex items-center justify-center gap-2 transition-all active:scale-[0.98]",
                                    children: s ? v.jsxs(v.Fragment, {
                                        children: [v.jsx(Er, {
                                            className: "w-5 h-5 animate-spin"
                                        }), "Downloading..."]
                                    }) : v.jsxs(v.Fragment, {
                                        children: [v.jsx(Ku, {
                                            className: "w-5 h-5"
                                        }), "Download Video"]
                                    })
                                }), v.jsxs("div", {
                                    className: "pt-4 mt-2 border-t border-slate-800",
                                    children: [v.jsxs("p", {
                                        className: "text-xs font-bold text-slate-500 uppercase tracking-wider mb-3",
                                        children: [v.jsx("span", {
                                            className: "mr-1",
                                            children: "✨"
                                        }), " Smart Social Assistant"]
                                    }), v.jsxs("div", {
                                        className: "grid grid-cols-2 gap-2",
                                        children: [v.jsxs("button", {
                                            onClick: () => j("caption"),
                                            disabled: h,
                                            className: "py-2.5 px-3 bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-all",
                                            children: [h && k === "caption" ? v.jsx(Er, {
                                                className: "w-3 h-3 animate-spin"
                                            }) : v.jsx(Wd, {
                                                className: "w-3 h-3"
                                            }), "Viral Caption"]
                                        }), v.jsxs("button", {
                                            onClick: () => j("ideas"),
                                            disabled: h,
                                            className: "py-2.5 px-3 bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/30 text-purple-300 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-all",
                                            children: [h && k === "ideas" ? v.jsx(Er, {
                                                className: "w-3 h-3 animate-spin"
                                            }) : v.jsx(Vd, {
                                                className: "w-3 h-3"
                                            }), "Remix Ideas"]
                                        })]
                                    })]
                                })]
                            })]
                        })]
                    }), p && v.jsxs("div", {
                        ref: f,
                        className: "bg-slate-950/50 border-t border-slate-800 p-6 animate-fade-in",
                        children: [v.jsxs("div", {
                            className: "flex items-center justify-between mb-3",
                            children: [v.jsxs("h4", {
                                className: "text-sm font-bold text-white flex items-center gap-2",
                                children: [v.jsx(Qd, {
                                    className: "w-4 h-4 text-amber-400"
                                }), k === "caption" ? "AI Generated Caption" : "Creative Ideas"]
                            }), v.jsxs("button", {
                                onClick: () => xe(p),
                                className: "text-xs flex items-center gap-1 text-slate-400 hover:text-white transition-colors",
                                children: [v.jsx(Ad, {
                                    className: "w-3 h-3"
                                }), " Copy"]
                            })]
                        }), v.jsx("div", {
                            className: "bg-slate-900 rounded-xl p-4 border border-slate-800 text-sm text-slate-300 whitespace-pre-wrap leading-relaxed shadow-inner",
                            children: p
                        })]
                    })]
                })
            }), v.jsxs("div", {
                className: "border-t border-slate-800/50 pt-16",
                children: [v.jsx("h2", {
                    className: "text-center text-slate-400 font-medium mb-10 text-sm uppercase tracking-widest",
                    children: "Supported Platforms"
                }), v.jsx("div", {
                    className: "grid grid-cols-3 sm:grid-cols-4 md:grid-cols-7 gap-4",
                    children: Kd.map(P => v.jsxs("div", {
                        className: "flex flex-col items-center justify-center gap-3 p-4 rounded-2xl bg-slate-900/30 border border-slate-800 hover:border-indigo-500/30 hover:bg-slate-800/50 transition-all group cursor-default h-28",
                        children: [v.jsxs("div", {
                            className: "w-8 h-8 relative flex items-center justify-center transition-transform duration-300 group-hover:scale-110",
                            children: [v.jsx("img", {
                                src: `https://cdn.simpleicons.org/${P.slug}/white`,
                                alt: P.name,
                                className: "w-full h-full object-contain opacity-70 group-hover:opacity-100 transition-opacity",
                                onError: T => {
                                    T.target.style.display = "none",
                                    T.target.nextSibling.style.display = "block"
                                }
                            }), v.jsx("div", {
                                style: {
                                    display: "none"
                                },
                                className: "w-8 h-8 rounded-full bg-slate-700"
                            })]
                        }), v.jsx("span", {
                            className: "text-xs font-medium text-slate-500 group-hover:text-slate-200 transition-colors text-center",
                            children: P.name
                        })]
                    }, P.slug))
                })]
            }), v.jsx("footer", {
                className: "mt-20 border-t border-slate-900 pt-8 pb-12 text-center",
                children: v.jsxs("div", {
                    className: "flex flex-col items-center gap-4",
                    children: [v.jsxs("a", {
                        href: "https://whatsapp.com/channel/0029Vb56S8R4yltWXkgB5s1h",
                        target: "_blank",
                        rel: "noopener noreferrer",
                        className: "inline-flex items-center gap-2 px-4 py-2 rounded-full bg-green-500/10 text-green-400 hover:bg-green-500/20 transition-colors text-sm font-medium border border-green-500/20",
                        children: [v.jsx(Hd, {
                            className: "w-4 h-4"
                        }), "Join WhatsApp Channel"]
                    }), v.jsxs("p", {
                        className: "text-slate-600 text-sm",
                        children: ["© ", new Date().getFullYear(), " HOWLER Social Downloader. All rights reserved."]
                    })]
                })
            })]
        })]
    })
}
;
Gl.createRoot(document.getElementById("root")).render(v.jsx(kc.StrictMode, {
    children: v.jsx(Yd, {})
}));
